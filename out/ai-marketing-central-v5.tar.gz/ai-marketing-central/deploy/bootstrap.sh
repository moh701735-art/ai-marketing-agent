#!/usr/bin/env bash
# تثبيت staging/prod على سيرفر (أو محلياً للاختبار): يولّد الأسرار، يبني القاعدتين بلا بيانات تجريبية، يستورد الـ workflows، ويشغّل الخدمات.
# الاستعمال:  DOMAIN=bot.example.com ACME_EMAIL=you@example.com deploy/bootstrap.sh [--mock]
#   --mock : يشغّل منصات وهمية (P7). بدونها يجب ضبط عناوين المنصات الحقيقية بـ deploy/.env (P8 فقط).
# آمن لإعادة التشغيل: لا يستبدل .env/الأسرار الموجودة، ولا يعيد إنشاء القاعدة إن كانت موجودة.
set -euo pipefail
cd "$(dirname "$0")/.."
MOCK=""; [ "${1:-}" = "--mock" ] && MOCK="--profile mock"
umask 077; mkdir -p deploy/.secrets; touch deploy/.env
add() { grep -q "^$1=" deploy/.env || echo "$1=$2" >> deploy/.env; }
[ -n "${DOMAIN:-}" ] && add DOMAIN "$DOMAIN"; [ -n "${ACME_EMAIL:-}" ] && add ACME_EMAIL "$ACME_EMAIL"
grep -q '^DOMAIN=' deploy/.env || { echo "حدّد DOMAIN (مثلاً DOMAIN=bot.example.com)"; exit 1; }
[ "$(grep ^DOMAIN= deploy/.env | cut -d= -f2)" = "localhost" ] && add ACME_EMAIL test@example.com     # اختبار محلي فقط (شهادة داخلية)
grep -q '^ACME_EMAIL=' deploy/.env || { echo "حدّد ACME_EMAIL (بريد حقيقي لإشعارات Let's Encrypt)"; exit 1; }
add COMPOSE_PROJECT_NAME "${COMPOSE_PROJECT_NAME:-central-stg}"; add DB_CENTRAL central; add DB_VAULT vault
add POSTGRES_PASSWORD "$(openssl rand -hex 24)"; add SVC_PW "$(openssl rand -hex 16)"
add N8N_ENCRYPTION_KEY "$(openssl rand -hex 24)"; add BROKER_HMAC_KEY "$(openssl rand -hex 32)"; add BROKER_ADMIN_KEY "$(openssl rand -hex 32)"
[ -f deploy/.secrets/backup.pass ] || openssl rand -hex 32 > deploy/.secrets/backup.pass
if [ ! -f deploy/.secrets/broker_secrets.json ]; then
  K=$(grep ^BROKER_HMAC_KEY deploy/.env | cut -d= -f2); A=$(grep ^BROKER_ADMIN_KEY deploy/.env | cut -d= -f2)
  printf '{"kek":"%s","hmac_keys":{"n8n-runtime":{"key":"%s","scope":"runtime"},"ops-admin":{"key":"%s","scope":"admin"}}}' \
    "$(openssl rand -base64 32)" "$(printf %s "$K" | base64 -w0)" "$(printf %s "$A" | base64 -w0)" > deploy/.secrets/broker_secrets.json
fi
chmod 600 deploy/.env deploy/.secrets/*; chmod 644 deploy/.secrets/broker_secrets.json   # الحاوية (uid 10001) تقرأه؛ المجلد 700 للمالك فقط
set -a; . deploy/.env; set +a
DC="docker compose --env-file deploy/.env -f deploy/docker-compose.prod.yml $MOCK"
PG="docker exec -i ${COMPOSE_PROJECT_NAME}-pg"; P="$PG psql -U postgres -q -v ON_ERROR_STOP=1"
CA=""; [ -f /root/.ccr/ca-bundle.crt ] && CA="--secret id=ca,src=/root/.ccr/ca-bundle.crt"
echo "── بناء Broker"; DOCKER_BUILDKIT=1 docker build -q $CA -t "central-broker:${BROKER_TAG:-prod}" broker/ >/dev/null
echo "── Postgres"; $DC up -d postgres >/dev/null
for i in $(seq 1 60); do docker exec "${COMPOSE_PROJECT_NAME}-pg" pg_isready -U postgres >/dev/null 2>&1 && break; sleep 2; done
if [ -z "$($P -At -d postgres -c "select 1 from pg_database where datname='$DB_CENTRAL'")" ]; then
  echo "── بناء القاعدتين (بلا بيانات تجريبية)"
  $P -d postgres -c "CREATE DATABASE $DB_CENTRAL" -c "CREATE DATABASE $DB_VAULT" >/dev/null
  $P -d postgres -f /work/db/00_roles.sql >/dev/null
  $P -d "$DB_CENTRAL" -c "REVOKE ALL ON DATABASE $DB_CENTRAL FROM PUBLIC; GRANT CONNECT ON DATABASE $DB_CENTRAL TO app_runtime, app_jobs, app_ops, app_owner, app_resolver, app_ops_fn, app_broker; GRANT TEMPORARY ON DATABASE $DB_CENTRAL TO app_owner;" >/dev/null
  for f in 10_schema 20_rls 30_functions 35_broker_auth 40_partitions 60_rules; do $P -d "$DB_CENTRAL" -f /work/db/$f.sql >/dev/null; done
  for f in 50_vault 51_vault_broker; do $P -d "$DB_VAULT" -f /work/db/$f.sql >/dev/null; done
  $P -d "$DB_VAULT" -c "REVOKE ALL ON DATABASE $DB_VAULT FROM PUBLIC; GRANT CONNECT ON DATABASE $DB_VAULT TO broker_rw;" >/dev/null
fi
$P -d "$DB_CENTRAL" -f /work/deploy/canary.sql >/dev/null      # كاناري العزل (R10): انظر deploy/canary.sql
echo "── حسابات الخدمة"
for spec in "broker_central_svc:app_broker" "broker_vault_svc:broker_rw" "n8n_runtime_svc:app_runtime" "n8n_jobs_svc:app_jobs"; do
  u=${spec%%:*}; r=${spec##*:}
  $P -d postgres -c "DO \$\$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='$u') THEN CREATE ROLE $u LOGIN IN ROLE $r; END IF; END \$\$" -c "ALTER ROLE $u PASSWORD '$SVC_PW' LOGIN" >/dev/null
done
[ -n "$MOCK" ] && $DC up -d platform-mock >/dev/null      # P7: منصات وهمية
echo "── Broker + n8n"; $DC up -d broker n8n >/dev/null
for i in $(seq 1 60); do docker exec "${COMPOSE_PROJECT_NAME}-n8n" wget -qO- http://localhost:5678/healthz >/dev/null 2>&1 && break; sleep 2; done
echo "── استيراد الـ workflows"
python3 n8n/build.py >/dev/null; mkdir -p n8n/generated; chmod 755 n8n/generated      # الحاوية (مستخدم node) تقرؤه عبر bind mount
python3 - "$SVC_PW" "$BROKER_HMAC_KEY" "$DB_CENTRAL" <<'PY'
import json, sys
pw, hk, db = sys.argv[1:4]
def pg(i, name, user): return {"id": i, "name": name, "type": "postgres", "data": {"host": "postgres", "port": 5432, "database": db, "user": user, "password": pw, "maxConnections": 10, "allowUnauthorizedCerts": False, "ssl": "disable", "sshTunnel": False, "sshAuthenticateWith": "password"}}
json.dump([pg("credPgRuntime0001", "central DB (runtime)", "n8n_runtime_svc"), pg("credPgJobs000001", "central DB (jobs)", "n8n_jobs_svc"),
           {"id": "credCryptoBroker1", "name": "Broker HMAC (n8n runtime)", "type": "crypto", "data": {"hmacSecret": hk}}], open("n8n/generated/credentials.json", "w"))
PY
chmod 644 n8n/generated/credentials.json
N="docker exec ${COMPOSE_PROJECT_NAME}-n8n n8n"
$N import:credentials --input=/import/generated/credentials.json 2>&1 | tail -1
$N import:workflow --separate --input=/import/workflows/ 2>&1 | tail -1
for id in $(ls n8n/workflows/*.json | xargs -n1 python3 -c "import json,sys;d=json.load(open(sys.argv[1]));print(d['id'])" | grep -v wfSelfTestErr0001); do $N publish:workflow --id="$id" >/dev/null 2>&1 || true; done   # workflow الاختبار الذاتي لا يُنشر
rm -f n8n/generated/credentials.json      # يحوي كلمة مرور الخدمة: لا يبقى على القرص بعد الاستيراد
docker restart "${COMPOSE_PROJECT_NAME}-n8n" >/dev/null
for i in $(seq 1 60); do docker exec "${COMPOSE_PROJECT_NAME}-n8n" wget -qO- http://localhost:5678/healthz >/dev/null 2>&1 && break; sleep 2; done
echo "── Caddy (TLS)"; $DC up -d caddy >/dev/null
echo "جاهز: https://$DOMAIN/webhook/tg-ingress (POST فقط). الخطوة التالية: ops/add-tenant.py مع PG_CONTAINER/BROKER_NETWORK/ENV_FILE (انظر deploy/RUNBOOK.md)"
