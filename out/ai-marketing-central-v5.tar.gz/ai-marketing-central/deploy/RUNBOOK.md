# دليل تشغيل staging/prod للورك فلو المركزي (P7)

> **حالة P7:** كل ما بهذا الدليل **مجرَّب محلياً** على Docker (نفس الملفات، منصات وهمية، `DOMAIN=localhost`). **لم يُجرَّب على سيرفر حقيقي ولا بشهادة Let's Encrypt حقيقية** (يحتاج سيرفر ودومين منك).
> لا منصة حقيقية قبل P8: `BROKER_ALLOW_REAL_PLATFORMS` يبقى 0 (الـ Broker يرفض الإقلاع إن أُشير لمضيف حقيقي).

## 0) المتطلبات (منك)
1. سيرفر Ubuntu 22.04/24.04 جديد **مخصّص للمركزي** (حساب مزوّد منفصل عن البوت القديم)، 2–4 GB رام، مفتاح SSH.
2. دومين/نطاق فرعي (مثل `bot.example.com`) يشير بسجل A إلى IP السيرفر.
3. (اختياري) حساب تخزين للنسخ الاحتياطي (Backblaze B2 مثلاً) و`rclone config`، ورابط مراقبة (healthchecks.io) لكل مهمة.

## 1) التثبيت (على السيرفر كـ root)
```
git clone <المستودع> /opt/central && cd /opt/central      # أو انسخه بـ scp/rsync
deploy/server-setup.sh                                    # جدار ناري 22/80/443، fail2ban، تحديثات تلقائية، Docker، cron
DOMAIN=bot.example.com ACME_EMAIL=you@example.com deploy/bootstrap.sh --mock
```
- `--mock` = منصات وهمية (P7). **بدون المنصات الحقيقية.**
- يولّد الأسرار في `deploy/.env` و`deploy/.secrets/` (لا تُرفع لـ Git)، يبني القاعدتين بلا بيانات تجريبية (+ عميل «كاناري العزل»، انظر §6)، يستورد الـ workflows، ويشغّل Caddy (TLS تلقائي).
- **فوراً بعد أول تثبيت:** احفظ نسخة مشفّرة **خارج السيرفر** من `deploy/.env` و`deploy/.secrets/broker_secrets.json` (فيه المفتاح الرئيسي KEK). بدونهما لا تُفك أسرار vault حتى لو سلمت النسخ الاحتياطية.

## 2) إضافة عميل
```
export PG_CONTAINER=central-stg-pg BROKER_NETWORK=central-stg_backend BROKER_IMAGE=central-broker:prod ENV_FILE=deploy/.env TENANT_DB=central
TENANT_BOT_TOKEN=... TENANT_META_TOKEN=... python3 ops/add-tenant.py --slug acme --name "اسم العميل" --features meta,schedule \
   --owner <TG_ID> --meta-user <fb_user_id> --meta-ad-account act_123 --page <page_id> --set-webhook
deploy/run-readiness.sh        # مرتين: الأولى تسجّل الفحوصات، الثانية تُرقّي READY إن نجحت الـ 15
```
`--set-webhook` يضبط webhook تيليجرام عبر الـ Broker (بادئة مقيَّدة بـ `BROKER_WEBHOOK_URL_PREFIX`) ويتحقق بـ getWebhookInfo؛ **فحص R03 يشترط webhook مضبوطاً** فبدونه لا يصير العميل READY. لإعادة الضبط/الفحص/الحذف: `deploy/set-webhook.sh <slug> [set|info|delete]`. (الجاهزية تعمل تلقائياً كل 6 ساعات أيضاً.) التوكنات من متغيرات بيئة أو إدخال مخفي، **لا تُكتب بالدردشة ولا كوسائط**.

## 3) المهام الدورية (`/etc/cron.d/central`، السجلات `/var/log/central/`)
| المهمة | التوقيت | الغرض |
|---|---|---|
| `cron/purge.sh` | كل 10 د | حذف فعلي لبيانات تنفيذ n8n (فيها نص رسائل المستخدمين) |
| `cron/maintenance.sh` | يومياً 03:17 | أقسام التقارير/الأخطاء للأشهر القادمة + فحص صحتها (يفشل إن وُجد خلل) |
| `backup.sh` | يومياً 02:23 | نسخة مشفّرة GPG (محلية 14 يوماً + رفع rclone إن ضُبط `RCLONE_REMOTE`) |
| `restore-drill.sh` | أحد 04:41 | يستعيد أحدث نسخة لقاعدتين مؤقتتين ويقارن العدّادات ثم يحذفهما |
لا توجد قناة تنبيه داخلية بعد: ضع `PING_MAINT/PING_PURGE/PING_BACKUP/PING_DRILL=<رابط healthchecks>` بـ `deploy/.env` فتنبّهك الخدمة إذا توقفت الإشارات.

## 4) الاستعادة على سيرفر جديد
1. سيرفر جديد + `server-setup.sh` + انسخ `deploy/.env` و`deploy/.secrets/` من نسختك الخارجية (**KEK نفسه**).
2. `deploy/bootstrap.sh --mock` (ينشئ قاعدة فارغة)، ثم احذف القاعدتين الفارغتين واستعد: `gpg -d central.dump.gpg | docker exec -i <pg> pg_restore -U postgres -C -d postgres` (وكذلك vault)، ثم أعد `bootstrap.sh` (يعيد ضبط كلمات مرور حسابات الخدمة).
3. `deploy/restore-drill.sh` للتحقق، ثم `docker compose ... up -d`.

## 5) الصيانة
- تحديث الـ workflows: `git pull && deploy/bootstrap.sh --mock` (آمن للتكرار؛ يعيد الاستيراد والنشر).
- تدوير مفتاح Broker/توكن: عبر `ops/vault_put.py` (نسخة جديدة تُبطل القديمة).
- فحص ثغرات الصور: `deploy/scan-images.sh` قبل كل نشر وشهرياً.
- لا محرر n8n (معطّل) ولا منفذ لـ n8n/Postgres/Broker: الإدارة عبر `docker exec`/CLI فقط.

## 6) ملاحظات تصميم مهمة
- **كاناري العزل:** فحص R10 يحتاج حساباً إعلانياً لعميل **آخر**. على سيرفر بعميل واحد كان R10=unknown فلا يترقّى أحد. لذلك `deploy/canary.sql` ينشئ عميلاً بلا بوت/مالك بحسابين تركيبيين؛ الفحص يمرّ بنفس فحص الملكية بقاعدة البيانات (لا منصة). لا يدخل التقارير ولا التنبيهات (حالته TESTING).
- الشبكات: `backend` (internal، بلا إنترنت) لـ Postgres/n8n/Broker؛ `egress` للـ Broker فقط؛ `edge` لـ Caddy. n8n **بلا** وصول للإنترنت.
- Caddy يمرّر `POST /webhook/tg-ingress` فقط (حد 256KB)؛ كل ما عداه 404.

## 7) غير مغطّى بعد (مفتوح بصراحة)
- **سيرفر حقيقي + Let's Encrypt حقيقي + rclone/B2**: غير مجرَّب (لا سيرفر/حساب).
- **فحص ثغرات الصور (Trivy):** السكربت جاهز، لم يُشغَّل (الصندوق يحجب ghcr.io).
- **`setWebhook`:** أُضيفت عمليات إدارية بالـ Broker (مفتاح admin فقط) واختُبرت على منصة وهمية (121 اختبار + 16/16 mutation)؛ **لم تُجرَّب على Telegram الحقيقي** (P8: سلوك الأخطاء والحدود الفعلي).
- **حد معدل (rate limit) على الـ webhook** (يحتاج إضافة لـ Caddy أو قاعدة جدار)؛ حالياً فقط حد الحجم والمهل.
- **P5 الكامل على staging:** سكربتات P5 مربوطة بأسماء بيئة P4؛ على staging يُشغَّل بدلها: add-tenant + جاهزية + webhook عبر TLS + نسخ/استعادة (كما جُرِّب محلياً). إعادة P5 الكاملة تحتاج تهيئة السكربتات (عمل منفصل).
- مسار فشل `maintenance.sh` (قسم افتراضي غير فارغ) لم يُختبر بحقن خلل.
- لا تنبيه داخلي بفشل cron (مراقبة خارجية فقط).
