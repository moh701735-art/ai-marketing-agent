#!/usr/bin/env bash
# تهيئة سيرفر Ubuntu 22.04/24.04 جديد (تشغيل مرة واحدة كـ root). لا يُشغَّل إلا على سيرفر staging/prod الجديد المخصّص للمركزي.
# يفعل: تحديثات أمنية تلقائية، جدار ناري (22/80/443 فقط)، fail2ban، SSH بالمفاتيح فقط (إن وُجد مفتاح)، Docker من مستودعات Ubuntu، مجلد السجلات، cron.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "شغّله كـ root"; exit 1; }
export DEBIAN_FRONTEND=noninteractive
PKGS="ufw fail2ban unattended-upgrades gnupg rclone ca-certificates curl python3 openssl"
# بعض صور المزوّد تأتي بـ Docker CE (containerd.io) فيتعارض مع docker.io: لا نثبّته إن كان docker موجوداً
command -v docker >/dev/null 2>&1 || PKGS="$PKGS docker.io docker-compose-v2"
apt-get update -qq && apt-get install -y -qq $PKGS >/dev/null
dpkg-reconfigure -f noninteractive unattended-upgrades >/dev/null 2>&1 || true
ufw --force reset >/dev/null; ufw default deny incoming >/dev/null; ufw default allow outgoing >/dev/null
ufw limit 22/tcp >/dev/null; ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; ufw --force enable >/dev/null
systemctl enable --now fail2ban docker >/dev/null 2>&1
if [ -s /root/.ssh/authorized_keys ]; then
  sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/; s/^#\?PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
  systemctl reload ssh 2>/dev/null || systemctl reload sshd
  echo "SSH: كلمة المرور معطّلة (مفتاح فقط)"
else echo "تحذير: لا يوجد /root/.ssh/authorized_keys، تُرك SSH كما هو. أضف مفتاحك ثم عطّل كلمة المرور يدوياً."; fi
mkdir -p /var/log/central /opt/central
[ -d /opt/central/deploy ] && install -m 644 /opt/central/deploy/crontab /etc/cron.d/central
echo "تم. المنافذ المفتوحة: 22 (محدود المعدل) و80 و443. انسخ المستودع إلى /opt/central ثم شغّل deploy/bootstrap.sh --mock (P7)."
