#!/usr/bin/env bash
# فحص ثغرات صور الحاويات (OS + حزم) بـ Trivy. يُشغَّل على السيرفر/جهاز له وصول لـ ghcr.io (لم يكن متاحاً بصندوق التطوير: الوكيل يحجب ghcr.io وDocker Hub يعطي 429).
# يفشل (1) إن وُجدت ثغرة HIGH/CRITICAL لها إصلاح. شغّله قبل كل نشر وشهرياً.
set -euo pipefail
. "$(dirname "$0")/cron/lib.sh"
T="docker run --rm -v /var/run/docker.sock:/var/run/docker.sock -v trivy-cache:/root/.cache ghcr.io/aquasecurity/trivy:latest image --severity HIGH,CRITICAL --ignore-unfixed --exit-code 1 --quiet"
rc=0
for img in "central-broker:${BROKER_TAG:-prod}" "$(docker inspect "$PGC" --format '{{.Config.Image}}')" "$(docker inspect "$N8NC" --format '{{.Config.Image}}')" "$(docker inspect "${COMPOSE_PROJECT_NAME}-caddy" --format '{{.Config.Image}}')"; do
  echo "── $img"; $T "$img" || rc=1
done
[ $rc = 0 ] && log "images clean (HIGH/CRITICAL with fix)" || log "FAIL: vulnerable images"; exit $rc
