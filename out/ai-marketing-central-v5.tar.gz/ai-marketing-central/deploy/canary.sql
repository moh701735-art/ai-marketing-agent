-- عميل "كاناري العزل": فحص الجاهزية R10 يختبر أن حساب العميل لا يستطيع قراءة حساب إعلاني يخص **عميلاً آخر**، فيحتاج وجود عميل آخر.
-- على سيرفر جديد بعميل واحد لا يوجد "آخر" فيبقى R10=unknown ولا يصير أول عميل READY أبداً. هذا العميل صفّ حقيقي بالقاعدة (حالته TESTING فلا يدخل التقارير/التنبيهات
-- ولا يُرقّى لأنه بلا بوت/مالك)، وحساباه الإعلانيان أرقام تركيبية. الاختبار يمرّ بنفس فحص الملكية بالـ Broker (قاعدة البيانات)، لا يلمس أي منصة.
-- idempotent: آمن للتكرار. لا يحوي أسراراً.
\set ON_ERROR_STOP on
\set T '\'c4a4a400-0000-0000-0000-000000000001\''
INSERT INTO core.tenants (tenant_id, slug, display_name, status, features)
  VALUES (:T, 'isolation-canary', 'Isolation canary (R10)', 'CONFIGURATION_REQUIRED', '{"meta":true,"tiktok":true}') ON CONFLICT DO NOTHING;
INSERT INTO core.config_versions (tenant_id, version, config, author) VALUES (:T, 1, '{"canary":true}', 'bootstrap') ON CONFLICT DO NOTHING;
UPDATE core.tenants SET active_config_version = 1, status = 'TESTING' WHERE tenant_id = :T AND status = 'CONFIGURATION_REQUIRED';
INSERT INTO core.platform_connections (connection_id, tenant_id, platform, auth_mode, external_user_id, secret_ref) VALUES
  ('c4a4a400-0000-0000-0000-0000000000a1', :T, 'meta', 'oauth_user', 'canary_meta', 'ref-canary-meta'),
  ('c4a4a400-0000-0000-0000-0000000000a2', :T, 'tiktok', 'tiktok_oauth', 'canary_tt', 'ref-canary-tt') ON CONFLICT DO NOTHING;
INSERT INTO core.ad_accounts (tenant_id, platform, external_id, connection_id, name) VALUES
  (:T, 'meta', 'act_999999999999999', 'c4a4a400-0000-0000-0000-0000000000a1', 'canary meta'),
  (:T, 'tiktok', '9999999999999999999', 'c4a4a400-0000-0000-0000-0000000000a2', 'canary tiktok') ON CONFLICT DO NOTHING;
SELECT api_admin.set_subscription(:T::uuid, 'canary', 'active', now() + interval '3650 days', 3, '{}'::jsonb);
