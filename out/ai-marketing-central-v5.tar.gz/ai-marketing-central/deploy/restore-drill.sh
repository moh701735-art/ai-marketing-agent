#!/usr/bin/env bash
# تمرين استعادة: يفك أحدث نسخة (أو المسار الممرَّر) إلى قاعدتين مؤقتتين على نفس Postgres، يقارن العدّادات والبصمات بما سُجّل وقت النسخ، ثم يحذفهما.
# لا يمس القاعدتين الحيّتين. يفشل (1) عند أي اختلاف.
set -euo pipefail
. "$(dirname "$0")/cron/lib.sh"
D="${1:-$(ls -1d deploy/backups/*/ 2>/dev/null | tail -1)}"; D="${D%/}"; [ -d "$D" ] || { echo "لا توجد نسخة"; exit 1; }
( cd "$D" && sha256sum -c SHA256SUMS >/dev/null ) || { log "FAIL checksum"; exit 1; }
DEC() { gpg --batch --pinentry-mode loopback --passphrase-file deploy/.secrets/backup.pass -d "$1"; }
RC="restore_chk_central"; RV="restore_chk_vault"
psql_c -d postgres -c "DROP DATABASE IF EXISTS $RC" -c "DROP DATABASE IF EXISTS $RV" -c "CREATE DATABASE $RC" -c "CREATE DATABASE $RV" >/dev/null
DEC "$D/$DB_CENTRAL.dump.gpg" | docker exec -i "$PGC" pg_restore -U postgres -d "$RC" --exit-on-error
DEC "$D/$DB_VAULT.dump.gpg"   | docker exec -i "$PGC" pg_restore -U postgres -d "$RV" --exit-on-error
GOT_T=$(psql_c -d "$RC" -c "select count(*) from core.tenants"); GOT_S=$(psql_c -d "$RV" -c "select count(*) from vault.secrets")
WANT_T=$(awk -F'|' '$1=="tenants"{print $2}' "$D/counts.txt"); WANT_S=$(awk -F'|' '$1=="secrets"{print $2}' "$D/counts.txt")
psql_c -d postgres -c "DROP DATABASE $RC" -c "DROP DATABASE $RV" >/dev/null
if [ "$GOT_T" = "$WANT_T" ] && [ "$GOT_S" = "$WANT_S" ]; then log "restore drill OK ($D): tenants=$GOT_T secrets=$GOT_S"; ping_ok DRILL
else log "FAIL restore drill: tenants $GOT_T/$WANT_T secrets $GOT_S/$WANT_S"; exit 1; fi
