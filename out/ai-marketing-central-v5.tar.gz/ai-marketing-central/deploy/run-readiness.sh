#!/usr/bin/env bash
# يشغّل منفِّذ الجاهزية فوراً (يعمل تلقائياً كل 6 ساعات). شغّله مرتين بعد add-tenant: الأولى تسجّل الفحوصات، والثانية ترقّي READY إن نجحت كلها.
set -euo pipefail
. "$(dirname "$0")/cron/lib.sh"
for i in 1 2; do
  docker exec -e N8N_RUNNERS_BROKER_PORT=5690 -e N8N_PORT=5690 "$N8NC" n8n execute --id=wfReadiness00001 2>&1 | grep -c '"status": "success"' | sed "s/^/run$i success: /"
done
psql_c -d "$DB_CENTRAL" -F' ' -c "SELECT slug, status FROM core.tenants ORDER BY slug"
