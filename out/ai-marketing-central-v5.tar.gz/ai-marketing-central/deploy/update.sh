#!/usr/bin/env bash
# تطبيق تحديث الكود على السيرفر: يعيد بناء الـ Broker ويعيد تشغيله، ثم يعيد بناء/استيراد/نشر كل الـ workflows ويعيد تشغيل n8n.
# لا يمسّ القواعد ولا الأسرار ولا .env. آمن لإعادة التشغيل.   الاستعمال: bash deploy/update.sh
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; . deploy/.env; set +a
DC="docker compose --env-file deploy/.env -f deploy/docker-compose.prod.yml"
N="docker exec ${COMPOSE_PROJECT_NAME}-n8n n8n"
CA=""; [ -f /root/.ccr/ca-bundle.crt ] && CA="--secret id=ca,src=/root/.ccr/ca-bundle.crt"
echo "── ترقية القاعدة (قواعد المراقبة، آمنة لإعادة التشغيل)"; docker exec -i "${COMPOSE_PROJECT_NAME}-pg" psql -U postgres -d "${DB_CENTRAL:-central}" -q -v ON_ERROR_STOP=1 < db/60_rules.sql >/dev/null
echo "── بناء Broker"; DOCKER_BUILDKIT=1 docker build -q $CA -t "central-broker:${BROKER_TAG:-prod}" broker/ >/dev/null
echo "── إعادة تشغيل Broker"; $DC up -d --force-recreate broker >/dev/null
echo "── بناء ونشر الـ workflows"
python3 n8n/build.py >/dev/null
$N import:workflow --separate --input=/import/workflows/ 2>&1 | tail -1
for id in $(ls n8n/workflows/*.json | xargs -n1 python3 -c "import json,sys;d=json.load(open(sys.argv[1]));print(d['id'])" | grep -v wfSelfTestErr0001); do $N publish:workflow --id="$id" >/dev/null 2>&1 || true; done
docker restart "${COMPOSE_PROJECT_NAME}-n8n" >/dev/null
for i in $(seq 1 60); do docker exec "${COMPOSE_PROJECT_NAME}-n8n" wget -qO- http://localhost:5678/healthz >/dev/null 2>&1 && break; sleep 2; done
sleep 8
echo "تم. Broker + n8n محدّثان."
