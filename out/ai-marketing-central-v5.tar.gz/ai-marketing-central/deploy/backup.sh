#!/usr/bin/env bash
# نسخة احتياطية مشفّرة (GPG AES256) لقاعدتي central وvault + الأدوار. يحتفظ محلياً بـ KEEP_DAYS (افتراضي 14) ويرفع اختيارياً إن ضُبط RCLONE_REMOTE (مثل b2:bucket/central).
# تنبيه: المفتاح الرئيسي KEK (deploy/.secrets/broker_secrets.json) و.env **لا يدخلان النسخة عمداً**: احفظ نسخة منهما مشفّرة خارج السيرفر وإلا لا تُفك أسرار vault.
set -euo pipefail
. "$(dirname "$0")/cron/lib.sh"
D="${1:-deploy/backups/$(date -u +%Y%m%dT%H%M%SZ)}"; umask 077; mkdir -p "$D"
ENC() { gpg --batch --yes --pinentry-mode loopback --passphrase-file deploy/.secrets/backup.pass --symmetric --cipher-algo AES256 -o "$1"; }
docker exec -i "$PGC" pg_dumpall -U postgres --globals-only --no-role-passwords | grep -vE '^(CREATE|ALTER) ROLE postgres' | ENC "$D/globals.sql.gpg"
for db in "$DB_CENTRAL" "$DB_VAULT"; do docker exec -i "$PGC" pg_dump -U postgres -Fc "$db" | ENC "$D/$db.dump.gpg"; done
psql_c -d "$DB_CENTRAL" -c "select 'tenants', count(*) from core.tenants" -F'|' > "$D/counts.txt"
psql_c -d "$DB_VAULT" -c "select 'secrets', count(*) from vault.secrets" -F'|' >> "$D/counts.txt"
( cd "$D" && sha256sum *.gpg counts.txt > SHA256SUMS )
if [ -n "${RCLONE_REMOTE:-}" ]; then rclone copy "$D" "$RCLONE_REMOTE/$(basename "$D")" --quiet; log "uploaded to $RCLONE_REMOTE"; fi
find deploy/backups -mindepth 1 -maxdepth 1 -type d -mtime +"${KEEP_DAYS:-14}" -exec rm -rf {} + 2>/dev/null || true
log "backup ok: $D ($(du -sh "$D" | cut -f1))"; ping_ok BACKUP
