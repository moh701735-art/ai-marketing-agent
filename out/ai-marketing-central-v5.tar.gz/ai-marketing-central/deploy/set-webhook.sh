#!/usr/bin/env bash
# إدارة webhook تيليجرام لعميل: deploy/set-webhook.sh <slug> [set|info|delete]   (الافتراضي info)
# set يقرأ bot_public_id وسر الـ webhook من .secrets/webhook-<slug>.txt (كتبه add-tenant) ولا يطبعه. التوكن لا يخرج من الـ vault.
set -euo pipefail
. "$(dirname "$0")/cron/lib.sh"
SLUG="${1:?usage: set-webhook.sh <slug> [set|info|delete]}"; ACT="${2:-info}"
case "$ACT" in set) A=set-webhook;; info) A=webhook-info;; delete) A=delete-webhook;; *) echo "action: set|info|delete"; exit 1;; esac
ROW=$(psql_c -d "$DB_CENTRAL" -F'|' -c "select t.tenant_id, b.secret_ref from core.tenants t join core.bots b using(tenant_id) where t.slug='$SLUG' and b.status='active'")
[ -n "$ROW" ] || { echo "لا عميل/بوت نشط بهذا الاسم"; exit 1; }
TID=${ROW%%|*}; REF=${ROW##*|}
PAY=$(python3 - "$A" "$TID" "$REF" "$DOMAIN" "$SLUG" <<'PY'
import json, sys, pathlib
a, tid, ref, domain, slug = sys.argv[1:6]
d = {"action": a, "tenant_id": tid, "secret_ref": ref}
if a == "set-webhook":
    kv = dict(l.split("=", 1) for l in pathlib.Path(f".secrets/webhook-{slug}.txt").read_text().split() if "=" in l)
    d.update(url=f"https://{domain}/webhook/tg-ingress?bot={kv['bot_public_id']}", secret_token=kv["webhook_secret_token"])
print(json.dumps(d))
PY
)
printf '%s' "$PAY" | docker run --rm -i --network "${COMPOSE_PROJECT_NAME}_backend" -e BROKER_ADMIN_KEY \
  -v "$ROOT/ops/telegram_admin.py:/w/t.py:ro" -v "$ROOT/broker/hmac_auth.py:/w/hmac_auth.py:ro" -w /w --entrypoint python "central-broker:${BROKER_TAG:-prod}" t.py
[ "$ACT" = set ] && psql_c -d "$DB_CENTRAL" -c "UPDATE core.bots SET webhook_set_at = now() WHERE tenant_id='$TID' AND status='active'" >/dev/null || true
