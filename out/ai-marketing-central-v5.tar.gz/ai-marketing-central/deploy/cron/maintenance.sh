#!/usr/bin/env bash
# يومي: يضمن أقسام الأشهر القادمة (تقارير/أخطاء) ويتحقق من صحتها؛ يفشل (خروج 1) إن وُجد خلل أو صفوف بالقسم الافتراضي.
set -euo pipefail
. "$(dirname "$0")/lib.sh"
psql_c -d "$DB_CENTRAL" -c "SET ROLE app_ops; SELECT api_admin.ensure_partitions(3);" >/dev/null
BAD=$(psql_c -d "$DB_CENTRAL" -F'|' -c "SET ROLE app_ops; SELECT * FROM api_admin.partition_health();" | awk -F'|' '$2=="f"')
if [ -n "$BAD" ]; then log "FAIL partition_health: $BAD"; exit 1; fi
log "ok partitions"; ping_ok MAINT
