#!/usr/bin/env bash
# كل 10 دقائق: حذف فعلي لبيانات تنفيذ n8n (فيها نص رسائل المستخدمين). انظر تقرير P5/P6.
set -euo pipefail
. "$(dirname "$0")/lib.sh"
N8N_CONTAINER="$N8NC" ops/p4-purge-n8n-executions.sh | sed 's/^/purge: /'; ping_ok PURGE
