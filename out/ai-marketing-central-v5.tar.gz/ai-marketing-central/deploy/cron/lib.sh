# مشترك بين سكربتات الصيانة: يحمّل deploy/.env ويعرّف أسماء الحاويات وإشارة "نجحت" (ping) اختيارية لخدمة مراقبة (Uptime).
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"; cd "$ROOT"
set -a; . deploy/.env; set +a
PGC="${COMPOSE_PROJECT_NAME}-pg"; N8NC="${COMPOSE_PROJECT_NAME}-n8n"
psql_c() { docker exec -i "$PGC" psql -U postgres -q -At -v ON_ERROR_STOP=1 "$@"; }
# PING_<JOB> بـ deploy/.env (رابط healthchecks.io أو مثله). إذا توقفت الإشارات تنبّهك الخدمة (لا قناة تنبيه داخلية بعد).
ping_ok() { local v="PING_$1"; [ -n "${!v:-}" ] && curl -fsS -m 10 -o /dev/null "${!v}" || true; }
log() { echo "$(date -u +%FT%TZ) $*"; }
