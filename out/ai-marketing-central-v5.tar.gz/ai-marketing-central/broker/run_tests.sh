#!/usr/bin/env bash
# يشغّل اختبارات الـ Broker داخل venv معزول (حزمة cryptography من pip) ويحفظ السجل في docs/results/.
set -euo pipefail
cd "$(dirname "$0")"
V=$("$PWD/../scripts/ensure_venv.sh")
LOG="../docs/results/broker-tests-$(date -u +%Y%m%dT%H%M%SZ).log"
"$V/bin/python" -m unittest tests.test_broker tests.test_unit -v 2>&1 | tee "$LOG"
echo "log: $LOG"
