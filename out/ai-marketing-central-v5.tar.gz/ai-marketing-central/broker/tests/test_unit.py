"""اختبارات وحدة (بدون قاعدة بيانات): تصنيف الأخطاء، المعدّل، القاطع، التأخير، الكتالوج، حماية المنصات الحقيقية، فحص HMAC."""
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import hmac_auth, redact
from app import catalog, classify
from app.config import Settings
from app.resilience import Breaker, TokenBucket, backoff_delay


def B(d):
    return json.dumps(d).encode()


class Classify(unittest.TestCase):
    def setUp(self):
        redact.KNOWN._d.clear()

    def test_meta_codes(self):
        cases = [(400, {"error": {"code": 190, "message": "x"}}, "auth_expired"), (400, {"error": {"code": 102}}, "auth_expired"),
                 (400, {"error": {"code": 17}}, "rate_limited"), (400, {"error": {"code": 80004}}, "rate_limited"),
                 (500, {"error": {"code": 2}}, "transient"), (403, {"error": {"code": 200}}, "permission_denied"),
                 (400, {"error": {"code": 368}}, "policy_rejected"), (400, {"error": {"code": 100}}, "bad_request"),
                 (401, {}, "auth_expired"), (429, {}, "rate_limited"), (503, {}, "transient"), (404, {}, "not_found")]
        for st, body, want in cases:
            e = classify.classify("meta", st, B(body))
            self.assertEqual(e.cls, want, (st, body))
            self.assertEqual(e.retryable, want in ("rate_limited", "transient"))

    def test_meta_success(self):
        self.assertIsNone(classify.classify("meta", 200, B({"data": []})))

    def test_tiktok_codes(self):
        for code, want in [(40105, "auth_expired"), (40104, "auth_expired"), (40100, "rate_limited"), (50000, "transient"), (40001, "bad_request"), (40999, "bad_request")]:
            self.assertEqual(classify.classify("tiktok", 200, B({"code": code, "message": "m"})).cls, want, code)
        self.assertIsNone(classify.classify("tiktok", 200, B({"code": 0, "message": "OK", "data": {}})))
        self.assertEqual(classify.classify("tiktok", 502, b"<html>").cls, "transient")

    def test_non_json_body_and_message_redacted(self):
        e = classify.classify("meta", 400, B({"error": {"code": 100, "message": "bad token EAAGm0PX4ZCpsBOxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx here"}}))  # scan:allow
        self.assertNotIn("EAAGm0PX4ZCpsBO", e.message)
        self.assertEqual(classify.classify("meta", 500, b"not json").cls, "transient")


class Resilience(unittest.TestCase):
    def test_bucket(self):
        t = [0.0]
        b = TokenBucket(rate=1, burst=2, clock=lambda: t[0])
        self.assertTrue(b.allow("k")); self.assertTrue(b.allow("k")); self.assertFalse(b.allow("k"))
        t[0] = 1.0
        self.assertTrue(b.allow("k")); self.assertFalse(b.allow("k"))
        self.assertTrue(b.allow("other"))                      # مفتاح آخر (عميل آخر) مستقل

    def test_breaker_cycle(self):
        t = [0.0]
        br = Breaker(3, 30, clock=lambda: t[0])
        for _ in range(2):
            br.failure("k")
        self.assertTrue(br.allow("k"))
        br.failure("k")
        self.assertFalse(br.allow("k")); self.assertEqual(br.state("k"), "open")
        t[0] = 31
        self.assertTrue(br.allow("k"))                         # محاولة واحدة (half-open)
        self.assertFalse(br.allow("k"))                        # لا ثانية قبل نتيجتها
        br.failure("k")                                        # فشلت: يعود مفتوحاً من جديد
        self.assertFalse(br.allow("k"))
        t[0] = 70
        self.assertTrue(br.allow("k")); br.success("k")
        self.assertTrue(br.allow("k")); self.assertEqual(br.state("k"), "closed")
        self.assertTrue(br.allow("other-tenant"))

    def test_backoff(self):
        self.assertEqual(backoff_delay(0, 0.2, 2.0, lambda: 1.0), 0.2)
        self.assertEqual(backoff_delay(1, 0.2, 2.0, lambda: 1.0), 0.4)
        self.assertEqual(backoff_delay(10, 0.2, 2.0, lambda: 1.0), 2.0)        # سقف
        self.assertEqual(backoff_delay(0, 0.2, 2.0, lambda: 0.0), 0.0)         # jitter
        self.assertEqual(backoff_delay(0, 0.2, 2.0, lambda: 0.0, retry_after=3), 3.0)
        self.assertEqual(backoff_delay(0, 0.2, 2.0, lambda: 0.0, retry_after=9999), 10.0)


class Catalog(unittest.TestCase):
    def test_valid_and_forced(self):
        op = catalog.OPS["meta.create_campaign"]
        out = catalog.validate(op, {"name": "حملة اختبار", "objective": "OUTCOME_TRAFFIC"})
        self.assertEqual(out["status"], "PAUSED")
        self.assertEqual(catalog.validate(catalog.OPS["tiktok.create_campaign"], {"campaign_name": "x", "objective_type": "TRAFFIC"})["operation_status"], "DISABLE")

    def test_cannot_override_forced(self):
        with self.assertRaises(catalog.Invalid):
            catalog.validate(catalog.OPS["meta.create_campaign"], {"name": "x", "objective": "OUTCOME_TRAFFIC", "status": "ACTIVE"})
        with self.assertRaises(catalog.Invalid):
            catalog.validate(catalog.OPS["tiktok.create_campaign"], {"campaign_name": "x", "objective_type": "TRAFFIC", "operation_status": "ENABLE"})

    def test_rejections(self):
        bad = [("meta.read_campaigns", {"limit": 0}), ("meta.read_campaigns", {"limit": True}), ("meta.read_campaigns", {"limit": "5"}),
               ("meta.read_campaigns", {"fields": "id;DROP"}), ("meta.read_campaigns", {"after": "a b"}), ("meta.read_campaigns", {"url": "http://evil"}),
               ("meta.read_campaigns", {"effective_status": ["HACKED"]}), ("meta.create_campaign", {"name": "x\nInjected: 1", "objective": "OUTCOME_TRAFFIC"}),
               ("meta.create_campaign", {"name": "", "objective": "OUTCOME_TRAFFIC"}), ("meta.create_campaign", {"objective": "OUTCOME_TRAFFIC"}),
               ("tiktok.read_report", {"report_type": "BASIC", "data_level": "AUCTION_AD", "dimensions": ["ad_id"], "metrics": ["spend"], "start_date": "2026/01/01", "end_date": "2026-01-02"}),
               ("tiktok.create_campaign", {"campaign_name": "x", "objective_type": "TRAFFIC", "budget": 0})]
        for name, p in bad:
            with self.assertRaises(catalog.Invalid, msg=(name, p)):
                catalog.validate(catalog.OPS[name], p)

    def test_ad_account_regex(self):
        for ok in ("act_123456789", "123456789"):
            self.assertTrue(catalog.AD_ACCOUNT_RE.fullmatch(ok))
        for bad in ("../x", "act_1/campaigns", "a b", "x?y=1", "x#", "a\nb", "act_1\n", "act_\u0661\u0662", "act_１２", "", "a" * 41, "%2e%2e"):
            self.assertFalse(catalog.AD_ACCOUNT_RE.fullmatch(bad), bad)

    def test_no_op_accepts_url_host_or_header_params(self):
        for op in catalog.OPS.values():
            self.assertFalse({"url", "host", "headers", "base_url", "path", "access_token", "token"} & set(op.params), op.name)


class RealPlatformGuard(unittest.TestCase):
    def mk(self, urls, allow=False):
        return Settings(kek=os.urandom(32), hmac_keys={"k": (os.urandom(32), "runtime")}, central_dsn="x", vault_dsn="y", base_urls=urls, allow_real_platforms=allow)

    def test_blocks_real_hosts(self):
        for host in ("https://graph.facebook.com/v21.0", "https://business-api.tiktok.com/open_api/v1.3", "https://api.telegram.org", "https://GRAPH.facebook.com"):
            with self.assertRaises(ValueError):
                self.mk({"meta": host}).validate()

    def test_allows_mock_and_explicit_flag(self):
        self.mk({"meta": "http://mock-meta:8080/v1"}).validate()
        self.mk({"meta": "https://graph.facebook.com/v21.0"}, allow=True).validate()

    def test_requires_runtime_key_and_strong_keys(self):
        with self.assertRaises(ValueError):
            Settings(kek=os.urandom(32), hmac_keys={"k": (os.urandom(32), "admin")}, central_dsn="x", vault_dsn="y").validate()
        with self.assertRaises(ValueError):
            Settings(kek=os.urandom(32), hmac_keys={"k": (b"short", "runtime")}, central_dsn="x", vault_dsn="y").validate()


class HmacCheck(unittest.TestCase):
    def test_check(self):
        k, body = os.urandom(32), b"{}"
        n = "n" * 16
        s = hmac_auth.sign(k, body, 1000, n)
        self.assertIsNone(hmac_auth.check(k, body, 1000, n, s, now=1010))
        self.assertEqual(hmac_auth.check(k, body, 1000, n, s, now=1100), "stale_timestamp")
        self.assertEqual(hmac_auth.check(k, body, "abc", n, s, now=1010), "bad_timestamp")
        self.assertEqual(hmac_auth.check(k, body, 1000, "short", s, now=1010), "bad_nonce")
        self.assertEqual(hmac_auth.check(k, b"{ }", 1000, n, s, now=1010), "bad_signature")
        self.assertEqual(hmac_auth.check(k, body, 1000, n, "", now=1010), "bad_signature")
        self.assertEqual(hmac_auth.check(k, body, 1000, n, None, now=1010), "bad_signature")


if __name__ == "__main__":
    unittest.main()
