"""عمليات تيليجرام الإدارية (setWebhook/getWebhookInfo/deleteWebhook): مفتاح admin فقط، رابط مقيَّد بالبادئة، لا تسريب للتوكن أو secret_token."""
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import helpers as H
from test_integration import SKIP

PREFIX = "https://bot.example.test/webhook/tg-ingress?bot="
BOT_PUBLIC = "A9ilW4a4XNJN-1PtAiX9ddEC"
SECRET = "wh-" + "s" * 40


class WBase(unittest.IsolatedAsyncioTestCase):
    prefix = PREFIX

    async def asyncSetUp(self):
        H.reset_state()
        self.logcap = H.LogCapture()
        import logging
        logging.getLogger().addHandler(self.logcap); logging.getLogger().setLevel(logging.DEBUG)
        self.env = await H.make_env(H.make_settings(webhook_url_prefix=self.prefix))
        self.app, self.cl, self.up, self.sleeps, _ = self.env

    async def asyncTearDown(self):
        import logging, redact
        redact.KNOWN._d.clear()
        logging.getLogger().removeHandler(self.logcap)
        await H.close_env(self.env)

    async def adm(self, action, payload, **kw):
        return await self.cl.post(f"/v1/admin/telegram/{action}", payload, key=H.ADMIN_KEY, key_id="ops-admin", **kw)

    def body(self, tenant=H.A, ref="ref-bot-a", **extra):
        return {"tenant_id": tenant, "secret_ref": ref, **extra}


@SKIP
class WebhookAdmin(WBase):
    async def test_WH01_set_webhook_ok_forced_params_no_leak(self):
        self.up.push((200, {"ok": True, "result": True, "description": "Webhook was set"}))
        r = await self.adm("set-webhook", self.body(url=PREFIX + BOT_PUBLIC, secret_token=SECRET))
        self.assertEqual(r.status_code, 200, r.text); self.assertTrue(r.json()["ok"], r.text)
        c = self.up.calls[0]
        self.assertTrue(str(c.url).endswith("/bot" + H.FAKE["ref-bot-a"] + "/setWebhook"))
        sent = json.loads(c.content)
        self.assertEqual(sent["url"], PREFIX + BOT_PUBLIC); self.assertEqual(sent["secret_token"], SECRET)
        self.assertEqual(sent["allowed_updates"], ["message"]); self.assertEqual(sent["max_connections"], 20); self.assertFalse(sent["drop_pending_updates"])
        for s in (H.FAKE["ref-bot-a"], SECRET):
            self.assertNotIn(s, r.text)
        self.assertNotIn(SECRET, "\n".join(self.logcap.lines)); self.assertNotIn(H.FAKE["ref-bot-a"], "\n".join(self.logcap.lines))

    async def test_WH02_runtime_key_cannot_use_admin_endpoint(self):
        r = await self.cl.post("/v1/admin/telegram/set-webhook", self.body(url=PREFIX + BOT_PUBLIC, secret_token=SECRET))
        self.assertEqual(r.status_code, 401); self.assertEqual(self.up.calls, [])

    async def test_WH03_not_callable_via_runtime_call(self):
        for op in ("telegram.set_webhook", "telegram.delete_webhook"):
            r = await self.cl.call(H.get_ctx("A_owner"), "telegram", op, None, {"url": PREFIX + BOT_PUBLIC})
            self.assertEqual(r.status_code, 400, r.text); self.assertEqual(r.json()["error"]["class"], "unknown_op")
        self.assertEqual(self.up.calls, [])

    async def test_WH04_url_must_be_prefix_plus_bot_id(self):
        for bad in ["http://bot.example.test/webhook/tg-ingress?bot=" + BOT_PUBLIC, "https://evil.test/webhook/tg-ingress?bot=" + BOT_PUBLIC,
                    PREFIX + BOT_PUBLIC + "&x=1", PREFIX + BOT_PUBLIC + "/../x", PREFIX, PREFIX + "short", PREFIX + BOT_PUBLIC + "\r\nX: 1",
                    "https://bot.example.test.evil.test/webhook/tg-ingress?bot=" + BOT_PUBLIC, 5, None]:
            r = await self.adm("set-webhook", self.body(url=bad, secret_token=SECRET))
            self.assertEqual(r.status_code, 400, (bad, r.text))
        self.assertEqual(self.up.calls, [])

    async def test_WH05_secret_token_validated(self):
        for bad in ["short", "has space " + "x" * 20, "ü" * 20, "x" * 300, "", None, 12345]:
            r = await self.adm("set-webhook", self.body(url=PREFIX + BOT_PUBLIC, secret_token=bad))
            self.assertEqual(r.status_code, 400, (bad, r.text))
        self.assertEqual(self.up.calls, [])

    async def test_WH06_ref_must_be_this_tenants_bot_token(self):
        r = await self.adm("set-webhook", self.body(ref="ref-a-meta", url=PREFIX + BOT_PUBLIC, secret_token=SECRET))      # ليس توكن بوت
        self.assertEqual(r.status_code, 400, r.text)
        r = await self.adm("set-webhook", self.body(tenant=H.B, ref="ref-bot-a", url=PREFIX + BOT_PUBLIC, secret_token=SECRET))   # مؤشر عميل آخر
        self.assertEqual(r.status_code, 424, r.text)
        self.assertEqual(self.up.calls, [])

    async def test_WH07_prefix_not_configured_disables_set(self):
        await self.asyncTearDown(); self.prefix = ""; await self.asyncSetUp()
        r = await self.adm("set-webhook", self.body(url=PREFIX + BOT_PUBLIC, secret_token=SECRET))
        self.assertEqual(r.status_code, 503, r.text); self.assertEqual(self.up.calls, [])

    async def test_WH08_info_and_delete(self):
        self.up.push((200, {"ok": True, "result": {"url": PREFIX + BOT_PUBLIC, "pending_update_count": 0}}), (200, {"ok": True, "result": True}))
        r = await self.adm("webhook-info", self.body()); self.assertTrue(r.json()["ok"], r.text); self.assertEqual(r.json()["data"]["result"]["pending_update_count"], 0)
        r = await self.adm("delete-webhook", self.body()); self.assertTrue(r.json()["ok"], r.text)
        self.assertTrue(str(self.up.calls[1].url).endswith("/deleteWebhook"))
        r = await self.adm("nope", self.body()); self.assertEqual(r.status_code, 400)

    async def test_WH09_platform_error_is_classified_and_scrubbed(self):
        self.up.push((400, {"ok": False, "error_code": 400, "description": "Bad Request: bad webhook: " + SECRET + " " + H.FAKE["ref-bot-a"]}))
        r = await self.adm("set-webhook", self.body(url=PREFIX + BOT_PUBLIC, secret_token=SECRET))
        self.assertEqual(r.status_code, 200); self.assertFalse(r.json()["ok"])
        for s in (SECRET, H.FAKE["ref-bot-a"]):
            self.assertNotIn(s, r.text)
        self.assertNotIn(SECRET, "\n".join(self.logcap.lines))

    async def test_WH10_unreachable_telegram_is_transient(self):
        import httpx
        self.up.push(httpx.ConnectError("down"), httpx.ConnectError("down"), httpx.ConnectError("down"))
        r = await self.adm("set-webhook", self.body(url=PREFIX + BOT_PUBLIC, secret_token=SECRET))
        self.assertEqual(r.status_code, 200); self.assertEqual(r.json()["error"]["class"], "transient")


if __name__ == "__main__":
    unittest.main()
