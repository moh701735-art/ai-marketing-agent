"""تكامل: خدمة الـ Broker الحقيقية + قاعدتان حقيقيتان (مركزية + vault) + منصة محاكاة. بيانات وهمية فقط."""
import asyncio
import json
import logging
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import httpx
import helpers as H
import envelope

SKIP = unittest.skipUnless(H.HAVE_DB, "needs the Postgres test environment (ops/run-broker-tests.sh)")
IDEM = lambda s: ("idem-" + s).ljust(24, "x")
OK_DATA = (200, {"data": [{"id": "1"}]})
TT_OK = (200, {"code": 0, "message": "OK", "data": {"list": []}})


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        H.reset_state()
        self.ctx = {w: H.get_ctx(w) for w in H.USERS}
        self.logcap = H.LogCapture()
        logging.getLogger().addHandler(self.logcap)
        logging.getLogger().setLevel(logging.DEBUG)
        self.env = await H.make_env()
        self.app, self.cl, self.up, self.sleeps, _ = self.env

    async def asyncTearDown(self):
        import redact
        redact.KNOWN._d.clear()               # القيم الحية في الذاكرة خاصة بالعملية؛ ننظّفها بين الاختبارات حتى لا تتداخل
        logging.getLogger().removeHandler(self.logcap)
        await H.close_env(self.env)

    def calls_to(self, needle):
        return [c for c in self.up.calls if needle in str(c.url)]


@SKIP
class Auth(Base):
    async def test_IT01_signed_call_ok_token_injected_not_returned(self):
        self.up.push(OK_DATA)
        r = await self.cl.call(self.ctx["A_viewer"], "meta", "meta.read_campaigns", "act_A1", {"limit": 5})
        self.assertEqual(r.status_code, 200); j = r.json()
        self.assertTrue(j["ok"], j)
        self.assertEqual(self.up.calls[0].headers["authorization"], "Bearer " + H.FAKE["ref-a-meta"])
        self.assertNotIn("access_token", str(self.up.calls[0].url))              # التوكن بالرأس فقط
        self.assertNotIn(H.FAKE["ref-a-meta"], r.text)

    async def test_IT02_bad_auth_variants_rejected_without_upstream(self):
        body = json.dumps({"ctx": self.ctx["A_viewer"], "platform": "meta", "op": "meta.me"}).encode()
        h = H.sign_headers(H.RUNTIME_KEY, body, "n8n-runtime")
        variants = {
            "no headers": {}, "unknown key": H.sign_headers(H.RUNTIME_KEY, body, "nobody"),
            "wrong key": H.sign_headers(os.urandom(32), body, "n8n-runtime"),
            "stale": H.sign_headers(H.RUNTIME_KEY, body, "n8n-runtime", ts=1), "future": H.sign_headers(H.RUNTIME_KEY, body, "n8n-runtime", ts=2**31),
            "short nonce": H.sign_headers(H.RUNTIME_KEY, body, "n8n-runtime", nonce="abc"),
            "tampered sig": {**h, "x-signature": "0" * 64}}
        for name, hh in variants.items():
            r = await self.cl.http.post("/v1/call", content=body, headers=hh)
            self.assertEqual(r.status_code, 401, name)
        r = await self.cl.http.post("/v1/call", content=body + b" ", headers=h)           # جسم معدّل
        self.assertEqual(r.status_code, 401)
        self.assertEqual(len(self.up.calls), 0)

    async def test_IT03_replay_rejected_across_instances(self):
        body = json.dumps({"ctx": self.ctx["A_viewer"], "platform": "meta", "op": "meta.me"}).encode()
        h = H.sign_headers(H.RUNTIME_KEY, body, "n8n-runtime")
        r1 = await self.cl.http.post("/v1/call", content=body, headers=h)
        self.assertEqual(r1.status_code, 200)
        env2 = await H.make_env()                                      # نسخة ثانية من الخدمة (عملية أخرى) بنفس قاعدة vault
        try:
            r2 = await env2[1].http.post("/v1/call", content=body, headers=h)
            self.assertEqual(r2.status_code, 401)
        finally:
            await H.close_env(env2)
        r3 = await self.cl.http.post("/v1/call", content=body, headers=h)
        self.assertEqual(r3.status_code, 401)

    async def test_IT04_runtime_key_cannot_use_admin(self):
        r = await self.cl.post("/v1/admin/secrets", {"tenant_id": H.A, "kind": "meta_user_token", "secret_ref": "ref-a-meta", "value": "x" * 20})
        self.assertEqual(r.status_code, 401)
        r = await self.cl.post("/v1/admin/secrets/revoke", {"tenant_id": H.A, "secret_ref": "ref-a-meta"})
        self.assertEqual(r.status_code, 401)

    async def test_IT05_oversized_body_and_malformed_json(self):
        r = await self.cl.post("/v1/call", raw=b"x" * 70000)
        self.assertEqual(r.status_code, 413)
        r = await self.cl.post("/v1/call", raw=b"{not json")
        self.assertEqual(r.status_code, 400)
        r = await self.cl.post("/v1/call", {"ctx": 5, "platform": "meta", "op": "meta.me"})
        self.assertEqual(r.status_code, 400)

    async def test_IT06_health_and_no_docs(self):
        self.assertEqual((await self.cl.http.get("/healthz")).json(), {"ok": True})
        for p in ("/docs", "/redoc", "/openapi.json", "/v1/admin/secrets", "/v1/call"):
            self.assertIn((await self.cl.http.get(p)).status_code, (404, 405), p)


@SKIP
class TenantIsolation(Base):
    async def test_IT10_cross_tenant_ad_account_refused_no_upstream(self):
        for who, plat, acct in [("A_owner", "meta", "act_B1"), ("B_owner", "meta", "act_A1"), ("B_owner", "tiktok", "tt_A1"), ("A_owner", "tiktok", "act_A1")]:
            op = "meta.read_account" if plat == "meta" else "tiktok.read_campaigns"
            r = await self.cl.call(self.ctx[who], plat, op, acct)
            self.assertEqual(r.status_code, 403, (who, acct)); self.assertEqual(r.json()["error"]["message"], "ad_account_not_owned_or_disabled")
        self.assertEqual(len(self.up.calls), 0)

    async def test_IT11_each_tenant_uses_only_its_own_token(self):
        self.up.push(OK_DATA, OK_DATA, TT_OK, TT_OK)
        await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")
        await self.cl.call(self.ctx["B_owner"], "meta", "meta.read_account", "act_B1")
        await self.cl.call(self.ctx["A_owner"], "tiktok", "tiktok.read_campaigns", "tt_A1")
        await self.cl.call(self.ctx["B_owner"], "tiktok", "tiktok.read_campaigns", "tt_B1")
        c = self.up.calls
        self.assertEqual(c[0].headers["authorization"], "Bearer " + H.FAKE["ref-a-meta"])
        self.assertEqual(c[1].headers["authorization"], "Bearer " + H.FAKE["ref-b-meta"])
        self.assertEqual(c[2].headers["access-token"], H.FAKE["ref-a-tt"])
        self.assertEqual(c[3].headers["access-token"], H.FAKE["ref-b-tt"])
        self.assertIn("advertiser_id=tt_B1", str(c[3].url))

    async def test_IT12_stolen_ciphertext_cannot_be_opened_for_another_tenant(self):
        # مهاجم لديه كتابة على vault ينسخ سرّ A فوق سرّ B: فك التشفير يفشل (AAD) ولا يصل شيء للمنصة
        row = H.sup_vault("SELECT ciphertext, dek_wrapped FROM vault.secrets WHERE secret_ref='ref-a-meta'")[0]
        H.sup_vault("UPDATE vault.secrets SET ciphertext=%s, dek_wrapped=%s WHERE secret_ref='ref-b-meta'", (row[0], row[1]))
        r = await self.cl.call(self.ctx["B_owner"], "meta", "meta.read_account", "act_B1")
        self.assertEqual(r.status_code, 500); self.assertEqual(r.json()["error"]["class"], "integrity_error")
        self.assertEqual(len(self.up.calls), 0)
        self.assertNotIn(H.FAKE["ref-a-meta"], r.text)

    async def test_IT13_roles_and_ctx_validity(self):
        r = await self.cl.call(self.ctx["A_viewer"], "meta", "meta.create_campaign", "act_A1", {"name": "x", "objective": "OUTCOME_TRAFFIC"}, idem=IDEM("v"))
        self.assertEqual(r.status_code, 403)
        for bad in ("abc.def", "", "0" * 40 + "." + "0" * 64):
            r = await self.cl.call(bad, "meta", "meta.me")
            self.assertEqual(r.status_code, 401, bad)
        exp = H.sup_central("SELECT private.sign_ctx(jsonb_build_object('t',%s::text,'u',1001,'r','owner','e',1,'k','user'))", (H.A,))[0][0]
        self.assertEqual((await self.cl.call(exp, "meta", "meta.me")).status_code, 401)
        self.assertEqual(len(self.up.calls), 0)

    async def test_IT14_platform_feature_disabled_for_tenant(self):
        r = await self.cl.call(self.ctx["D_owner"], "tiktok", "tiktok.read_campaigns", "tt_D1")
        self.assertEqual(r.status_code, 403); self.assertEqual(r.json()["error"]["message"], "platform_not_enabled")

    async def test_IT15_suspended_or_not_ready_tenant_refused(self):
        H.sup_central("UPDATE core.tenants SET status='NEEDS_REVIEW' WHERE tenant_id=%s", (H.A,))
        try:
            r = await self.cl.call(self.ctx["A_viewer"], "meta", "meta.read_account", "act_A1")
            self.assertEqual(r.status_code, 403); self.assertEqual(r.json()["error"]["message"], "tenant_not_ready")
        finally:
            H.sup_central("UPDATE core.tenants SET status='READY' WHERE tenant_id=%s", (H.A,))

    async def test_IT16_deactivated_user_ctx_stops_immediately(self):
        H.sup_central("UPDATE core.tenant_users SET active=false WHERE telegram_user_id=1002")
        try:
            r = await self.cl.call(self.ctx["A_viewer"], "meta", "meta.read_account", "act_A1")
            self.assertEqual(r.status_code, 403)
        finally:
            H.sup_central("UPDATE core.tenant_users SET active=true WHERE telegram_user_id=1002")


@SKIP
class Secrets(Base):
    async def test_IT20_upstream_echoing_token_is_redacted_everywhere(self):
        tok = H.FAKE["ref-a-meta"]
        self.up.push((400, {"error": {"code": 100, "message": f"Invalid parameter. token={tok} was used; Bearer {tok}"}}))
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")
        self.assertEqual(r.json()["error"]["class"], "bad_request")
        self.assertNotIn(tok, r.text)
        self.up.push((200, {"data": [{"note": f"leaked {tok}"}]}))
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")
        self.assertNotIn(tok, r.text)

    async def test_IT21_no_secret_in_logs_after_varied_run(self):
        self.up.push((500, {}), (500, {}), (500, {}), (401, {"error": {"code": 190, "message": f"bad {H.FAKE['ref-b-meta']}"}}))
        await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")
        await self.cl.call(self.ctx["B_owner"], "meta", "meta.read_account", "act_B1")
        await self.cl.call("garbage", "meta", "meta.me")
        await self.cl.post("/v1/call", raw=b"{bad")
        await self.cl.admin_put(H.A, "meta_user_token", "ref-a-meta", "NEW-SECRET-" + "z" * 16)
        blob = "\n".join(self.logcap.lines)
        for s in list(H.FAKE.values()) + ["NEW-SECRET-" + "z" * 16]:
            self.assertNotIn(s, blob)
        self.assertGreater(len(self.logcap.lines), 0)

    async def test_IT22_admin_put_never_returns_value_and_ciphertext_has_no_plaintext(self):
        val = "ROTATED-SECRET-" + "q" * 20
        r = await self.cl.admin_put(H.A, "meta_user_token", "ref-a-meta", val)
        self.assertEqual(r.json(), {"ok": True, "secret_ref": "ref-a-meta", "version": 2})
        self.assertNotIn(val, r.text)
        for ct, dek in H.sup_vault("SELECT ciphertext, dek_wrapped FROM vault.secrets"):
            for p in list(H.FAKE.values()) + [val]:
                self.assertNotIn(p.encode(), bytes(ct) + bytes(dek))

    async def test_IT23_call_log_has_metadata_only(self):
        self.up.push(OK_DATA)
        await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")
        rows = H.sup_vault("SELECT tenant_id::text, platform, endpoint, http_status, error_code FROM vault.api_call_log")
        self.assertEqual(rows, [(H.A, "meta", "meta.read_account", 200, None)])
        self.assertNotIn(H.FAKE["ref-a-meta"], str(H.sup_vault("SELECT * FROM vault.api_call_log")))

    async def test_IT24_rotation_new_version_used_old_revoked(self):
        self.up.push(OK_DATA)
        r = await self.cl.admin_put(H.A, "meta_user_token", "ref-a-meta", "ROTATED-V2-" + "k" * 16)
        self.assertEqual(r.json()["version"], 2)
        await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")
        self.assertEqual(self.up.calls[0].headers["authorization"], "Bearer ROTATED-V2-" + "k" * 16)
        self.assertEqual(H.sup_vault("SELECT version, revoked_at IS NOT NULL FROM vault.secrets WHERE secret_ref='ref-a-meta' ORDER BY version"), [(1, True), (2, False)])

    async def test_IT25_secret_ref_cannot_be_hijacked_by_another_tenant(self):
        r = await self.cl.admin_put(H.B, "meta_user_token", "ref-a-meta", "HIJACK-" + "h" * 16)
        self.assertEqual(r.status_code, 409); self.assertEqual(r.json()["error"]["class"], "ref_mismatch")
        r = await self.cl.admin_put(H.A, "tiktok_token", "ref-a-meta", "HIJACK-" + "h" * 16)         # نفس العميل ونوع آخر
        self.assertEqual(r.status_code, 409)
        self.assertEqual(H.sup_vault("SELECT count(*) FROM vault.secrets WHERE secret_ref='ref-a-meta'")[0][0], 1)

    async def test_IT26_revoked_secret_blocks_calls(self):
        r = await self.cl.post("/v1/admin/secrets/revoke", {"tenant_id": H.A, "secret_ref": "ref-a-meta"}, key=H.ADMIN_KEY, key_id="ops-admin")
        self.assertEqual(r.json()["revoked"], 1)
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")
        self.assertEqual(r.status_code, 424); self.assertEqual(r.json()["error"]["class"], "secret_missing")
        self.assertEqual(len(self.up.calls), 0)

    async def test_IT27_kek_rewrap(self):
        store = self.app.router.lifespan_context  # noqa
        new = os.urandom(32)
        from app.cli import _rewrap  # noqa: F401  (استيراد يتحقق من سلامة الـ CLI)
        from psycopg_pool import AsyncConnectionPool
        from app.store import VaultStore
        pool = AsyncConnectionPool(H.ENV["T_VAULT"], open=False, kwargs={"autocommit": True}); await pool.open()
        vs = VaultStore(pool, H.KEK)
        self.assertEqual(await vs.rewrap_all(H.KEK, new), len(H.REFS))
        _, _, v = await vs.open_latest(H.A, "ref-a-meta")
        self.assertEqual(v, H.FAKE["ref-a-meta"])
        await pool.close()
        pool2 = AsyncConnectionPool(H.ENV["T_VAULT"], open=False, kwargs={"autocommit": True}); await pool2.open()
        with self.assertRaises(Exception):
            await VaultStore(pool2, H.KEK).open_latest(H.A, "ref-a-meta")           # KEK القديم لم يعد يعمل
        await pool2.close()


@SKIP
class Resilience(Base):
    async def test_IT30_read_retries_transient_with_backoff(self):
        self.up.push((500, {}), (503, {}), OK_DATA)
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_campaigns", "act_A1")
        self.assertTrue(r.json()["ok"]); self.assertEqual(r.json()["meta"]["attempts"], 3)
        self.assertEqual(self.sleeps, [0.2, 0.4])

    async def test_IT31_retry_after_respected(self):
        self.up.push((429, {"error": {"code": 17}}, {"retry-after": "3"}), OK_DATA)
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_campaigns", "act_A1")
        self.assertTrue(r.json()["ok"]); self.assertEqual(self.sleeps, [3.0])

    async def test_IT32_exhausted_retries_returns_classified_error(self):
        self.up.push((500, {}), (500, {}), (500, {}))
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_campaigns", "act_A1")
        e = r.json()["error"]
        self.assertEqual((e["class"], e["retryable"]), ("transient", True)); self.assertEqual(len(self.up.calls), 3)

    async def test_IT33_non_retryable_errors_not_retried(self):
        for status, body, cls in [(400, {"error": {"code": 100, "message": "x"}}, "bad_request"), (403, {"error": {"code": 200}}, "permission_denied"), (400, {"error": {"code": 368}}, "policy_rejected")]:
            self.up.calls.clear(); self.up.push((status, body))
            r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_campaigns", "act_A1")
            self.assertEqual(r.json()["error"]["class"], cls); self.assertEqual(len(self.up.calls), 1)

    async def test_IT34_network_errors_retried_for_reads(self):
        self.up.push(httpx.ConnectError("boom"), httpx.ReadTimeout("slow"), OK_DATA)
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_campaigns", "act_A1")
        self.assertTrue(r.json()["ok"]); self.assertEqual(len(self.up.calls), 3)

    async def test_IT35_circuit_breaker_per_tenant_and_platform(self):
        t = [0.0]
        await H.close_env(self.env)
        self.env = await H.make_env(clock=lambda: t[0]); self.app, self.cl, self.up, self.sleeps, _ = self.env
        self.up.default = (500, {})
        for _ in range(5):
            await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_campaigns", "act_A1", idem=None)
        n = len(self.up.calls)
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_campaigns", "act_A1")
        self.assertEqual(r.json()["error"]["class"], "circuit_open"); self.assertEqual(len(self.up.calls), n)       # لا طلب للمنصة
        self.up.default = OK_DATA
        r = await self.cl.call(self.ctx["B_owner"], "meta", "meta.read_campaigns", "act_B1")                          # عميل آخر لا يتأثر
        self.assertTrue(r.json()["ok"])
        r = await self.cl.call(self.ctx["A_owner"], "tiktok", "tiktok.read_campaigns", "tt_A1")                       # منصة أخرى لنفس العميل لا تتأثر
        self.up.default = (200, {"code": 0, "data": {}})
        t[0] = 31.0
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_campaigns", "act_A1")                          # بعد الـ cooldown: محاولة واحدة تُغلق الدائرة
        self.assertTrue(r.json()["ok"])
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_campaigns", "act_A1")
        self.assertTrue(r.json()["ok"])

    async def test_IT36_local_rate_limit_isolated_per_tenant(self):
        await H.close_env(self.env)
        self.env = await H.make_env(settings=H.make_settings(rate_per_sec=0.0001, rate_burst=2)); self.app, self.cl, self.up, self.sleeps, _ = self.env
        codes = [(await self.cl.call(self.ctx["A_owner"], "meta", "meta.me")).status_code for _ in range(4)]
        self.assertEqual(codes, [200, 200, 429, 429])
        self.assertEqual((await self.cl.call(self.ctx["B_owner"], "meta", "meta.me")).status_code, 200)

    async def test_IT37_redirects_not_followed(self):
        self.up.push((302, {}, {"location": "http://evil.invalid/steal"}))
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")
        self.assertFalse(r.json()["ok"]); self.assertEqual(len(self.up.calls), 1)
        self.assertEqual(len(self.calls_to("evil.invalid")), 0)


@SKIP
class TokenExpiry(Base):
    async def test_IT40_meta_expired_token_isolates_only_that_connection(self):
        self.up.push((400, {"error": {"code": 190, "message": "Error validating access token: expired"}}))
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")
        e = r.json()["error"]; self.assertEqual((e["class"], e["retryable"]), ("auth_expired", False))
        self.assertEqual(len(self.up.calls), 1)                                                      # بلا إعادة محاولة
        self.assertEqual(H.sup_vault("SELECT state FROM vault.secret_state WHERE secret_ref='ref-a-meta'"), [("auth_expired",)])
        self.assertEqual(H.sup_central("SELECT status FROM core.platform_connections WHERE secret_ref='ref-a-meta'"), [("expired",)])
        n = len(self.up.calls)
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")           # فشل سريع بدون المنصة
        self.assertEqual(r.json()["error"]["class"], "auth_expired"); self.assertEqual(len(self.up.calls), n)
        self.up.push(OK_DATA, TT_OK)
        self.assertTrue((await self.cl.call(self.ctx["B_owner"], "meta", "meta.read_account", "act_B1")).json()["ok"])     # عميل آخر سليم
        self.assertTrue((await self.cl.call(self.ctx["A_owner"], "tiktok", "tiktok.read_campaigns", "tt_A1")).json()["ok"])  # منصة أخرى سليمة
        self.assertEqual(H.sup_central("SELECT secret_ref, status FROM core.platform_connections ORDER BY 1"),
                         [("ref-a-meta", "expired"), ("ref-a-tt", "active"), ("ref-b-meta", "active"), ("ref-b-tt", "active"), ("ref-d-meta", "active")])

    async def test_IT41_tiktok_expired_code_mapping(self):
        self.up.push((200, {"code": 40105, "message": "Access token expired"}))
        r = await self.cl.call(self.ctx["B_owner"], "tiktok", "tiktok.read_campaigns", "tt_B1")
        self.assertEqual(r.json()["error"]["class"], "auth_expired")
        self.assertEqual(H.sup_central("SELECT status FROM core.platform_connections WHERE secret_ref='ref-b-tt'"), [("expired",)])

    async def test_IT42_recovery_requires_new_secret_and_system_reactivation(self):
        self.up.push((401, {}))
        await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")
        await self.cl.admin_put(H.A, "meta_user_token", "ref-a-meta", "REAUTH-" + "n" * 16)          # توكن جديد بعد إعادة المصادقة
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")           # المركزية ما زالت expired
        self.assertEqual(r.json()["error"]["class"], "auth_expired"); self.assertEqual(len(self.up.calls), 1)
        sysctx = H.get_sys_ctx(H.A)
        import psycopg
        with psycopg.connect(H.ENV["T_JOBS"], autocommit=True) as c:
            self.assertTrue(c.execute("SELECT api.set_connection_status(%s,'ref-a-meta','active')", (sysctx,)).fetchone()[0])
        self.up.push(OK_DATA)
        r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_account", "act_A1")
        self.assertTrue(r.json()["ok"]); self.assertEqual(self.up.calls[-1].headers["authorization"], "Bearer REAUTH-" + "n" * 16)


@SKIP
class Writes(Base):
    P = {"name": "حملة اختبار", "objective": "OUTCOME_TRAFFIC"}

    async def create(self, key, who="A_mgr", params=None, acct="act_A1"):
        return await self.cl.call(self.ctx[who], "meta", "meta.create_campaign", acct, params or self.P, idem=key)

    async def test_IT50_forced_paused_and_json_body(self):
        self.up.push((200, {"id": "999"}))
        r = await self.create(IDEM("a"))
        self.assertTrue(r.json()["ok"])
        sent = json.loads(self.up.calls[0].content)
        self.assertEqual(sent["status"], "PAUSED"); self.assertEqual(sent["name"], "حملة اختبار")
        self.up.push((200, {"code": 0, "data": {"campaign_id": "1"}}))
        await self.cl.call(self.ctx["A_mgr"], "tiktok", "tiktok.create_campaign", "tt_A1", {"campaign_name": "x", "objective_type": "TRAFFIC"}, idem=IDEM("tt"))
        sent = json.loads(self.up.calls[1].content)
        self.assertEqual((sent["operation_status"], sent["advertiser_id"]), ("DISABLE", "tt_A1"))

    async def test_IT51_same_key_sequential_sends_once_and_replays(self):
        self.up.push((200, {"id": "111"}))
        r1 = await self.create(IDEM("b")); r2 = await self.create(IDEM("b"))
        self.assertEqual(len(self.up.calls), 1)
        self.assertEqual(r2.json()["data"], {"id": "111"}); self.assertTrue(r2.json()["meta"]["replayed"])

    async def test_IT52_ten_parallel_same_key_exactly_one_upstream_call(self):
        async def slow(_req):
            await asyncio.sleep(0)
            return httpx.Response(200, json={"id": "222"})
        self.up.default = slow
        rs = await asyncio.gather(*[self.create(IDEM("par")) for _ in range(10)])
        self.assertEqual(len(self.up.calls), 1)
        kinds = sorted(("ok" if r.json().get("ok") else r.json()["error"]["class"]) for r in rs)
        self.assertEqual(kinds.count("ok") + kinds.count("in_progress"), 10, kinds)
        self.assertGreaterEqual(kinds.count("ok"), 1)

    async def test_IT53_same_key_different_payload_conflict(self):
        self.up.push((200, {"id": "1"}))
        await self.create(IDEM("c"))
        r = await self.create(IDEM("c"), params={"name": "غير", "objective": "OUTCOME_TRAFFIC"})
        self.assertEqual(r.status_code, 409); self.assertEqual(r.json()["error"]["class"], "idempotency_conflict"); self.assertEqual(len(self.up.calls), 1)

    async def test_IT54_same_key_other_tenant_independent(self):
        self.up.push((200, {"id": "a"}), (200, {"id": "b"}))
        ra = await self.create(IDEM("same"), "A_mgr", acct="act_A1"); rb = await self.create(IDEM("same"), "B_mgr", acct="act_B1")
        self.assertTrue(ra.json()["ok"] and rb.json()["ok"]); self.assertEqual(len(self.up.calls), 2)

    async def test_IT55_missing_or_short_idempotency_key(self):
        for k in (None, "short"):
            r = await self.create(k); self.assertEqual(r.status_code, 400)
        self.assertEqual(len(self.up.calls), 0)

    async def test_IT56_ambiguous_timeout_never_resent(self):
        self.up.push(httpx.ReadTimeout("lost"))
        r = await self.create(IDEM("amb"))
        self.assertEqual(r.json()["error"]["class"], "outcome_unknown"); self.assertEqual(len(self.up.calls), 1)       # بلا إعادة
        r = await self.create(IDEM("amb"))
        self.assertEqual(r.json()["error"]["class"], "outcome_unknown"); self.assertEqual(len(self.up.calls), 1)       # ولا عند التكرار
        self.up.push((200, {"id": "n"}))
        self.assertTrue((await self.create(IDEM("amb2"))).json()["ok"])                                                # مفتاح جديد = قرار واعٍ من المُستدعي

    async def test_IT57_server_error_on_write_is_unknown_not_retried(self):
        self.up.push((500, {}))
        r = await self.create(IDEM("e5"))
        self.assertEqual(r.json()["error"]["class"], "outcome_unknown"); self.assertEqual(len(self.up.calls), 1)

    async def test_IT58_connect_error_on_write_is_retried_safely(self):
        self.up.push(httpx.ConnectError("refused"), (200, {"id": "ok"}))
        r = await self.create(IDEM("ce"))
        self.assertTrue(r.json()["ok"]); self.assertEqual(len(self.up.calls), 2)

    async def test_IT59_rejected_write_can_be_retried_with_same_key(self):
        self.up.push((400, {"error": {"code": 100, "message": "bad"}}), (200, {"id": "fixed"}))
        r = await self.create(IDEM("rej")); self.assertEqual(r.json()["error"]["class"], "bad_request")
        r = await self.create(IDEM("rej")); self.assertTrue(r.json()["ok"]); self.assertEqual(len(self.up.calls), 2)

    async def test_IT5A_rate_limited_write_is_failed_retryable_not_unknown(self):
        self.up.push((429, {"error": {"code": 17}}), (200, {"id": "later"}))
        r = await self.create(IDEM("rl")); e = r.json()["error"]
        self.assertEqual((e["class"], e["retryable"]), ("rate_limited", True)); self.assertEqual(len(self.up.calls), 1)
        self.assertTrue((await self.create(IDEM("rl"))).json()["ok"])

    async def test_IT5B_stale_executing_becomes_unknown_and_is_not_resent(self):
        from app.store import VaultStore
        h = VaultStore.request_hash("meta", "meta.create_campaign", "act_A1", self.P)
        H.sup_vault("INSERT INTO vault.write_requests (tenant_id, idempotency_key, request_hash, platform, op, state, updated_at) "
                    "VALUES (%s,%s,%s,'meta','meta.create_campaign','executing', now() - interval '20 minutes')", (H.A, IDEM("stale"), h))
        r = await self.create(IDEM("stale"))
        self.assertEqual(r.json()["error"]["class"], "outcome_unknown"); self.assertEqual(len(self.up.calls), 0)
        self.assertEqual(H.sup_vault("SELECT state FROM vault.write_requests WHERE idempotency_key=%s", (IDEM("stale"),)), [("unknown",)])

    async def test_IT5C_fresh_executing_blocks_second_sender(self):
        from app.store import VaultStore
        h = VaultStore.request_hash("meta", "meta.create_campaign", "act_A1", self.P)
        H.sup_vault("INSERT INTO vault.write_requests (tenant_id, idempotency_key, request_hash, platform, op, state) VALUES (%s,%s,%s,'meta','meta.create_campaign','executing')", (H.A, IDEM("busy"), h))
        r = await self.create(IDEM("busy"))
        self.assertEqual(r.status_code, 409); self.assertEqual(r.json()["error"]["class"], "in_progress"); self.assertEqual(len(self.up.calls), 0)


@SKIP
class Telegram(Base):
    TG_OK = (200, {"ok": True, "result": {"message_id": 7}})

    async def send(self, who, chat, text):
        return await self.cl.call(self.ctx[who], "telegram", "telegram.send_message", str(chat), {"text": text})

    async def test_IT80_send_uses_own_bot_token_in_path_only(self):
        self.up.push(self.TG_OK)
        r = await self.send("A_viewer", 1001, "أهلاً\nسطر ثاني")
        self.assertTrue(r.json()["ok"], r.text)
        c = self.up.calls[0]
        self.assertIn("/bot" + H.FAKE["ref-bot-a"] + "/sendMessage", str(c.url))
        body = json.loads(c.content)
        self.assertEqual((body["chat_id"], body["text"]), (1001, "أهلاً\nسطر ثاني"))
        self.assertNotIn(H.FAKE["ref-bot-a"], r.text)

    async def test_IT81_cannot_message_other_tenants_chat_or_unknown_chat(self):
        for chat in (2001, 99999):
            r = await self.send("A_owner", chat, "x")
            self.assertEqual(r.status_code, 403, chat); self.assertEqual(r.json()["error"]["message"], "chat_not_registered")
        r = await self.send("B_owner", 1001, "x")
        self.assertEqual(r.status_code, 403)
        self.assertEqual(len(self.up.calls), 0)

    async def test_IT82_each_tenant_uses_its_own_bot(self):
        self.up.push(self.TG_OK, self.TG_OK)
        await self.send("A_owner", 1001, "a"); await self.send("B_owner", 2001, "b")
        self.assertIn(H.FAKE["ref-bot-a"], str(self.up.calls[0].url)); self.assertIn(H.FAKE["ref-bot-b"], str(self.up.calls[1].url))

    async def test_IT83_bad_chat_and_text_rejected(self):
        for chat in ("abc", "-100123", "1001; DROP", ""):
            r = await self.send("A_owner", chat, "x")
            self.assertIn(r.status_code, (400, 403))
        for text in ("", "x" * 4000, "a\x00b", "a\x1bb"):
            r = await self.send("A_owner", 1001, text)
            self.assertEqual(r.status_code, 400, repr(text[:10]))
        self.assertEqual(len(self.up.calls), 0)

    async def test_IT84_blocked_user_and_bad_token_classified(self):
        self.up.push((403, {"ok": False, "error_code": 403, "description": "Forbidden: bot was blocked by the user"}))
        r = await self.send("A_owner", 1001, "x")
        self.assertEqual(r.json()["error"]["class"], "permission_denied")
        self.up.push((401, {"ok": False, "error_code": 401, "description": "Unauthorized"}))
        r = await self.send("B_owner", 2001, "x")
        self.assertEqual(r.json()["error"]["class"], "auth_expired")

    async def test_IT85_bot_token_never_in_logs_or_errors(self):
        tok = H.FAKE["ref-bot-a"]
        self.up.push((400, {"ok": False, "error_code": 400, "description": f"Bad Request: https://api.telegram.org/bot{tok}/sendMessage"}))
        r = await self.send("A_owner", 1001, "x")
        self.assertNotIn(tok, r.text)
        self.up.push(httpx.ConnectError(f"cannot connect to https://x/bot{tok}/sendMessage"), httpx.ConnectError("again"), httpx.ConnectError("again"))
        await self.send("A_owner", 1001, "y")
        self.assertNotIn(tok, "\n".join(self.logcap.lines))

    async def test_IT96_expired_subscription_blocks_platform_calls_but_not_renewal_notice(self):
        H.sup_central("UPDATE core.subscriptions SET status='past_due', current_period_end = now() - interval '10 days' WHERE tenant_id = %s", (H.A,))
        try:
            r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_campaigns", "act_A1", {"limit": 1})
            self.assertEqual(r.status_code, 403); self.assertEqual(r.json()["error"]["message"], "subscription_expired")
            self.assertEqual(len(self.up.calls), 0)
            self.up.push((200, {"ok": True, "result": {"message_id": 1}}))
            r = await self.cl.call(self.ctx["A_owner"], "telegram", "telegram.send_message", "1001", {"text": "اشتراكك منتهي"})
            self.assertTrue(r.json()["ok"], r.text)
            r = await self.cl.call(self.ctx["B_owner"], "meta", "meta.me")          # عميل آخر غير متأثر
            self.assertNotEqual(r.status_code, 403)
        finally:
            H.sup_central("UPDATE core.subscriptions SET status='active', current_period_end = now() + interval '30 days' WHERE tenant_id = %s", (H.A,))

    async def test_IT97_grace_period_allows_reads_blocks_writes(self):
        H.sup_central("UPDATE core.subscriptions SET status='past_due', current_period_end = now() - interval '1 day' WHERE tenant_id = %s", (H.A,))
        try:
            self.up.push((200, {"data": []}))
            r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.read_campaigns", "act_A1", {"limit": 1})
            self.assertTrue(r.json()["ok"], r.text)
            r = await self.cl.call(self.ctx["A_owner"], "meta", "meta.create_campaign", "act_A1", {"name": "x", "objective": "OUTCOME_TRAFFIC"}, idem="g" * 20)
            self.assertEqual(r.status_code, 403); self.assertEqual(r.json()["error"]["message"], "subscription_grace_readonly")
        finally:
            H.sup_central("UPDATE core.subscriptions SET status='active', current_period_end = now() + interval '30 days' WHERE tenant_id = %s", (H.A,))


@SKIP
class Readiness(Base):
    OK = (200, {"ok": True, "result": {"id": 111}})

    async def probe(self, ctx, plat, op, acct=None, params=None, mode="readiness"):
        return await self.cl.call(ctx, plat, op, acct, params, mode=mode)

    async def test_IT90_probe_get_me_uses_own_bot_token(self):
        self.up.push(self.OK)
        r = await self.probe(H.get_sys_ctx(H.A), "telegram", "telegram.get_me")
        self.assertTrue(r.json()["ok"], r.text)
        self.assertIn("/bot" + H.FAKE["ref-bot-a"] + "/getMe", str(self.up.calls[0].url))
        self.assertNotIn(H.FAKE["ref-bot-a"], r.text)

    async def test_IT91_probe_requires_system_ctx(self):
        r = await self.probe(self.ctx["A_owner"], "telegram", "telegram.get_me")
        self.assertEqual(r.status_code, 403); self.assertEqual(len(self.up.calls), 0)

    async def test_IT92_readiness_mode_refuses_writes(self):
        r = await self.cl.call(H.get_sys_ctx(H.A), "meta", "meta.create_campaign", "act_A1", {"name": "x", "objective": "OUTCOME_TRAFFIC"}, idem="k" * 20, mode="readiness")
        self.assertEqual(r.status_code, 400); self.assertEqual(len(self.up.calls), 0)

    async def test_IT93_probe_cannot_reach_other_tenant_account(self):
        r = await self.probe(H.get_sys_ctx(H.A), "meta", "meta.read_account", "act_B1")
        self.assertEqual(r.status_code, 403); self.assertEqual(len(self.up.calls), 0)

    async def test_IT94_validate_campaign_is_validate_only_and_paused(self):
        self.up.push((200, {"success": True}))
        r = await self.probe(H.get_sys_ctx(H.A), "meta", "meta.validate_campaign", "act_A1", {"name": "probe", "objective": "OUTCOME_TRAFFIC"})
        self.assertTrue(r.json()["ok"], r.text)
        body = json.loads(self.up.calls[0].content)
        self.assertEqual(body["execution_options"], ["validate_only"]); self.assertEqual(body["status"], "PAUSED")

    async def test_IT95_unknown_mode_rejected(self):
        r = await self.probe(H.get_sys_ctx(H.A), "telegram", "telegram.get_me", mode="admin")
        self.assertEqual(r.status_code, 400); self.assertEqual(len(self.up.calls), 0)


@SKIP
class Partitions(Base):
    async def test_IT70_log_partitions_and_nonce_purge(self):
        self.assertGreaterEqual(H.sup_vault("SELECT count(*) FROM pg_inherits WHERE inhparent='vault.api_call_log'::regclass")[0][0], 3)
        await self.cl.call(self.ctx["A_owner"], "meta", "meta.me")
        self.assertGreater(H.sup_vault("SELECT count(*) FROM vault.used_nonces")[0][0], 0)
        H.sup_vault("UPDATE vault.used_nonces SET at = now() - interval '1 hour'")
        from psycopg_pool import AsyncConnectionPool
        from app.store import VaultStore
        p = AsyncConnectionPool(H.ENV["T_VAULT"], open=False, kwargs={"autocommit": True}); await p.open()
        await VaultStore(p, H.KEK).purge_nonces(300); await p.close()
        self.assertEqual(H.sup_vault("SELECT count(*) FROM vault.used_nonces")[0][0], 0)


if __name__ == "__main__":
    unittest.main()
