"""أدوات الاختبارات: بيئة، توقيع الطلبات، سياقات (ctx) حقيقية من القاعدة، upstream محاكى."""
import asyncio
import base64
import hashlib
import json
import logging
import os
import secrets
import time

import httpx
import psycopg

import envelope
import hmac_auth
from app.config import Settings
from app.main import create_app

ENV = {k: os.environ.get(k) for k in ("T_CENTRAL", "T_VAULT", "T_RUNTIME", "T_JOBS", "T_SUPER_CENTRAL", "T_SUPER_VAULT")}
HAVE_DB = all(ENV.values())

A = "a0000000-0000-0000-0000-000000000001"
B = "b0000000-0000-0000-0000-000000000001"
C = "c0000000-0000-0000-0000-000000000001"
D = "d0000000-0000-0000-0000-000000000001"
BOTS = {"A": ("botAAAAAAAAAAAAAAAAAAAAAAAA", "secret-a"), "B": ("botBBBBBBBBBBBBBBBBBBBBBBBB", "secret-b"), "D": ("botDDDDDDDDDDDDDDDDDDDDDDDD", "secret-d")}
USERS = {"A_owner": ("A", 1001), "A_viewer": ("A", 1002), "A_mgr": ("A", 1003), "B_owner": ("B", 2001), "B_mgr": ("B", 2002), "D_owner": ("D", 4001)}

KEK = os.urandom(32)
RUNTIME_KEY, ADMIN_KEY = os.urandom(32), os.urandom(32)
FAKE = {"ref-a-meta": "FAKE-A-META-" + secrets.token_hex(12), "ref-a-tt": "FAKE-A-TT-" + secrets.token_hex(12),
        "ref-b-meta": "FAKE-B-META-" + secrets.token_hex(12), "ref-b-tt": "FAKE-B-TT-" + secrets.token_hex(12),
        "ref-bot-a": "1111111111:AAF" + secrets.token_hex(16), "ref-bot-b": "2222222222:AAF" + secrets.token_hex(16)}   # scan:allow (وهمي)
REFS = {"ref-a-meta": (A, "meta_user_token"), "ref-a-tt": (A, "tiktok_token"), "ref-b-meta": (B, "meta_user_token"), "ref-b-tt": (B, "tiktok_token"),
        "ref-bot-a": (A, "telegram_bot_token"), "ref-bot-b": (B, "telegram_bot_token")}


def make_settings(**kw) -> Settings:
    base = dict(kek=KEK, hmac_keys={"n8n-runtime": (RUNTIME_KEY, "runtime"), "ops-admin": (ADMIN_KEY, "admin")},
                central_dsn=ENV["T_CENTRAL"], vault_dsn=ENV["T_VAULT"],
                base_urls={"meta": "http://mock-meta.invalid/v1", "tiktok": "http://mock-tiktok.invalid/open_api/v1.3", "telegram": "http://mock-telegram.invalid"},
                backoff_base=0.2, backoff_cap=2.0)
    base.update(kw)
    return Settings(**base).validate()


class Upstream:
    """منصة وهمية: تسجّل كل طلب، وتردّ من طابور ردود (callables أو (status, body, headers))."""
    def __init__(self):
        self.calls, self.queue, self.default = [], [], None

    def push(self, *responses):
        self.queue.extend(responses)

    def handler(self, request: httpx.Request):
        self.calls.append(request)
        item = self.queue.pop(0) if self.queue else self.default
        if item is None:
            return httpx.Response(200, json={"data": []})
        if isinstance(item, Exception):
            raise item
        if callable(item):
            return item(request)
        status, body = item[0], item[1]
        headers = item[2] if len(item) > 2 else {}
        return httpx.Response(status, json=body, headers=headers)

    @property
    def transport(self):
        return httpx.MockTransport(self.handler)


def sign_headers(key: bytes, body: bytes, key_id: str, ts=None, nonce=None):
    ts = int(time.time()) if ts is None else ts
    nonce = secrets.token_hex(12) if nonce is None else nonce
    return {"x-key-id": key_id, "x-timestamp": str(ts), "x-nonce": nonce, "x-signature": hmac_auth.sign(key, body, ts, nonce), "content-type": "application/json"}


class Client:
    """عميل HTTP موقّع نحو تطبيق Broker عبر ASGI (بدون شبكة)."""
    def __init__(self, app):
        self.app = app
        self.http = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://broker.test")

    async def post(self, path, payload=None, *, raw=None, key=RUNTIME_KEY, key_id="n8n-runtime", headers=None, **sign_kw):
        body = raw if raw is not None else json.dumps(payload).encode()
        h = sign_headers(key, body, key_id, **sign_kw)
        if headers is not None:
            h = headers
        return await self.http.post(path, content=body, headers=h)

    async def call(self, ctx, platform, op, ad_account=None, params=None, idem=None, mode=None, **kw):
        d = {"ctx": ctx, "platform": platform, "op": op, "ad_account": ad_account, "params": params or {}}
        if mode:
            d["mode"] = mode
        if idem:
            d["idempotency_key"] = idem
        return await self.post("/v1/call", d, **kw)

    async def admin_put(self, tenant, kind, ref, value):
        return await self.post("/v1/admin/secrets", {"tenant_id": tenant, "kind": kind, "secret_ref": ref, "value": value}, key=ADMIN_KEY, key_id="ops-admin")


def get_ctx(who: str) -> str:
    bot, user = USERS[who]
    b, sec = BOTS[bot]
    with psycopg.connect(ENV["T_RUNTIME"], autocommit=True) as c:
        return c.execute("SELECT ctx FROM api.resolve_context(%s, decode(%s,'hex'), %s)", (b, hashlib.sha256(sec.encode()).hexdigest(), user)).fetchone()[0]


def get_sys_ctx(tenant: str) -> str:
    with psycopg.connect(ENV["T_JOBS"], autocommit=True) as c:
        return c.execute("SELECT ctx FROM api.job_contexts('schedule',10) WHERE tenant_id = %s", (tenant,)).fetchone()[0]


def sup_central(sql, args=()):
    with psycopg.connect(ENV["T_SUPER_CENTRAL"], autocommit=True) as c:
        cur = c.execute(sql, args)
        return cur.fetchall() if cur.description else None


def sup_vault(sql, args=()):
    with psycopg.connect(ENV["T_SUPER_VAULT"], autocommit=True) as c:
        cur = c.execute(sql, args)
        return cur.fetchall() if cur.description else None


def reset_state():
    """حالة نظيفة: اتصالات active، سجل الـ vault فارغ، الأسرار الوهمية مُدخلة بنسخة 1."""
    sup_central("UPDATE core.platform_connections SET status='active'")
    sup_vault("TRUNCATE vault.secrets, vault.secret_state, vault.used_nonces, vault.write_requests, vault.api_call_log, vault.secret_refs CASCADE")
    for ref, (tenant, kind) in REFS.items():
        sup_vault("INSERT INTO vault.secret_refs (secret_ref, tenant_id, kind) VALUES (%s,%s,%s)", (ref, tenant, kind))
        s = envelope.seal(FAKE[ref].encode(), KEK, tenant, kind, 1, ref)
        sup_vault("INSERT INTO vault.secrets (secret_ref, tenant_id, kind, version, ciphertext, dek_wrapped) VALUES (%s,%s,%s,%s,%s,%s)",
                  (ref, tenant, kind, 1, s.ciphertext, s.dek_wrapped))


class LogCapture(logging.Handler):
    def __init__(self):
        super().__init__(logging.DEBUG)
        self.lines = []

    def emit(self, record):
        self.lines.append(self.format(record))


async def make_env(settings=None, upstream=None, **broker_kw):
    """-> (app, client, upstream, sleeps). يشغّل lifespan يدوياً."""
    up = upstream or Upstream()
    sleeps = []

    async def fake_sleep(d):
        sleeps.append(d)
    clock = broker_kw.pop("clock", None)
    kw = dict(sleep=fake_sleep, rng=lambda: 1.0)
    if clock:
        kw["clock"] = clock
    kw.update(broker_kw)
    app = create_app(settings or make_settings(), transport=up.transport, **kw)
    cm = app.router.lifespan_context(app)
    await cm.__aenter__()
    return app, Client(app), up, sleeps, cm


async def close_env(env):
    app, client, up, sleeps, cm = env
    await client.http.aclose()
    await cm.__aexit__(None, None, None)
