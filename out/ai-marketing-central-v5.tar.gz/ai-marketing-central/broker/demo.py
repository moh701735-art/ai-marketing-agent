#!/usr/bin/env python3
"""عرض تجريبي (Demo): عميلان وهميان، منصة وهمية. يشغّل الخدمة الحقيقية + قاعدتين حقيقيتين ويطبع ما يحدث بكلام مفهوم."""
import asyncio, json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "tests"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import httpx
import helpers as H

IDEM = lambda s: ("demo-" + s).ljust(24, "x")
OK = (200, {"data": [{"id": "1"}]})
results = []


def say(s=""):
    print(s, flush=True)


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    say(("   ✅ " if cond else "   ❌ ") + name + (f"  ← {detail}" if detail else ""))


async def main():
    H.reset_state()
    ctx = {w: H.get_ctx(w) for w in ("A_owner", "A_mgr", "B_owner", "B_mgr")}
    app, cl, up, sleeps, cm = await H.make_env()
    import logging
    cap = H.LogCapture(); logging.getLogger().addHandler(cap); logging.getLogger().setLevel(logging.DEBUG)

    say("═" * 66)
    say("عرض تجريبي: نظام الاشتراكات المركزي — عميلان وهميان (A و B)")
    say("كل شي هنا وهمي: لا بوت، لا تيك توك حقيقي، لا حملات حقيقية")
    say("═" * 66)

    say("\n1) كل عميل يشتغل على حسابه فقط")
    up.push(OK, OK)
    ra = await cl.call(ctx["A_owner"], "meta", "meta.read_account", "act_A1")
    rb = await cl.call(ctx["B_owner"], "meta", "meta.read_account", "act_B1")
    check("العميل A قرأ حسابه (act_A1)", ra.json()["ok"])
    check("العميل B قرأ حسابه (act_B1)", rb.json()["ok"])
    check("كل واحد استعمل توكنه هو (لا خلط)",
          up.calls[0].headers["authorization"].endswith(H.FAKE["ref-a-meta"]) and up.calls[1].headers["authorization"].endswith(H.FAKE["ref-b-meta"]))

    say("\n2) عميل يحاول يلمس حساب غيره")
    n = len(up.calls)
    r = await cl.call(ctx["A_owner"], "meta", "meta.read_account", "act_B1")
    check("A حاول يقرأ حساب B → مرفوض (403)", r.status_code == 403, r.json()["error"]["message"])
    r = await cl.call(ctx["B_mgr"], "meta", "meta.create_campaign", "act_A1", {"name": "x", "objective": "OUTCOME_TRAFFIC"}, idem=IDEM("x"))
    check("B حاول ينشئ حملة على حساب A → مرفوض (403)", r.status_code == 403)
    check("ولا طلب واحد وصل للمنصة من هذي المحاولات", len(up.calls) == n)

    say("\n3) منع تكرار الحملات")
    async def slow(_req):
        await asyncio.sleep(0)
        return httpx.Response(200, json={"id": "new-campaign-1"})
    up.calls.clear(); up.default = slow
    rs = await asyncio.gather(*[cl.call(ctx["A_mgr"], "meta", "meta.create_campaign", "act_A1", {"name": "حملة العرض", "objective": "OUTCOME_TRAFFIC"}, idem=IDEM("camp1")) for _ in range(10)])
    check("10 طلبات إنشاء متزامنة بنفس المفتاح → أُرسل طلب واحد فقط للمنصة", len(up.calls) == 1, f"{len(up.calls)} طلب")
    check("الحملة أُنشئت متوقفة (PAUSED) تلقائياً", json.loads(up.calls[0].content)["status"] == "PAUSED")
    up.default = None

    say("\n4) انقطاع غامض أثناء إنشاء حملة")
    up.calls.clear(); up.push(httpx.ReadTimeout("lost"))
    r1 = await cl.call(ctx["A_mgr"], "meta", "meta.create_campaign", "act_A1", {"name": "حملة ثانية", "objective": "OUTCOME_TRAFFIC"}, idem=IDEM("camp2"))
    r2 = await cl.call(ctx["A_mgr"], "meta", "meta.create_campaign", "act_A1", {"name": "حملة ثانية", "objective": "OUTCOME_TRAFFIC"}, idem=IDEM("camp2"))
    check("لا نعرف إذا انرسلت أو لا → النظام يرفض يعيد الإرسال (حتى لا تتكرر الحملة)", r1.json()["error"]["class"] == "outcome_unknown" and r2.json()["error"]["class"] == "outcome_unknown" and len(up.calls) == 1)

    say("\n5) خلل مؤقت من المنصة")
    up.calls.clear(); up.push((500, {}), (500, {}), OK)
    r = await cl.call(ctx["B_owner"], "meta", "meta.read_campaigns", "act_B1")
    check("المنصة فشلت مرتين ثم نجحت → النظام أعاد المحاولة تلقائياً (القراءة فقط)", r.json()["ok"] and len(up.calls) == 3, f"{len(up.calls)} محاولات")

    say("\n6) انتهاء توكن عميل")
    up.calls.clear(); up.push((400, {"error": {"code": 190, "message": "Error validating access token: Session has expired"}}))
    r = await cl.call(ctx["A_owner"], "meta", "meta.read_account", "act_A1")
    check("توكن A انتهى → النظام عرف وصنّفه «auth_expired»", r.json()["error"]["class"] == "auth_expired")
    n = len(up.calls)
    r = await cl.call(ctx["A_owner"], "meta", "meta.read_account", "act_A1")
    check("المحاولة التالية تفشل فوراً بدون ما تزعج المنصة", len(up.calls) == n)
    up.push(OK)
    rb = await cl.call(ctx["B_owner"], "meta", "meta.read_account", "act_B1")
    check("العميل B ما تأثر أبداً", rb.json()["ok"])
    st = H.sup_central("SELECT status FROM core.platform_connections WHERE secret_ref='ref-a-meta'")[0][0]
    check("حالة اتصال A صارت «expired» بالقاعدة المركزية", st == "expired", st)

    say("\n7) سرية التوكن")
    tok = H.FAKE["ref-b-meta"]
    up.push((400, {"error": {"code": 100, "message": f"Bad request. token={tok} Bearer {tok}"}}))
    r = await cl.call(ctx["B_owner"], "meta", "meta.read_account", "act_B1")
    check("المنصة أرجعت التوكن بالغلط داخل رسالة الخطأ → ظهر محجوب", tok not in r.text, r.json()["error"]["message"][:60])
    blob = "\n".join(cap.lines)
    check("التوكنات غير موجودة بأي سجل للخدمة", not any(v in blob for v in H.FAKE.values()))
    cipher = H.sup_vault("SELECT ciphertext FROM vault.secrets LIMIT 1")[0][0]
    check("التوكنات بقاعدة الأسرار مشفّرة (لا نص صريح)", H.FAKE["ref-a-meta"].encode() not in bytes(cipher))

    ok = sum(1 for _, c in results if c)
    say("\n" + "═" * 66)
    say(f"النتيجة: {ok} من {len(results)} فحص نجح" + ("  ✅ كل شي سليم" if ok == len(results) else "  ❌ في خلل"))
    say("═" * 66)
    await H.close_env((app, cl, up, sleeps, cm))
    return 0 if ok == len(results) else 1

sys.exit(asyncio.run(main()))
