"""نقطة التشغيل: uvicorn app.server:app  (يقرأ الإعدادات من البيئة؛ يرفض الإقلاع إن أُشير لمنصة حقيقية بدون تفعيل صريح)."""
from app.config import Settings
from app.main import create_app

app = create_app(Settings.from_env())
