"""الوصول لقاعدة vault: الأسرار المشفّرة، حالة السر، nonces، طلبات الكتابة، سجل المكالمات."""
import hashlib
import json
from typing import Optional

from cryptography.exceptions import InvalidTag
from psycopg.types.json import Jsonb

import envelope
import redact


class SecretMissing(Exception):
    pass


class IntegrityError(Exception):
    pass


class RefMismatch(Exception):
    pass


class VaultStore:
    def __init__(self, pool, kek: bytes):
        self.pool, self.kek = pool, kek

    # ───── الأسرار ─────
    async def open_latest(self, tenant_id: str, secret_ref: str) -> tuple:
        """يرجع (version, kind, plaintext_str). الاستعلام مقيّد بالعميل والمؤشر معاً + AAD مرتبط بالعميل."""
        async with self.pool.connection() as c:
            r = await (await c.execute(
                "SELECT version, kind, ciphertext, dek_wrapped FROM vault.secrets "
                "WHERE secret_ref = %s AND tenant_id = %s AND revoked_at IS NULL ORDER BY version DESC LIMIT 1",
                (secret_ref, tenant_id))).fetchone()
        if not r:
            raise SecretMissing(secret_ref)
        ver, kind, ct, dek = r
        try:
            plain = envelope.open_(envelope.Sealed(bytes(ct), bytes(dek)), self.kek, tenant_id, kind, ver, secret_ref).decode()
        except InvalidTag:
            raise IntegrityError(secret_ref)
        redact.KNOWN.add(plain)
        return ver, kind, plain

    async def put(self, tenant_id: str, kind: str, secret_ref: str, value: str) -> int:
        """تخزين نسخة جديدة (تدوير): version+1، وتُلغى النسخ السابقة. مؤشر واحد = عميل واحد ونوع واحد دائماً."""
        redact.KNOWN.add(value)
        async with self.pool.connection() as c:
            async with c.transaction():
                await c.execute("INSERT INTO vault.secret_refs (secret_ref, tenant_id, kind) VALUES (%s,%s,%s) ON CONFLICT DO NOTHING",
                                (secret_ref, tenant_id, kind))
                r = await (await c.execute("SELECT tenant_id::text, kind FROM vault.secret_refs WHERE secret_ref = %s FOR UPDATE", (secret_ref,))).fetchone()
                if r != (tenant_id, kind):
                    raise RefMismatch(secret_ref)
                ver = (await (await c.execute("SELECT coalesce(max(version),0)+1 FROM vault.secrets WHERE secret_ref = %s", (secret_ref,))).fetchone())[0]
                s = envelope.seal(value.encode(), self.kek, tenant_id, kind, ver, secret_ref)
                await c.execute("INSERT INTO vault.secrets (secret_ref, tenant_id, kind, version, ciphertext, dek_wrapped) VALUES (%s,%s,%s,%s,%s,%s)",
                                (secret_ref, tenant_id, kind, ver, s.ciphertext, s.dek_wrapped))
                await c.execute("UPDATE vault.secrets SET revoked_at = now(), rotated_at = now() WHERE secret_ref = %s AND version < %s AND revoked_at IS NULL", (secret_ref, ver))
                await c.execute("INSERT INTO vault.secret_state (secret_ref, state) VALUES (%s,'ok') ON CONFLICT (secret_ref) DO UPDATE SET state='ok', since=now(), detail=NULL", (secret_ref,))
        return ver

    async def revoke(self, tenant_id: str, secret_ref: str) -> int:
        async with self.pool.connection() as c:
            cur = await c.execute("UPDATE vault.secrets SET revoked_at = now() WHERE secret_ref = %s AND tenant_id = %s AND revoked_at IS NULL", (secret_ref, tenant_id))
            return cur.rowcount

    async def get_state(self, secret_ref: str) -> str:
        async with self.pool.connection() as c:
            r = await (await c.execute("SELECT state FROM vault.secret_state WHERE secret_ref = %s", (secret_ref,))).fetchone()
        return r[0] if r else "ok"

    async def set_state(self, secret_ref: str, state: str, detail: str = ""):
        async with self.pool.connection() as c:
            await c.execute("INSERT INTO vault.secret_state (secret_ref, state, detail) VALUES (%s,%s,%s) "
                            "ON CONFLICT (secret_ref) DO UPDATE SET state = EXCLUDED.state, since = now(), detail = EXCLUDED.detail",
                            (secret_ref, state, redact.redact_text(detail)[:200]))

    # ───── nonces (منع إعادة الإرسال عبر عدة عمليات) ─────
    async def use_nonce(self, key_id: str, nonce: str) -> bool:
        async with self.pool.connection() as c:
            cur = await c.execute("INSERT INTO vault.used_nonces (key_id, nonce) VALUES (%s,%s) ON CONFLICT DO NOTHING", (key_id, nonce))
            return cur.rowcount == 1

    async def purge_nonces(self, older_than_s: int = 300):
        async with self.pool.connection() as c:
            await c.execute("DELETE FROM vault.used_nonces WHERE at < now() - make_interval(secs => %s)", (older_than_s,))

    # ───── طلبات الكتابة ─────
    @staticmethod
    def request_hash(platform: str, op: str, ad_account: Optional[str], params: dict) -> bytes:
        return hashlib.sha256(json.dumps([platform, op, ad_account, params], sort_keys=True, ensure_ascii=False).encode()).digest()

    async def claim_write(self, tenant_id: str, key: str, h: bytes, platform: str, op: str, stale_after: int):
        """-> (state, response): new | replay | in_progress | conflict | unknown"""
        async with self.pool.connection() as c:
            async with c.transaction():
                await c.execute("UPDATE vault.write_requests SET state='unknown', updated_at=now() "
                                "WHERE tenant_id=%s AND idempotency_key=%s AND state='executing' AND updated_at < now() - make_interval(secs => %s)",
                                (tenant_id, key, stale_after))
                cur = await c.execute("INSERT INTO vault.write_requests (tenant_id, idempotency_key, request_hash, platform, op, state) "
                                      "VALUES (%s,%s,%s,%s,%s,'executing') ON CONFLICT DO NOTHING", (tenant_id, key, h, platform, op))
                if cur.rowcount == 1:
                    return "new", None
                r = await (await c.execute("SELECT request_hash, state, response FROM vault.write_requests WHERE tenant_id=%s AND idempotency_key=%s FOR UPDATE",
                                           (tenant_id, key))).fetchone()
                if bytes(r[0]) != h:
                    return "conflict", None
                if r[1] == "succeeded":
                    return "replay", r[2]
                if r[1] == "executing":
                    return "in_progress", None
                if r[1] == "unknown":
                    return "unknown", r[2]
                # failed: يُسمح بإعادة المحاولة بنفس المفتاح (المنصة رفضت أو لم تُرسل)
                await c.execute("UPDATE vault.write_requests SET state='executing', updated_at=now() WHERE tenant_id=%s AND idempotency_key=%s", (tenant_id, key))
                return "new", None

    async def finish_write(self, tenant_id: str, key: str, state: str, response: dict):
        async with self.pool.connection() as c:
            await c.execute("UPDATE vault.write_requests SET state=%s, response=%s, updated_at=now() WHERE tenant_id=%s AND idempotency_key=%s",
                            (state, Jsonb(response), tenant_id, key))

    # ───── السجل ─────
    async def log_call(self, tenant_id: str, platform: str, op: str, status: Optional[int], ms: int, error_code: Optional[str], idem: Optional[str]):
        async with self.pool.connection() as c:
            await c.execute("INSERT INTO vault.api_call_log (tenant_id, platform, endpoint, http_status, duration_ms, error_code, idempotency_key) VALUES (%s,%s,%s,%s,%s,%s,%s)",
                            (tenant_id, platform, op, status, ms, error_code, idem))

    async def ensure_partitions(self):
        async with self.pool.connection() as c:
            await c.execute("SELECT vault.ensure_log_partitions(2)")

    # ───── تدوير المفتاح الرئيسي (offline) ─────
    async def rewrap_all(self, old_kek: bytes, new_kek: bytes) -> int:
        """يعيد تغليف كل DEK بالـ KEK الجديد دون لمس النص المشفّر. معاملة واحدة: إما الكل أو لا شيء."""
        n = 0
        async with self.pool.connection() as c:
            async with c.transaction():
                rows = await (await c.execute("SELECT secret_ref, version, dek_wrapped FROM vault.secrets FOR UPDATE")).fetchall()
                for ref, ver, dek in rows:
                    new = envelope.rewrap(envelope.Sealed(b"", bytes(dek)), old_kek, new_kek, ref).dek_wrapped
                    await c.execute("UPDATE vault.secrets SET dek_wrapped = %s WHERE secret_ref = %s AND version = %s", (new, ref, ver))
                    n += 1
        self.kek = new_kek
        return n
