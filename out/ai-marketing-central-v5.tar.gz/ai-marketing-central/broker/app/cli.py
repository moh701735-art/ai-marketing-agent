"""أدوات إدارية offline:  python -m app.cli rewrap --old <b64> --new <b64>  (DSN من BROKER_VAULT_DSN)."""
import argparse
import asyncio
import os

from psycopg_pool import AsyncConnectionPool

import envelope
from app.store import VaultStore


async def _rewrap(old, new):
    pool = AsyncConnectionPool(os.environ["BROKER_VAULT_DSN"], open=False, kwargs={"autocommit": True})
    await pool.open()
    n = await VaultStore(pool, envelope.load_kek(old)).rewrap_all(envelope.load_kek(old), envelope.load_kek(new))
    await pool.close()
    print(f"rewrapped {n} secret versions")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("rewrap"); r.add_argument("--old", required=True); r.add_argument("--new", required=True)
    a = ap.parse_args()
    asyncio.run(_rewrap(a.old, a.new))


if __name__ == "__main__":
    main()
