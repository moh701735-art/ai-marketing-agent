"""معدّل الطلبات، قاطع الدائرة، وتأخير إعادة المحاولة. الساعة قابلة للحقن للاختبار."""
import time


class TokenBucket:
    def __init__(self, rate: float, burst: float, clock=time.monotonic):
        self.rate, self.burst, self.clock = rate, burst, clock
        self._b: dict = {}

    def allow(self, key) -> bool:
        now = self.clock()
        tokens, last = self._b.get(key, (self.burst, now))
        tokens = min(self.burst, tokens + (now - last) * self.rate)
        if tokens < 1:
            self._b[key] = (tokens, now)
            return False
        self._b[key] = (tokens - 1, now)
        return True


class Breaker:
    """closed -> (threshold فشل متتالٍ) -> open -> (بعد cooldown) -> half_open (محاولة واحدة) -> closed|open."""
    def __init__(self, threshold: int, cooldown: float, clock=time.monotonic):
        self.threshold, self.cooldown, self.clock = threshold, cooldown, clock
        self._s: dict = {}

    def _st(self, key):
        return self._s.setdefault(key, {"fails": 0, "opened": None, "probe": False})

    def allow(self, key) -> bool:
        s = self._st(key)
        if s["opened"] is None:
            return True
        if self.clock() - s["opened"] >= self.cooldown and not s["probe"]:
            s["probe"] = True
            return True
        return False

    def success(self, key):
        self._s[key] = {"fails": 0, "opened": None, "probe": False}

    def failure(self, key):
        s = self._st(key)
        s["fails"] += 1
        s["probe"] = False
        if s["fails"] >= self.threshold or s["opened"] is not None:
            s["opened"] = self.clock()

    def state(self, key) -> str:
        s = self._st(key)
        if s["opened"] is None:
            return "closed"
        return "half_open" if s["probe"] else "open"


def backoff_delay(attempt: int, base: float, cap: float, rng, retry_after=None) -> float:
    """full jitter: عشوائي في [0, min(cap, base*2^attempt)]؛ Retry-After من المنصة يرفع الحد الأدنى (بسقف)."""
    d = rng() * min(cap, base * (2 ** attempt))
    if retry_after is not None:
        d = max(d, min(float(retry_after), cap * 5))
    return d
