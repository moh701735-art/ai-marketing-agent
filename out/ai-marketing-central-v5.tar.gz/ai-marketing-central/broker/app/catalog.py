"""كتالوج العمليات المسموحة (allowlist). لا مسار ولا URL ولا رأس يأتي من المُستدعي: فقط اسم عملية + معاملات تُتحقق صارماً.
قيم forced تُفرض دائماً (مثلاً الحملة تُنشأ متوقفة PAUSED/DISABLE ولا يستطيع المُستدعي تغيير ذلك)."""
import re
from dataclasses import dataclass, field
from typing import Any, Optional

AD_ACCOUNT_RE = re.compile(r"[A-Za-z0-9_]{1,40}")
_SAFE = re.compile(r"[A-Za-z0-9_,.:\- ]{0,300}")
_DATE = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")
_CURSOR = re.compile(r"[A-Za-z0-9_=+/\-]{1,300}")
_ID = re.compile(r"[0-9]{1,24}")
_KW = re.compile(r"[a-z0-9][a-z0-9 &'\-]{1,38}[a-z0-9]")
_DATETIME = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}")


class Invalid(ValueError):
    pass


@dataclass(frozen=True)
class P:
    kind: str                       # str | text | int | num | enum | enums | date | cursor | safe | safelist
    required: bool = False
    values: tuple = ()
    lo: Optional[float] = None
    hi: Optional[float] = None
    max_len: int = 200


@dataclass(frozen=True)
class Op:
    name: str
    platform: str
    method: str
    path: str                       # قالب: {ad_account}
    write: bool = False
    needs_account: bool = True
    params: dict = field(default_factory=dict)
    forced: dict = field(default_factory=dict)       # تُدمج في الجسم/الاستعلام بعد التحقق
    defaults: dict = field(default_factory=dict)     # قيم افتراضية تُضاف فقط إذا لم يرسلها المُستدعي (يستطيع تغييرها ضمن params المسموحة)
    advertiser_param: Optional[str] = None            # tiktok: اسم الحقل الذي يحمل advertiser_id (يُفرض من ad_account)
    bearer: bool = True                               # meta: Authorization Bearer ; tiktok: Access-Token
    token_in_path: bool = False                       # telegram: التوكن جزء من المسار /bot<TOKEN>/...
    filter_keys: tuple = ()                           # tiktok GET: هذه المعاملات تُنقل إلى filtering={...} (JSON) كما تتطلب واجهة القوائم
    query_map: tuple = ()                             # tiktok GET: (param, query_name, item_key): قائمة معرفات -> [{item_key: id}] تحت اسم query_name
    text_ok: bool = False                             # الرد الناجح قد يكون نصاً (CSV): يُغلَّف كـ {"data": {"csv": ...}}


# عمليات إدارية: لا تُدرج في OPS فلا يستطيع n8n (مفتاح runtime) استدعاءها. تُستعمل فقط من /v1/admin/telegram/* (مفتاح admin).
ADMIN_OPS = {o.name: o for o in [
    Op("telegram.set_webhook", "telegram", "POST", "/bot{token}/setWebhook", needs_account=False, bearer=False, token_in_path=True),
    Op("telegram.get_webhook_info", "telegram", "GET", "/bot{token}/getWebhookInfo", needs_account=False, bearer=False, token_in_path=True),
    Op("telegram.delete_webhook", "telegram", "POST", "/bot{token}/deleteWebhook", needs_account=False, bearer=False, token_in_path=True),
]}


def _check(name, spec: P, v: Any):
    if spec.kind == "int":
        if isinstance(v, bool) or not isinstance(v, int) or not (spec.lo <= v <= spec.hi):
            raise Invalid(f"{name}: integer {spec.lo}..{spec.hi}")
    elif spec.kind == "num":
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not (spec.lo <= v <= spec.hi):
            raise Invalid(f"{name}: number {spec.lo}..{spec.hi}")
    elif spec.kind == "enum":
        if v not in spec.values:
            raise Invalid(f"{name}: one of {list(spec.values)}")
    elif spec.kind == "enums":
        if not isinstance(v, list) or not v or len(v) > 20 or any(x not in spec.values for x in v):
            raise Invalid(f"{name}: list of {list(spec.values)}")
    elif spec.kind == "safe":
        if not isinstance(v, str) or not _SAFE.fullmatch(v):
            raise Invalid(f"{name}: safe string")
    elif spec.kind == "safelist":
        if not isinstance(v, list) or not v or len(v) > 40 or any(not isinstance(x, str) or not re.fullmatch(r"[A-Za-z0-9_.]{1,60}", x) for x in v):
            raise Invalid(f"{name}: list of identifiers")
    elif spec.kind == "date":
        if not isinstance(v, str) or not _DATE.fullmatch(v):
            raise Invalid(f"{name}: YYYY-MM-DD")
    elif spec.kind == "cursor":
        if not isinstance(v, str) or not _CURSOR.fullmatch(v):
            raise Invalid(f"{name}: cursor")
    elif spec.kind == "message":  # رسالة تيليجرام: أسطر جديدة وتبويب مسموحان، لا أحرف تحكم أخرى
        if not isinstance(v, str) or not (1 <= len(v) <= spec.max_len) or any((ord(c) < 32 and c not in "\n\t") or ord(c) == 127 for c in v):
            raise Invalid(f"{name}: message 1..{spec.max_len} chars")
    elif spec.kind == "text":     # نص حر (اسم حملة عربي مثلاً): بلا أحرف تحكم
        if not isinstance(v, str) or not (1 <= len(v) <= spec.max_len) or any(ord(c) < 32 or ord(c) == 127 for c in v):
            raise Invalid(f"{name}: text 1..{spec.max_len} chars, no control characters")
    elif spec.kind == "bool":
        if not isinstance(v, bool):
            raise Invalid(f"{name}: boolean")
    elif spec.kind == "id":       # معرّف رقمي من المنصة (كمعرف حملة/صفحة)
        if not isinstance(v, (str, int)) or isinstance(v, bool) or not _ID.fullmatch(str(v)):
            raise Invalid(f"{name}: numeric id")
    elif spec.kind == "idlist":
        mx = int(spec.hi) if spec.hi else 20
        if not isinstance(v, list) or not (1 <= len(v) <= mx) or any(isinstance(x, bool) or not isinstance(x, (str, int)) or not _ID.fullmatch(str(x)) for x in v):
            raise Invalid(f"{name}: list of 1..{mx} numeric ids")
    elif spec.kind == "keywords":     # كلمات اهتمام قصيرة بالإنجليزية (تُبحث في TikTok)
        if not isinstance(v, list) or not (1 <= len(v) <= 30) or any(not isinstance(x, str) or not _KW.fullmatch(x) for x in v):
            raise Invalid(f"{name}: 1..30 short english keywords")
    elif spec.kind == "datetime":
        if not isinstance(v, str) or not _DATETIME.fullmatch(v):
            raise Invalid(f"{name}: YYYY-MM-DD HH:MM:SS")
    elif spec.kind == "creatives":      # إعلانات Spark: قائمة محدودة بحقول محددة فقط (identity_type يُفرض AUTH_CODE)
        if not isinstance(v, list) or not (1 <= len(v) <= 10):
            raise Invalid(f"{name}: 1..10 creatives")
        allowed = {"ad_name", "ad_format", "identity_id", "tiktok_item_id", "ad_text", "call_to_action", "page_id", "card_id"}
        for c in v:
            if not isinstance(c, dict) or set(c) - allowed or not {"ad_name", "identity_id", "tiktok_item_id"} <= set(c):
                raise Invalid(f"{name}: bad creative fields")
            _check("ad_name", P("text", required=True, max_len=200), c["ad_name"])
            _check("identity_id", P("safe"), c["identity_id"])
            _check("tiktok_item_id", P("id"), c["tiktok_item_id"])
            if "ad_text" in c:
                _check("ad_text", P("text", max_len=100), c["ad_text"])
            if "ad_format" in c:
                _check("ad_format", P("enum", values=("SINGLE_VIDEO", "CAROUSEL_ADS")), c["ad_format"])
            if "call_to_action" in c:
                _check("call_to_action", P("enum", values=CTA_TT), c["call_to_action"])
            if "page_id" in c:
                _check("page_id", P("id"), c["page_id"])
            if "card_id" in c:
                _check("card_id", P("id"), c["card_id"])
    else:
        raise Invalid(f"{name}: unsupported spec")


def validate(op: Op, params: dict) -> dict:
    if not isinstance(params, dict):
        raise Invalid("params must be an object")
    extra = set(params) - set(op.params)
    if extra:
        raise Invalid(f"unknown params: {sorted(extra)}")
    for k, spec in op.params.items():
        if k not in params:
            if spec.required:
                raise Invalid(f"missing param: {k}")
            continue
        _check(k, spec, params[k])
    clean = dict(params)
    for k, spec in op.params.items():
        if spec.kind == "creatives" and k in clean:
            clean[k] = [dict(c, identity_type="AUTH_CODE") for c in clean[k]]
    for _k, _v in op.defaults.items():
        clean.setdefault(_k, _v)
    clean.update(op.forced)          # المفروض يتغلب على أي قيمة
    return clean


OBJ_META = ("OUTCOME_TRAFFIC", "OUTCOME_ENGAGEMENT", "OUTCOME_LEADS", "OUTCOME_SALES", "OUTCOME_AWARENESS", "OUTCOME_APP_PROMOTION")
OBJ_TT = ("TRAFFIC", "VIDEO_VIEWS", "LEAD_GENERATION", "ENGAGEMENT", "REACH", "CONVERSIONS", "WEB_CONVERSIONS", "PRODUCT_SALES")
CTA_TT = ("CONTACT_US", "LEARN_MORE", "SHOP_NOW", "SIGN_UP", "ORDER_NOW", "APPLY_NOW", "BOOK_NOW", "SEND_MESSAGE")
AGE_TT = ("AGE_13_17", "AGE_18_24", "AGE_25_34", "AGE_35_44", "AGE_45_54", "AGE_55_100")

OPS = {o.name: o for o in [
    Op("telegram.send_message", "telegram", "POST", "/bot{token}/sendMessage", bearer=False, token_in_path=True, advertiser_param="chat_id",
       params={"text": P("message", required=True, max_len=3800)}),
    Op("telegram.get_me", "telegram", "GET", "/bot{token}/getMe", needs_account=False, bearer=False, token_in_path=True),
    Op("telegram.get_webhook_info", "telegram", "GET", "/bot{token}/getWebhookInfo", needs_account=False, bearer=False, token_in_path=True),
    Op("meta.me", "meta", "GET", "/me", needs_account=False, params={"fields": P("safe")}),
    Op("meta.permissions", "meta", "GET", "/me/permissions", needs_account=False),
    Op("meta.read_pages", "meta", "GET", "/me/accounts", needs_account=False, params={"fields": P("safe"), "limit": P("int", lo=1, hi=200)}),
    # فحص إنشاء بلا أثر: Meta تدعم execution_options=validate_only (لا تُنشئ شيئاً). ليست write لذلك: لا idempotency ولا أثر.
    Op("meta.validate_campaign", "meta", "POST", "/{ad_account}/campaigns",
       params={"name": P("text", required=True, max_len=200), "objective": P("enum", required=True, values=OBJ_META)},
       forced={"status": "PAUSED", "execution_options": ["validate_only"]}),
    Op("meta.read_account", "meta", "GET", "/{ad_account}", params={"fields": P("safe")}),
    Op("meta.read_campaigns", "meta", "GET", "/{ad_account}/campaigns",
       params={"fields": P("safe"), "limit": P("int", lo=1, hi=200), "after": P("cursor"),
               "effective_status": P("enums", values=("ACTIVE", "PAUSED", "DELETED", "ARCHIVED"))}),
    Op("meta.read_insights", "meta", "GET", "/{ad_account}/insights",
       params={"fields": P("safe"), "date_preset": P("enum", values=("today", "yesterday", "last_7d", "last_30d", "this_month")),
               "level": P("enum", values=("account", "campaign", "adset", "ad")), "limit": P("int", lo=1, hi=500), "after": P("cursor")}),
    Op("meta.create_campaign", "meta", "POST", "/{ad_account}/campaigns", write=True,
       params={"name": P("text", required=True, max_len=200), "objective": P("enum", required=True, values=OBJ_META),
               "special_ad_categories": P("enums", values=("NONE", "HOUSING", "EMPLOYMENT", "CREDIT", "ISSUES_ELECTIONS_POLITICS"))},
       forced={"status": "PAUSED"}),
    Op("tiktok.read_advertiser", "tiktok", "GET", "/advertiser/info/", bearer=False, advertiser_param="advertiser_ids",
       params={"fields": P("safelist")}),
    Op("tiktok.read_campaigns", "tiktok", "GET", "/campaign/get/", bearer=False, advertiser_param="advertiser_id",
       params={"page": P("int", lo=1, hi=1000), "page_size": P("int", lo=1, hi=100)}),
    Op("tiktok.read_report", "tiktok", "GET", "/report/integrated/get/", bearer=False, advertiser_param="advertiser_id",
       params={"report_type": P("enum", required=True, values=("BASIC",)),
               "data_level": P("enum", required=True, values=("AUCTION_ADVERTISER", "AUCTION_CAMPAIGN", "AUCTION_ADGROUP", "AUCTION_AD")),
               "dimensions": P("safelist", required=True), "metrics": P("safelist", required=True),
               "start_date": P("date", required=True), "end_date": P("date", required=True), "page_size": P("int", lo=1, hi=1000)}),
    Op("tiktok.create_campaign", "tiktok", "POST", "/campaign/create/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"campaign_name": P("text", required=True, max_len=512), "objective_type": P("enum", required=True, values=OBJ_TT),
               "budget_mode": P("enum", values=("BUDGET_MODE_DAY", "BUDGET_MODE_TOTAL", "BUDGET_MODE_INFINITE")),
               "budget": P("num", lo=1, hi=1_000_000), "sales_destination": P("enum", values=("WEBSITE",)), "virtual_objective_type": P("enum", values=("SALES",))},
       forced={"operation_status": "DISABLE"}),
    # ───── إنشاء حملة Spark كاملة (كلها تُنشأ DISABLE): صفحات فورية، فيديو Spark، مجموعة إعلانية، إعلان ─────
    Op("tiktok.read_instant_pages", "tiktok", "GET", "/page/get/", bearer=False, advertiser_param="advertiser_id",
       params={"business_type": P("enum", required=True, values=("TIKTOK_INSTANT_PAGE", "LEAD_GEN")), "status": P("enum", values=("PUBLISHED",))}),
    # قراءة حملات Upgraded Smart+ (شكل الرد يطابق شكل طلب الإنشاء): لنسخ الحقول الفعلية من حملة منشورة. قراءة فقط.
    Op("tiktok.sp_read_campaigns", "tiktok", "GET", "/smart_plus/campaign/get/", bearer=False, advertiser_param="advertiser_id", filter_keys=("campaign_ids",),
       params={"campaign_ids": P("idlist", required=True), "page_size": P("int", lo=1, hi=100)}),
    Op("tiktok.sp_read_adgroups", "tiktok", "GET", "/smart_plus/adgroup/get/", bearer=False, advertiser_param="advertiser_id", filter_keys=("campaign_ids",),
       params={"campaign_ids": P("idlist", required=True), "page_size": P("int", lo=1, hi=100)}),
    Op("tiktok.sp_read_ads", "tiktok", "GET", "/smart_plus/ad/get/", bearer=False, advertiser_param="advertiser_id", filter_keys=("campaign_ids",),
       params={"campaign_ids": P("idlist", required=True), "page_size": P("int", lo=1, hi=100)}),
    Op("tiktok.read_message_event_set", "tiktok", "GET", "/ctm/message_event_set/get/", bearer=False, advertiser_param="advertiser_id",
       params={"messaging_app_type": P("enum", required=True, values=("WHATSAPP",)), "messaging_app_account_id": P("id", required=True)}),
    Op("tiktok.read_video_info", "tiktok", "GET", "/tt_video/info/", bearer=False, advertiser_param="advertiser_id",
       params={"auth_code": P("text", required=True, max_len=300)}),
    Op("tiktok.authorize_video", "tiktok", "POST", "/tt_video/authorize/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"auth_code": P("text", required=True, max_len=300)}),
    Op("tiktok.create_adgroup", "tiktok", "POST", "/adgroup/create/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"campaign_id": P("id", required=True), "adgroup_name": P("text", required=True, max_len=512),
               "location_ids": P("idlist", required=True), "budget_mode": P("enum", required=True, values=("BUDGET_MODE_DAY", "BUDGET_MODE_TOTAL")),
               "budget": P("num", required=True, lo=1, hi=100_000_000),
               "optimization_goal": P("enum", required=True, values=("CLICK", "CONVERT", "LEAD_GENERATION", "ENGAGED_VIEW", "REACH", "SHOW", "CONVERSATION")),
               "billing_event": P("enum", required=True, values=("CPC", "OCPM", "CPM", "CPV")),
               "schedule_type": P("enum", required=True, values=("SCHEDULE_START_END", "SCHEDULE_FROM_NOW")),
               "schedule_start_time": P("datetime", required=True), "schedule_end_time": P("datetime"),
               "promotion_type": P("enum", values=("WEBSITE", "LEAD_GENERATION", "EXTERNAL_OR_DISPLAY", "LEAD_GEN_CLICK_TO_SOCIAL_MEDIA_APP_MESSAGE")),
               "promotion_website_type": P("enum", values=("TIKTOK_NATIVE_PAGE",)), "promotion_target_type": P("enum", values=("INSTANT_PAGE",)),
               "optimization_event": P("enum", values=("BUTTON", "MESSAGE")), "search_result_enabled": P("bool"), "gender": P("enum", values=("GENDER_UNLIMITED", "GENDER_MALE", "GENDER_FEMALE")),
               "age_groups": P("enums", values=AGE_TT), "purchase_intention_keyword_ids": P("idlist"), "smart_interest_behavior_enabled": P("bool"),
               "interest_keyword_ids": P("idlist", hi=500),
               "bid_type": P("enum", values=("BID_TYPE_NO_BID", "BID_TYPE_CUSTOM")), "conversion_bid_price": P("num", lo=0.0001, hi=100_000_000),     # سقف/سعر مستهدف للتحويل (مثل الحملة اليدوية)؛ بلا إرساله: أقل تكلفة
               "messaging_app_type": P("enum", values=("WHATSAPP",)), "messaging_app_account_id": P("id"), "message_event_set_id": P("id"),
               "phone_region_code": P("enum", values=("IQ",)), "phone_region_calling_code": P("enum", values=("+964",)), "phone_number": P("id")},
       defaults={"bid_type": "BID_TYPE_NO_BID"},
       forced={"operation_status": "DISABLE", "placement_type": "PLACEMENT_TYPE_NORMAL", "placements": ["PLACEMENT_TIKTOK"], "pacing": "PACING_MODE_SMOOTH"}),
    Op("tiktok.create_ad", "tiktok", "POST", "/ad/create/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"adgroup_id": P("id", required=True), "creatives": P("creatives", required=True)},
       forced={"operation_status": "DISABLE"}),
    # ───── Smart+ لواتساب (نفس واجهات الورك فلو القديم): حملة بميزانية CBO ← مجموعة باستهداف تلقائي ← CTA ← إعلان. الحملة DISABLE؛ المجموعة والإعلان ENABLE تحتها (لا صرف قبل تفعيل الحملة) ─────
    Op("tiktok.sp_create_campaign", "tiktok", "POST", "/smart_plus/campaign/create/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"campaign_name": P("text", required=True, max_len=512), "budget": P("num", required=True, lo=1, hi=100_000_000),
               "budget_mode": P("enum", required=True, values=("BUDGET_MODE_TOTAL", "BUDGET_MODE_DYNAMIC_DAILY"))},
       forced={"operation_status": "DISABLE", "objective_type": "LEAD_GENERATION", "budget_optimize_on": True}),
    Op("tiktok.sp_create_adgroup", "tiktok", "POST", "/smart_plus/adgroup/create/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"campaign_id": P("id", required=True), "adgroup_name": P("text", required=True, max_len=512),
               "schedule_start_time": P("datetime", required=True), "schedule_end_time": P("datetime", required=True),
               "message_event_set_id": P("id", required=True), "phone_number": P("id", required=True)},
       forced={"promotion_type": "LEAD_GEN_CLICK_TO_SOCIAL_MEDIA_APP_MESSAGE", "optimization_goal": "CONVERSATION", "messaging_app_type": "WHATSAPP",
               "bid_type": "BID_TYPE_NO_BID", "billing_event": "OCPM", "placement_type": "PLACEMENT_TYPE_NORMAL", "placements": ["PLACEMENT_TIKTOK"],
               "schedule_type": "SCHEDULE_START_END", "targeting_optimization_mode": "AUTOMATIC",
               "targeting_spec": {"location_ids": ["99237"], "spc_audience_age": "OVER_EIGHTEEN"}, "operation_status": "ENABLE"}),
    Op("tiktok.create_cta_portfolio", "tiktok", "POST", "/creative/portfolio/create/", write=True, bearer=False, advertiser_param="advertiser_id",
       forced={"creative_portfolio_type": "CTA", "portfolio_content": [{"asset_content": "إرسال رسالة", "asset_ids": ["203711", "203712"]}]}),
    Op("tiktok.sp_create_ad", "tiktok", "POST", "/smart_plus/ad/create/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"adgroup_id": P("id", required=True), "ad_name": P("text", required=True, max_len=512), "ad_text": P("text", required=True, max_len=100),
               "cta_portfolio_id": P("id", required=True), "creatives": P("creatives", required=True)},
       forced={"operation_status": "ENABLE"}),
    # ───── استهداف مرتبط بالمنتج: اقتراح اهتمامات TikTok من كلمات المنتج ثم التحقق من صلاحيتها ─────
    Op("tiktok.recommend_interests", "tiktok", "GET", "/tool/interest_keyword/recommend/", bearer=False, advertiser_param="advertiser_id",
       params={"keywords": P("keywords", required=True), "language": P("enum", values=("en",)), "limit": P("int", lo=1, hi=100)}),
    Op("tiktok.check_interests", "tiktok", "GET", "/tool/interest_keyword/get/", bearer=False, advertiser_param="advertiser_id", query_map=(("keyword_ids", "keyword_query", "keyword_id"),),
       params={"keyword_ids": P("idlist", required=True, hi=50)}),
    # ───── تفعيل/إيقاف (الإيقاف يخفّض الصرف؛ التفعيل يُطلب فقط بأمر صريح من مستخدم manager+ عبر tiktok.activate_campaign) ─────
    # ───── سحب طلبات الاستمارات (نفس واجهات الورك فلو القديم): مهمة تنزيل ← حالتها ← ملف CSV ─────
    Op("tiktok.create_lead_task", "tiktok", "POST", "/page/lead/task/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"page_id": P("id", required=True)}),
    Op("tiktok.read_lead_task", "tiktok", "POST", "/page/lead/task/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"task_id": P("id", required=True)}),
    Op("tiktok.download_leads", "tiktok", "GET", "/page/lead/task/download/", bearer=False, advertiser_param="advertiser_id", text_ok=True,
       params={"task_id": P("id", required=True)}),
    # تصحيح بعد الإنشاء: TikTok قد تتجاهل search_result_enabled=false عند الإنشاء؛ هذا التحديث يغيّر هذا الحقل فقط
    Op("tiktok.update_adgroup", "tiktok", "POST", "/adgroup/update/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"adgroup_id": P("id", required=True), "search_result_enabled": P("bool", required=True)}),
    Op("tiktok.read_adgroups", "tiktok", "GET", "/adgroup/get/", bearer=False, advertiser_param="advertiser_id", filter_keys=("campaign_ids",),
       params={"campaign_ids": P("idlist", required=True), "page_size": P("int", lo=1, hi=100)}),
    Op("tiktok.read_ads", "tiktok", "GET", "/ad/get/", bearer=False, advertiser_param="advertiser_id", filter_keys=("campaign_ids",),
       params={"campaign_ids": P("idlist", required=True), "page_size": P("int", lo=1, hi=100)}),
    # كل إعلانات الحساب (صفحات) بحقول محددة فقط: لمعرفة إن كان فيديو/كود Spark سبق ترويجه بهذا الحساب
    Op("tiktok.read_ads_all", "tiktok", "GET", "/ad/get/", bearer=False, advertiser_param="advertiser_id",
       params={"fields": P("safelist"), "page": P("int", lo=1, hi=100), "page_size": P("int", lo=1, hi=1000)}),
    Op("tiktok.set_campaign_status", "tiktok", "POST", "/campaign/status/update/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"campaign_ids": P("idlist", required=True), "operation_status": P("enum", required=True, values=("ENABLE", "DISABLE"))}),
    Op("tiktok.set_adgroup_status", "tiktok", "POST", "/adgroup/status/update/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"adgroup_ids": P("idlist", required=True), "operation_status": P("enum", required=True, values=("ENABLE", "DISABLE"))}),
    Op("tiktok.set_ad_status", "tiktok", "POST", "/ad/status/update/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"ad_ids": P("idlist", required=True), "operation_status": P("enum", required=True, values=("ENABLE", "DISABLE"))}),
    # ───── مراجعة الإعلانات والطعن (نفس واجهتي الورك فلو القديم): حالة المراجعة وسبب الرفض، ثم طلب مراجعة يدوية ─────
    Op("tiktok.read_adgroup_review", "tiktok", "GET", "/adgroup/review_info/", bearer=False, advertiser_param="advertiser_id",
       params={"adgroup_ids": P("idlist", required=True, hi=20), "lang": P("enum", values=("en",))}),
    Op("tiktok.appeal_adgroup", "tiktok", "POST", "/adgroup/appeal/", write=True, bearer=False, advertiser_param="advertiser_id",
       params={"adgroup_id": P("id", required=True), "ad_id": P("id"), "appeal_reason": P("text", required=True, max_len=1000)}),
]}
