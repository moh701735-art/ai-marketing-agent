"""إنشاء حملة تيك توك كاملة بإعلان Spark (صفحة فورية + فيديو مفوَّض) خطوة واحدة موثوقة. كل شيء يُنشأ DISABLE (لا صرف قبل تفعيل صريح).
كل خطوة تمر عبر Broker.call العادي (تفويض القاعدة، الكتالوج، idempotency، القاطع)؛ هذا الملف يجمع الخطوات فقط."""
import datetime
import re
import unicodedata

IRAQ = ["99237"]
SALES_INTENT = ["26", "20", "17", "21", "27"]          # purchase_intention_keyword_ids (نفس المستعمل بالنظام القديم)
OBJECTIVES = {"sales": "WEB_CONVERSIONS", "leads": "LEAD_GENERATION", "whatsapp": "LEAD_GENERATION"}     # Product sales تفشل بالمجموعة (assetOwner)، وUpgraded Smart+ يحتاج allowlist من تيك توك
CODE_RE = re.compile(r"[A-Za-z0-9+/=_\-#.]{12,300}")


def wa_local(v) -> str:
    """رقم واتساب عراقي -> الجزء المحلي (7XXXXXXXXX) أو ''."""
    d = re.sub(r"\D", "", str(v or ""))
    d = d[2:] if d.startswith("00") else d
    local = d[3:] if d.startswith("964") else d[1:] if d.startswith("0") else d
    return local if re.fullmatch(r"7[0-9]{9}", local) else ""


def norm(s: str) -> str:
    s = unicodedata.normalize("NFKC", str(s or "")).lower()
    s = re.sub("[ً-ٟـ]", "", s)
    s = re.sub("[أإآٱ]", "ا", s).replace("ة", "ه").replace("ى", "ي")
    return " ".join(re.sub(r"[^\w]+", " ", s).split())


def lev(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def pick_page(pages: list, wanted: str):
    """-> (page|None, reason). بالاسم: تطابق ≥0.75؛ بلا اسم: صفحة واحدة فقط وإلا يطلب التحديد. لا اختيار عشوائي."""
    pages = [p for p in pages if isinstance(p, dict) and p.get("page_id")]
    if not pages:
        return None, "no_pages"
    if not wanted:
        return (pages[0], None) if len(pages) == 1 else (None, "page_required")
    t, best, bs = norm(wanted), None, 0.0
    for p in pages:
        n = norm(p.get("title"))
        if not n:
            continue
        sc = 1.0 if n == t else max(1 - lev(n, t) / max(len(n), len(t)), 0.85 if (t in n or n in t) else 0)
        if sc > bs:
            best, bs = p, sc
    return (best, None) if best and bs >= 0.75 else (None, "page_not_found")


def validate(params: dict):
    """-> (clean, error_msg)"""
    allowed = {"campaign_name", "objective", "budget", "budget_mode", "days", "spark_codes", "page_name", "ad_text", "product", "interest_count", "auto_activate", "activate_now", "whatsapp_number", "use_interests", "smart", "cost_cap"}
    if not isinstance(params, dict) or set(params) - allowed:
        return None, "unknown params"
    n = params.get("campaign_name")
    if not isinstance(n, str) or not (1 <= len(n) <= 200) or any(ord(c) < 32 for c in n):
        return None, "campaign_name"
    if params.get("objective") not in OBJECTIVES:
        return None, "objective must be sales|leads|whatsapp"
    b = params.get("budget")
    if isinstance(b, bool) or not isinstance(b, (int, float)) or not (1 <= b <= 100_000_000):
        return None, "budget"
    if params.get("budget_mode") not in ("daily", "total"):
        return None, "budget_mode must be daily|total"
    d = params.get("days")
    if isinstance(d, bool) or not isinstance(d, int) or not (1 <= d <= 90):
        return None, "days 1..90"
    codes = params.get("spark_codes")
    if not isinstance(codes, list) or not (1 <= len(codes) <= 5) or any(not isinstance(c, str) or not CODE_RE.fullmatch(c) for c in codes):
        return None, "spark_codes: 1..5 codes"
    for k, mx in (("page_name", 80), ("ad_text", 100), ("product", 200)):
        v = params.get(k)
        if v is not None and (not isinstance(v, str) or len(v) > mx or any(ord(c) < 32 for c in v)):
            return None, k
    if not isinstance(params.get("auto_activate", True), bool) or not isinstance(params.get("activate_now", False), bool) or not isinstance(params.get("use_interests", False), bool):
        return None, "auto_activate/activate_now/use_interests"
    if not isinstance(params.get("smart", False), bool) or (params.get("smart") and params["objective"] != "whatsapp"):
        return None, "smart only for objective whatsapp"
    cc = params.get("cost_cap")
    if cc is not None and (isinstance(cc, bool) or not isinstance(cc, (int, float)) or not (0.0001 <= cc <= 100_000_000)):
        return None, "cost_cap must be a positive number (account currency)"
    wa = ""
    if params["objective"] == "whatsapp":
        wa = wa_local(params.get("whatsapp_number"))
        if not wa:
            return None, "whatsapp_number: Iraqi mobile (07XXXXXXXXX)"
    elif params.get("whatsapp_number") not in (None, ""):
        return None, "whatsapp_number only for objective whatsapp"
    ic = params.get("interest_count", 450)
    if isinstance(ic, bool) or not isinstance(ic, int) or not (20 <= ic <= 500):
        return None, "interest_count 20..500"
    return {**params, "auto_activate": params.get("auto_activate", True), "activate_now": params.get("activate_now", False), "interest_count": ic, "use_interests": params.get("use_interests", False), "smart": params.get("smart", False), "cost_cap": cc, "page_name": (params.get("page_name") or "").strip(), "whatsapp_number": wa, "ad_text": (params.get("ad_text") or "").strip(), "product": (params.get("product") or "").strip()}, None


def adgroup_params(p: dict, campaign_id: str, name: str, now: datetime.datetime, interest_ids: list = None, wa: dict = None) -> dict:
    start = now + datetime.timedelta(minutes=10)
    end = start + datetime.timedelta(days=p["days"])
    f = "%Y-%m-%d %H:%M:%S"
    a = {"campaign_id": campaign_id, "adgroup_name": name, "location_ids": IRAQ,
         "budget_mode": "BUDGET_MODE_DAY" if p["budget_mode"] == "daily" else "BUDGET_MODE_TOTAL", "budget": p["budget"],
         "schedule_type": "SCHEDULE_START_END", "schedule_start_time": start.strftime(f), "schedule_end_time": end.strftime(f),
         "gender": "GENDER_UNLIMITED", "billing_event": "OCPM"}
    if p["objective"] == "sales":
        a.update(optimization_goal="CONVERT", promotion_type="WEBSITE", promotion_website_type="TIKTOK_NATIVE_PAGE", optimization_event="BUTTON",
                 purchase_intention_keyword_ids=SALES_INTENT, smart_interest_behavior_enabled=True,
                 age_groups=["AGE_18_24", "AGE_25_34", "AGE_35_44", "AGE_45_54"])
    elif wa:        # رسائل واتساب (نفس حقول الورك فلو القديم): تحسين على المحادثات لا على ضغطات الزر
        a.update(optimization_goal="CONVERSATION", promotion_type="LEAD_GEN_CLICK_TO_SOCIAL_MEDIA_APP_MESSAGE", optimization_event="MESSAGE", messaging_app_type="WHATSAPP",
                 messaging_app_account_id="964" + wa["local"], message_event_set_id=wa["event_set"], phone_region_code="IQ", phone_region_calling_code="+964",
                 phone_number=wa["local"], age_groups=["AGE_18_24", "AGE_25_34", "AGE_35_44", "AGE_45_54", "AGE_55_100"])
    else:
        a.update(optimization_goal="LEAD_GENERATION", promotion_type="LEAD_GENERATION", promotion_target_type="INSTANT_PAGE",
                 age_groups=["AGE_25_34", "AGE_35_44", "AGE_45_54"])
    if p.get("cost_cap"):                  # مثل الحملة اليدوية (BID_TYPE_CUSTOM + سعر مستهدف للتحويل)؛ بلا سقف: أقل تكلفة (الافتراضي من الكتالوج)
        a["bid_type"], a["conversion_bid_price"] = "BID_TYPE_CUSTOM", p["cost_cap"]
    a["search_result_enabled"] = False        # "Include search results" مطفي دائماً (طلب المالك): لا نتائج بحث ضمن مكان TikTok
    if not p.get("use_interests", False):  # بدون اهتمامات (طلب المالك): استهداف عام فقط (الموقع + العمر + الجنس)، لا نية شراء ولا اهتمامات ذكية
        for k in ("purchase_intention_keyword_ids", "smart_interest_behavior_enabled"):
            a.pop(k, None)
    elif interest_ids:                    # استهداف مرتبط بالمنتج: يحل محل نية الشراء العامة والاهتمامات الذكية
        for k in ("purchase_intention_keyword_ids", "smart_interest_behavior_enabled"):
            a.pop(k, None)
        a["interest_keyword_ids"] = [str(i) for i in interest_ids][:500]
    return a
