"""منطق الاستدعاء: تفويض من القاعدة -> فحوص -> إعادة محاولة/قاطع -> تصنيف -> سجل. لا يطبع ولا يعيد أي سر."""
import asyncio
import base64
import datetime
import hashlib
import json
import logging
import math
import random
import re
import sys
import time
from typing import Optional
from urllib.parse import quote

import httpx

from app import catalog
from app import classify
from app import leads
from app import llm
from app import spark
import redact
from app.central import AuthzError
from app.resilience import Breaker, TokenBucket, backoff_delay
from app.store import IntegrityError, SecretMissing

_NAME_STOP = {"حمله", "حملة", "الحمله", "الحملة", "نتائج", "نتايج", "شلونها", "شلون", "شنو", "وضع", "حاله", "حالة", "كم", "اريد", "ابي", "اشوف", "عن", "هاي", "هذي", "هذه", "جاي", "دا", "نشاط"}


def _norm_ar(s) -> str:
    """توحيد نص عربي للمطابقة: بلا تشكيل/تطويل، همزات وياء وتاء مربوطة موحّدة، حروف صغيرة، بلا رموز."""
    s = re.sub(r"[\u064B-\u065F\u0640]", "", str(s or "").lower())
    s = s.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا").replace("ٱ", "ا").replace("ى", "ي").replace("ة", "ه")
    return re.sub(r"[^\w\s]", " ", s)


def _name_tokens(q) -> list:
    stop = {_norm_ar(x) for x in _NAME_STOP}
    return [t for t in _norm_ar(q).split() if len(t) >= 2 and t not in stop]


def _name_match(q_toks: list, name: str) -> tuple:
    """-> (score, exact). exact = كل كلمات السؤال موجودة باسم الحملة."""
    n = _norm_ar(name)
    hits = sum(1 for t in q_toks if t in n)
    exact = bool(q_toks) and hits == len(q_toks)
    return (hits / len(q_toks) + (1 if exact else 0) + (0.5 if " ".join(q_toks) in n else 0)) if q_toks else 0.0, exact


launch_log = logging.getLogger("broker.launch")       # سجل منظم لكل مرحلة إنشاء حملة (الطلب الفعلي لتيك توك + الرد). الأسرار محجوبة؛ للقراءة: docker logs central-stg-broker | grep launch_step
if not launch_log.handlers:
    _h = logging.StreamHandler(sys.stdout)
    _h.setFormatter(logging.Formatter("%(message)s"))
    launch_log.addHandler(_h)
    launch_log.setLevel(logging.INFO)
    launch_log.propagate = False

PRE_SEND = (httpx.ConnectError, httpx.ConnectTimeout)     # فشل قبل وصول الطلب للمنصة: آمن لإعادة المحاولة حتى للكتابة


def scrub(obj):
    """يمرّر كل النصوص في الرد على فلتر الإخفاء (سر معروف أو نمط توكن)."""
    if isinstance(obj, str):
        return redact.redact_text(obj)
    if isinstance(obj, dict):
        return {k: scrub(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [scrub(v) for v in obj]
    return obj


WEBHOOK_BOT_RE = re.compile(r"[A-Za-z0-9_-]{22,64}")
WEBHOOK_SECRET_RE = re.compile(r"[A-Za-z0-9_-]{16,256}")      # حروف secret_token المسموحة عند تيليجرام


class Broker:
    def __init__(self, settings, store, central, client: httpx.AsyncClient, *, clock=time.monotonic, sleep=asyncio.sleep, rng=random.random):
        self.s, self.store, self.central, self.client = settings, store, central, client
        self.sleep, self.rng = sleep, rng
        self.bucket = TokenBucket(settings.rate_per_sec, settings.rate_burst, clock)
        self.breaker = Breaker(settings.breaker_threshold, settings.breaker_cooldown, clock)
        self.llm_bucket = TokenBucket(0.5, 5.0, clock)          # فهم الرسائل: 5 دفعة ثم رسالة كل ثانيتين لكل عميل
        if settings.llm_key:
            redact.KNOWN.add(settings.llm_key)

    # ───── بناء طلب المنصة ─────
    def _build(self, op: catalog.Op, ad_account: Optional[str], params: dict, token: str):
        base = self.s.base_urls[op.platform].rstrip("/")
        path = op.path
        if "{ad_account}" in path:
            path = path.replace("{ad_account}", quote(ad_account or "", safe=""))
        if op.token_in_path:
            path = path.replace("{token}", quote(token, safe=":"))
        headers = {"Authorization": f"Bearer {token}"} if op.bearer else ({} if op.token_in_path else {"Access-Token": token})
        q, body = {}, None
        p = dict(params)
        if op.name in ("meta.validate_campaign", "meta.create_campaign"):
            p.setdefault("special_ad_categories", [])          # Meta تشترطه بإنشاء الحملات (قائمة فارغة = لا فئة خاصة)
        if op.name == "tiktok.sp_create_adgroup":          # حقول Smart+ المتداخلة تُبنى هنا من قيم مسطحة محققة
            p["phone_info"] = {"phone_number": str(p.pop("phone_number")), "phone_region_calling_code": "+964", "phone_region_code": "IQ"}
        elif op.name == "tiktok.sp_create_ad":
            p["creative_list"] = [{"creative_info": {"ad_format": "SINGLE_VIDEO", "tiktok_item_id": str(c["tiktok_item_id"]), "identity_type": "AUTH_CODE", "identity_id": str(c["identity_id"])}} for c in p.pop("creatives")]
            p["ad_text_list"] = [{"ad_text": p.pop("ad_text")}]
            p["ad_configuration"] = {"call_to_action_id": str(p.pop("cta_portfolio_id"))}
        if op.advertiser_param:
            p[op.advertiser_param] = ad_account if op.advertiser_param != "advertiser_ids" else json.dumps([ad_account])
            if op.platform == "telegram":
                p[op.advertiser_param] = int(ad_account)
        for pname, qname, ikey in op.query_map:
            if pname in p:
                p[qname] = json.dumps([{ikey: str(x)} for x in p.pop(pname)])
        if op.filter_keys:
            f = {k: p.pop(k) for k in op.filter_keys if k in p}
            if f:
                p["filtering"] = json.dumps({k: [str(x) for x in v] for k, v in f.items()})
        if op.method == "GET":
            q = {k: (json.dumps(v) if isinstance(v, list) and op.platform == "tiktok" else (",".join(v) if isinstance(v, list) else v)) for k, v in p.items()}
        else:
            body = p
        return op.method, base + path, headers, q, body

    async def _send(self, op, ad_account, params, token):
        """يرجع (status, raw_body, attempts, sent_flag_unsure). إعادة المحاولة: القراءة على الأخطاء المؤقتة؛ الكتابة فقط عند فشل قبل الإرسال."""
        method, url, headers, q, body = self._build(op, ad_account, params, token)
        attempts, last_exc = 0, None
        while attempts < self.s.retry_attempts:
            attempts += 1
            try:
                r = await self.client.request(method, url, headers=headers, params=q or None, json=body, timeout=self.s.request_timeout)
            except PRE_SEND as e:
                last_exc = e
                if attempts >= self.s.retry_attempts:
                    return None, b"", attempts, "pre_send_failure"
                await self.sleep(backoff_delay(attempts - 1, self.s.backoff_base, self.s.backoff_cap, self.rng))
                continue
            except httpx.HTTPError as e:                      # مهلة قراءة/انقطاع بعد الإرسال
                last_exc = e
                if op.write:
                    return None, b"", attempts, "unknown_after_send"
                if attempts >= self.s.retry_attempts:
                    return None, b"", attempts, "network_error"
                await self.sleep(backoff_delay(attempts - 1, self.s.backoff_base, self.s.backoff_cap, self.rng))
                continue
            raw = r.content
            if op.text_ok and r.status_code == 200 and raw[:1] not in (b"{", b"["):       # ملف CSV: نغلّفه بصيغة TikTok الناجحة
                raw = json.dumps({"code": 0, "message": "OK", "data": {"csv": raw.decode("utf-8", "replace")[:2_000_000]}}).encode()
            err = classify.classify(op.platform, r.status_code, raw)
            if err is None:
                return r.status_code, raw, attempts, None
            if op.write:
                if err.cls == "transient" and r.status_code >= 500:
                    return r.status_code, raw, attempts, "unknown_after_send"      # الخادم أخطأ: قد يكون نُفّذ
                return r.status_code, raw, attempts, None                          # رفض واضح (4xx/429): لم يُنفَّذ
            if err.retryable and attempts < self.s.retry_attempts:
                ra = r.headers.get("retry-after")
                await self.sleep(backoff_delay(attempts - 1, self.s.backoff_base, self.s.backoff_cap, self.rng, float(ra) if ra and ra.isdigit() else None))
                continue
            return r.status_code, raw, attempts, None
        return None, b"", attempts, "network_error"

    # ───── الاستدعاء الكامل ─────
    async def call(self, ctx: str, platform: str, op_name: str, ad_account: Optional[str], params: dict, idem: Optional[str], readiness: bool = False) -> tuple:
        """-> (http_status, envelope dict)"""
        if platform == "llm":
            return await self._llm(ctx, op_name, params or {})
        if platform == "tiktok" and op_name == "tiktok.launch_spark":
            return await self._launch_spark(ctx, ad_account, params or {}, idem)
        if platform == "tiktok" and op_name == "tiktok.pull_leads":
            return await self._pull_leads(ctx, ad_account, params or {}, idem)
        if platform == "tiktok" and op_name == "tiktok.duplicate_campaign":
            return await self._duplicate_campaign(ctx, ad_account, params or {}, idem)
        if platform == "tiktok" and op_name in ("tiktok.balances", "tiktok.active_today"):
            return await self._accounts_overview(ctx, op_name, params or {})
        if platform == "tiktok" and op_name == "tiktok.find_campaign":
            return await self._find_campaign(ctx, params or {})
        if platform == "tiktok" and op_name == "tiktok.campaign_check":
            return await self._campaign_check(ctx, ad_account, params or {}, idem)
        if platform == "tiktok" and op_name == "tiktok.activate_campaign":
            return await self._activate_campaign(ctx, ad_account, params or {}, idem)
        op = catalog.OPS.get(op_name)
        if not op or op.platform != platform or platform not in self.s.base_urls:
            return 400, {"ok": False, "error": {"class": "unknown_op", "retryable": False, "message": "operation not in allowlist"}}
        try:
            clean = catalog.validate(op, params or {})
        except catalog.Invalid as e:
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": redact.redact_text(str(e))}}
        if op.needs_account and not (ad_account and catalog.AD_ACCOUNT_RE.fullmatch(ad_account)):
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "ad_account required (A-Za-z0-9_, max 40)"}}
        if not op.needs_account:
            ad_account = None
        if readiness and op.write:      # نمط الجاهزية للقراءة/الاختبار فقط؛ لا كتابة بسياق الفحص
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "readiness mode is read-only"}}
        if op.write and (not idem or len(idem) < 16 or len(idem) > 128):
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "idempotency_key (16..128 chars) required for writes"}}
        try:
            az = await self.central.authorize(ctx, platform, ad_account, "probe" if readiness else "write" if op.write else "read")
        except AuthzError as e:
            if e.code == "connection_not_active":     # انتهاء/إلغاء الاتصال مسجّل مركزياً: نفس تصنيف انتهاء التوكن
                return 200, {"ok": False, "error": {"class": "auth_expired", "retryable": False, "message": "connection not active; re-authorize"}}
            return e.status, {"ok": False, "error": {"class": "unauthorized" if e.status == 401 else "forbidden" if e.status == 403 else "invalid_params" if e.status == 400 else "central_unavailable",
                                                     "retryable": e.status == 502, "message": e.code}}
        tenant, ref = az["tenant_id"], az["secret_ref"]
        key = (tenant, platform)

        if await self.store.get_state(ref) != "ok":
            return 200, {"ok": False, "error": {"class": "auth_expired", "retryable": False, "message": "credential marked expired; re-authorize the connection"}}
        if not self.bucket.allow(key):
            return 429, {"ok": False, "error": {"class": "rate_limited_local", "retryable": True, "message": "tenant rate limit"}}
        if not self.breaker.allow(key):
            return 200, {"ok": False, "error": {"class": "circuit_open", "retryable": True, "message": "platform temporarily failing for this tenant"}}

        h = None
        if op.write:
            h = self.store.request_hash(platform, op_name, ad_account, params or {})
            state, stored = await self.store.claim_write(tenant, idem, h, platform, op_name, self.s.write_stale_after)
            if state == "replay":
                return 200, {**stored, "meta": {**stored.get("meta", {}), "replayed": True}}
            if state == "in_progress":
                return 409, {"ok": False, "error": {"class": "in_progress", "retryable": True, "message": "same idempotency_key is executing"}}
            if state == "conflict":
                return 409, {"ok": False, "error": {"class": "idempotency_conflict", "retryable": False, "message": "key reused with a different request"}}
            if state == "unknown":
                return 200, {"ok": False, "error": {"class": "outcome_unknown", "retryable": False, "message": "previous attempt outcome unknown; verify on the platform before retrying"}}
            # state == new

        try:
            _, _, token = await self.store.open_latest(tenant, ref)
        except SecretMissing:
            if op.write:
                await self.store.finish_write(tenant, idem, "failed", {"ok": False})
            return 424, {"ok": False, "error": {"class": "secret_missing", "retryable": False, "message": "no active secret for this connection"}}
        except IntegrityError:
            if op.write:
                await self.store.finish_write(tenant, idem, "failed", {"ok": False})
            return 500, {"ok": False, "error": {"class": "integrity_error", "retryable": False, "message": "stored secret failed integrity check"}}

        t0 = time.monotonic()
        status, raw, attempts, flag = await self._send(op, ad_account, clean, token)
        ms = int((time.monotonic() - t0) * 1000)

        if flag in ("pre_send_failure", "network_error"):
            self.breaker.failure(key)
            env = {"ok": False, "error": {"class": "transient", "retryable": True, "platform_code": None, "message": "could not reach platform"}, "meta": {"attempts": attempts}}
            if op.write:
                await self.store.finish_write(tenant, idem, "failed", env)
            await self.store.log_call(tenant, platform, op_name, None, ms, "transient", idem)
            return 200, env
        if flag == "unknown_after_send":
            self.breaker.failure(key)
            env = {"ok": False, "error": {"class": "outcome_unknown", "retryable": False, "message": "request may have reached the platform; verify before retrying"}, "meta": {"attempts": attempts}}
            await self.store.finish_write(tenant, idem, "unknown", env)
            await self.store.log_call(tenant, platform, op_name, status, ms, "outcome_unknown", idem)
            return 200, env

        err = classify.classify(platform, status, raw)
        if err is None:
            self.breaker.success(key)
            env = {"ok": True, "data": scrub(classify.parse_body(raw)), "meta": {"attempts": attempts, "replayed": False}}
            if op.write:
                await self.store.finish_write(tenant, idem, "succeeded", env)
            await self.store.log_call(tenant, platform, op_name, status, ms, None, idem)
            return 200, env

        if err.cls == "auth_expired":
            await self.store.set_state(ref, "auth_expired", err.message)
            await self.central.report_connection(ctx, platform, ref, "expired")
        elif err.cls == "transient":
            self.breaker.failure(key)
        else:
            self.breaker.success(key)      # الخطأ منطقي (طلب/صلاحية): المنصة تعمل
        env = {"ok": False, "error": err.as_dict(), "meta": {"attempts": attempts}}
        if op.write:
            await self.store.finish_write(tenant, idem, "failed", env)
        await self.store.log_call(tenant, platform, op_name, status, ms, err.cls, idem)
        return 200, env

    # ───── عمليات تيليجرام الإدارية (مفتاح admin فقط): setWebhook / getWebhookInfo / deleteWebhook لبوت عميل ─────
    async def _gemini(self, body: dict):
        """نداء Gemini (مفتاح من ملف الأسرار). -> (status, content) أو (None, b'') عند فشل الشبكة. لا يُسجّل المفتاح."""
        url = self.s.llm_base_url.rstrip("/") + f"/models/{self.s.llm_model}:generateContent"
        try:
            r = await self.client.post(url, headers={"x-goog-api-key": self.s.llm_key}, json=body, timeout=20.0)
            return r.status_code, r.content
        except httpx.HTTPError:
            return None, b""

    POSTER_HOSTS = (".tiktokcdn.com", ".tiktokcdn-us.com", ".tiktokcdn-eu.com", ".ibytedtos.com", ".ibyteimg.com", ".byteoversea.com", ".tiktokv.com", ".tiktokv.us", ".muscdn.com")

    async def _fetch_poster(self, url):
        """غلاف الفيديو من CDN تيك توك فقط (https + نطاقات مسموحة + صورة ≤2MB). غير ذلك => None. لا تتبع إعادة توجيه."""
        try:
            u = httpx.URL(str(url))
            host = (u.host or "").lower()
            if u.scheme != "https" or not host.endswith(self.POSTER_HOSTS):
                return None
            r = await self.client.get(str(u), timeout=10.0)
            mime = r.headers.get("content-type", "").split(";")[0].strip().lower()
            if r.status_code != 200 or mime not in ("image/jpeg", "image/png", "image/webp") or not (500 < len(r.content) <= 2_000_000):
                return None
            return mime, base64.b64encode(r.content).decode()
        except Exception:
            return None

    async def _product_interests(self, ctx: str, ad_account: str, product_text: str, images: list, want: int):
        """اهتمامات TikTok مرتبطة بالمنتج الفعلي: Gemini يحلل غلاف الفيديو + النص -> ~120 كلمة -> recommend بدفعات متوازية -> تحقق EFFECTIVE -> حتى `want` اهتمام.
        -> (ids, names, product_seen, reason, debug). أي فشل => ([], [], '', سبب) والإعداد العام بديل."""
        if not (product_text or images):
            return [], [], "", "no_product", {}
        if not self.s.llm_key:
            return [], [], "", "llm_disabled", {}
        try:
            az = await self.central.authorize(ctx, "telegram", None, "read")
        except AuthzError:
            return [], [], "", "unauthorized", {}
        if not self.llm_bucket.allow((az["tenant_id"], "llm")):
            return [], [], "", "rate_limited", {}
        # مصدران للكلمات بالتوازي: (1) المنتج نفسه من الصورة/النص، (2) المجال الأوسع كله والمجالات القريبة منه (كوزمتك، عناية، جمال...)
        (st, raw) = await self._gemini(llm.build_seed_request(product_text, images))
        seen, seeds = llm.parse_seeds(raw) if st == 200 else ("", [])
        if len(seeds) < 4:
            return [], [], seen, "no_seeds", {"seeds": len(seeds), "gemini": st}
        st2_, raw2 = await self._gemini(llm.build_broad_request(seen or product_text))
        seeds2 = llm.parse_seeds(raw2)[1] if st2_ == 200 else []
        dbg = {"seeds": len(seeds), "broad": len(seeds2), "rounds": 0, "calls": 0, "fail": 0, "err": "", "raw": 0, "cand": 0, "bad": 0}
        sem = asyncio.Semaphore(4)                                       # لطيف مع حدود معدل تيك توك (مع إعادة المحاولة عند rate limit)
        used_seeds, cand, seen_ids = set(), [], set()

        t_start = time.monotonic()                                       # ميزانية زمنية: الإطلاق الكامل يجب أن ينتهي قبل مهلة n8n (170ث)

        async def rec(batch):
          async with sem:
            if time.monotonic() - t_start > 75:
                dbg["err"] = dbg["err"] or "time_budget"
                return []
            dbg["calls"] += 1
            for att in range(3):
                st3, env = await self.call(ctx, "tiktok", "tiktok.recommend_interests", ad_account, {"keywords": batch, "language": "en", "limit": 50}, None)
                if st3 == 200 and env.get("ok"):
                    break
                if "too many" not in str((env.get("error") or {}).get("message", "")).lower() and (env.get("error") or {}).get("class") != "rate_limited":
                    break
                await self.sleep(0.8 * (att + 1))
            if st3 == 200 and env.get("ok"):
                return [k for k in (((env.get("data") or {}).get("data") or {}).get("recommended_keywords") or []) if isinstance(k, dict) and k.get("keyword_id")]
            dbg["fail"] += 1
            dbg["err"] = dbg["err"] or (str((env.get("error") or {}).get("class") or st3) + ":" + str((env.get("error") or {}).get("message") or "")[:70])
            return []

        async def run_round(seed_list, max_batches, bs=4):
            fresh = [x for x in dict.fromkeys(seed_list) if x not in used_seeds]
            batches = [fresh[i:i + bs] for i in range(0, len(fresh), bs)][:max_batches]
            for b in batches:
                used_seeds.update(b)
            res = await asyncio.gather(*[rec(b) for b in batches])
            dbg["rounds"] += 1
            added = []
            for lst in res:                                              # ترتيب الدفعات = ترتيب الصلة (المنتج أولاً ثم المجال الأوسع)
                dbg["raw"] += len(lst)
                for k in lst:
                    kid, name = str(k["keyword_id"]), str(k.get("keyword") or "")
                    if kid in seen_ids or not name or re.search(r"[._]|(?:^|\s)(\w+) \1(?:\s|$)", name):
                        continue
                    seen_ids.add(kid)
                    cand.append((kid, name[:40]))
                    added.append(name.lower())
            return added

        need = int(want * 1.35) + 10
        added = await run_round(seeds + seeds2, 40)
        for _ in range(4):                                               # تضخيم: أسماء الاهتمامات المرجعة تصير كلمات بحث جديدة حتى نبلغ العدد
            if len(cand) >= need or time.monotonic() - t_start > 45:
                break
            nxt = [n for n in added if llm._KW.fullmatch(" ".join(re.sub(r"[^a-z0-9 &'\-]", " ", n).split()))]
            nxt = [" ".join(re.sub(r"[^a-z0-9 &'\-]", " ", n).split()) for n in nxt]
            if not nxt:
                break
            added = await run_round(nxt, 30, 3)
        cand = cand[:need]
        dbg["cand"] = len(cand)
        if not cand:
            return [], [], seen, "no_recommendations", dbg

        async def chk(ids):
          async with sem:
            st4, env = await self.call(ctx, "tiktok", "tiktok.check_interests", ad_account, {"keyword_ids": ids}, None)
            if st4 == 200 and env.get("ok"):
                return {str(k.get("keyword_id")) for k in (((env.get("data") or {}).get("data") or {}).get("keywords") or []) if isinstance(k, dict) and k.get("status") not in (None, "EFFECTIVE")}
            dbg["err"] = dbg["err"] or ("check:" + str((env.get("error") or {}).get("message") or st4)[:70])
            return set()

        bad = set().union(*await asyncio.gather(*[chk([c[0] for c in cand[i:i + 50]]) for i in range(0, len(cand), 50)]))
        dbg["bad"] = len(bad)
        ok = [c for c in cand if c[0] not in bad][:want]
        if len(ok) < 20:
            return [], [], seen, "too_few_valid", dbg
        dbg["got"] = len(ok)
        return [c[0] for c in ok], [c[1] for c in ok], seen, None, dbg

    async def _previously_promoted(self, ctx: str, ad_account: str, item_ids: set) -> bool:
        """هل كل الفيديوهات (item ids) سبق ترويجها بهذا الحساب (إعلان موجود غير محذوف بنفس tiktok_item_id)؟ أي فشل قراءة => False (يبقى متوقفاً، الأمان أولاً)."""
        if not item_ids:
            return False
        found = set()
        for page in range(1, 6):
            st, env = await self.call(ctx, "tiktok", "tiktok.read_ads_all", ad_account, {"fields": ["ad_id", "tiktok_item_id", "operation_status"], "page": page, "page_size": 1000}, None)
            if st != 200 or not env.get("ok"):
                return False
            d = (env.get("data") or {}).get("data") or {}
            for x in d.get("list") or []:
                if isinstance(x, dict) and str(x.get("tiktok_item_id") or "") in item_ids:
                    found.add(str(x["tiktok_item_id"]))
            if item_ids <= found or page >= int((d.get("page_info") or {}).get("total_page") or 1):
                break
        return item_ids <= found

    async def _launch_spark(self, ctx: str, ad_account: Optional[str], params: dict, idem: Optional[str]) -> tuple:
        """حملة تيك توك كاملة (صفحة فورية + Spark): كل الخطوات DISABLE. فشل جزئي يرجع ok=false مع ما أُنشئ فعلاً (data.campaign_id...) كي لا يضيع."""
        def bad(msg):
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": msg}}
        if not (ad_account and catalog.AD_ACCOUNT_RE.fullmatch(ad_account)):
            return bad("ad_account required")
        if not idem or not (16 <= len(idem) <= 100):
            return bad("idempotency_key (16..100 chars) required")
        p, e = spark.validate(params)
        if e:
            return bad(e)
        made = {}
        smart_budget = 0
        if p["objective"] == "whatsapp" and p.get("smart") and p["budget"] >= 2:        # واتساب: نصف الميزانية يدوي ونصفها Smart+ (استهداف تلقائي) مثل الورك فلو القديم
            half = math.floor(p["budget"] / 2 * 100) / 100
            half = int(half) if float(half).is_integer() else half
            smart_budget = round(p["budget"] - half, 2)
            smart_budget = int(smart_budget) if float(smart_budget).is_integer() else smart_budget
            p["budget"] = half

        async def step(stage, op, prm, key=None):
            st, env = await self.call(ctx, "tiktok", op, ad_account, prm, key)
            self._log_step(stage, op, ad_account, key or idem, prm, st, env)
            if st != 200 or not env.get("ok"):
                err = dict(env.get("error") or {"class": "internal", "retryable": False, "message": "step failed"})
                return None, (200 if st < 500 else st, {"ok": False, "error": err, "data": {"stage": stage, **made}})
            return (env.get("data") or {}).get("data") or {}, None

        wa, page = None, None
        if p["objective"] == "whatsapp":         # رسائل واتساب: لا صفحة فورية؛ رقم الواتساب لازم يكون مربوطاً بالحساب (message_event_set)
            local = p["whatsapp_number"]
            ev, f = await step("whatsapp", "tiktok.read_message_event_set", {"messaging_app_type": "WHATSAPP", "messaging_app_account_id": "964" + local})
            if f:
                return f
            es = str((ev.get("matched_event_set") or {}).get("message_event_set_id") or "")       # مطابقة رقمك فقط: لا نأخذ رقماً ثانياً مربوطاً بالحساب (الرسائل كانت تروح لرقم غيرك)
            if not es:
                linked = [str(x.get("messaging_app_account_id") or x.get("message_event_set_name") or x.get("message_event_set_id") or "")[:40] for x in (ev.get("message_event_set_list") or []) if isinstance(x, dict)][:5]
                return 200, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "whatsapp_not_linked"}, "data": {"stage": "whatsapp", "linked": linked}}
            wa = {"local": local, "event_set": es}
        else:
            pages, f = await step("pages", "tiktok.read_instant_pages", {"business_type": "TIKTOK_INSTANT_PAGE" if p["objective"] == "sales" else "LEAD_GEN", "status": "PUBLISHED"})
            if f:
                return f
            page, why = spark.pick_page(pages.get("list") or [], p["page_name"])
            if not page:
                titles = [str(x.get("title"))[:40] for x in (pages.get("list") or []) if isinstance(x, dict)][:10]
                return 200, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": why}, "data": {"stage": "pages", "pages": titles}}
        made["page_title"] = str(page.get("title") or "")[:60] if page else ("واتساب +964" + wa["local"])
        creatives, skipped, captions, posters = [], 0, [], []
        for i, code in enumerate(p["spark_codes"], 1):
            await step("authorize", "tiktok.authorize_video", {"auth_code": code}, f"{idem}-a{i}")       # فشل التفويض لا يوقف: التحقق الفعلي من info
            info, fi = await step("video_info", "tiktok.read_video_info", {"auth_code": code})
            if fi:
                skipped += 1
                continue
            ii, ui = info.get("item_info") or {}, info.get("user_info") or {}
            if ii.get("status") == "ONLY_USER_PASS" or not ii.get("item_id") or not ui.get("identity_id"):
                skipped += 1
                continue
            creatives.append({"identity_id": str(ui["identity_id"]), "tiktok_item_id": str(ii["item_id"]), "photo": ii.get("item_type") == "CAROUSEL"})
            if len(captions) < 2 and isinstance(ii.get("text"), str):
                captions.append(ii["text"][:200])
            if len(posters) < 2 and (info.get("video_info") or {}).get("poster_url"):
                posters.append(info["video_info"]["poster_url"])
        made["videos_ok"], made["videos_skipped"] = len(creatives), skipped
        if not creatives:
            return 200, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "no usable video (private, expired code, or not authorized)"}, "data": {"stage": "video", **made}}
        images = [im for im in await asyncio.gather(*[self._fetch_poster(u) for u in posters]) if im]
        if p["use_interests"]:
            iids, inames, seen_prod, why, idbg = await self._product_interests(ctx, ad_account, " | ".join(x for x in [p["product"], *captions] if x), images, p["interest_count"])
        else:                                   # المستخدم ما طلب اهتمامات: لا استدعاء Gemini ولا TikTok للاهتمامات
            iids, inames, seen_prod, why, idbg = [], [], "", "off", {}
        made["interests"] = inames[:8]
        made["interests_n"] = len(iids)
        made["interests_note"] = why or ""
        if idbg and (why or len(iids) < p["interest_count"]):
            made["interests_debug"] = idbg
        made["product_seen"] = seen_prod
        reason = "declared" if p["activate_now"] else ""                         # إعلان المستخدم بالرسالة (الكود مروّج قبل بحسابات/وكالات أخرى لا نراها)
        if not reason and p["auto_activate"] and await self._previously_promoted(ctx, ad_account, {cr["tiktok_item_id"] for cr in creatives}):     # أو سجل نفس الحساب (قبل إنشاء حملتنا)
            reason = "history"
        known = bool(reason)
        async def make_campaign(name, tag):
            camp = {"campaign_name": name, "objective_type": spark.OBJECTIVES[p["objective"]], "budget_mode": "BUDGET_MODE_INFINITE"}
            if p["objective"] == "sales":       # هدف "Sales" بالواجهة الجديدة (وجهة: موقع إلكتروني): WEB_CONVERSIONS + virtual SALES؛ وإن رفضتها تيك توك نرجع لـWEB_CONVERSIONS العادي
                c, f = await step("campaign", "tiktok.create_campaign", {**camp, "virtual_objective_type": "SALES", "sales_destination": "WEBSITE"}, f"{idem}-cv{tag}")
                if not f:
                    made["sales_mode"] = "sales"
                    return c, f
                if "already exists" in str((f[1].get("error") or {}).get("message", "")).lower():
                    return c, f
                made["sales_mode"] = "web_conversions"
            return await step("campaign", "tiktok.create_campaign", camp, f"{idem}-c{tag}")

        c, f = await make_campaign(p["campaign_name"], "")
        if f and "already exists" in str((f[1].get("error") or {}).get("message", "")).lower():       # اسم الحملة مكرر بالحساب: أضف رقماً وأعد مرة وحدة
            p["campaign_name"] = f"{p['campaign_name'][:480]} {int(time.time()) % 10000}"
            c, f = await make_campaign(p["campaign_name"], "2")
        if f:
            return f
        made["campaign_id"] = str(c.get("campaign_id") or "")
        if not made["campaign_id"]:
            return 200, {"ok": False, "error": {"class": "bad_response", "retryable": False, "message": "no campaign_id returned"}, "data": {"stage": "campaign"}}
        gname = f"{p['campaign_name']}-adgroup-{int(time.time()) % 1000000}"[:200]
        g, f = await step("adgroup", "tiktok.create_adgroup", spark.adgroup_params(p, made["campaign_id"], gname, datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None), iids, wa), f"{idem}-g")
        if f:
            return f
        made["adgroup_id"] = str(g.get("adgroup_id") or "")
        await self._search_off(ctx, ad_account, made["campaign_id"], made["adgroup_id"], idem, made)
        text = (p["ad_text"] or p["campaign_name"])[:100]
        card = "" if wa else await self._account_card(ctx, ad_account)         # بطاقة العرض (Display Card) المستخدمة سابقاً بالحساب
        cre = []
        for i, cr in enumerate(creatives, 1):
            x = {"ad_name": f"{gname}-{i}"[:200], "identity_id": cr["identity_id"], "tiktok_item_id": cr["tiktok_item_id"], "ad_text": text,
                 "ad_format": "CAROUSEL_ADS" if cr["photo"] else "SINGLE_VIDEO"}
            if page:
                x["page_id"] = str(page["page_id"])
            if not cr["photo"]:
                x["call_to_action"] = "SEND_MESSAGE" if wa else "CONTACT_US"
                if card:
                    x["card_id"] = card
            cre.append(x)
        a, f = await step("ad", "tiktok.create_ad", {"adgroup_id": made["adgroup_id"], "creatives": cre}, f"{idem}-d")
        if f and card:          # البطاقة قد ترفضها تيك توك لهذا الإعلان: أعد الإنشاء بدونها بدل ما تفشل الحملة
            made["card"] = "rejected"
            for x in cre:
                x.pop("card_id", None)
            a, f = await step("ad", "tiktok.create_ad", {"adgroup_id": made["adgroup_id"], "creatives": cre}, f"{idem}-d2")
        elif card:
            made["card"] = card
        if f:
            return f
        made["ad_ids"] = [str(x) for x in (a.get("ad_ids") or [])][:10]
        if smart_budget:
            await self._launch_smart(ctx, ad_account, p, made, creatives, text, smart_budget, wa, idem)       # فشلها لا يُفشل الحملة اليدوية
        made["known_codes"] = bool(known)
        made["activation_reason"] = reason
        if known and (made.get("smart") or {}).get("ready"):
            st0, env0 = await self.call(ctx, "tiktok", "tiktok.set_campaign_status", ad_account, {"campaign_ids": [made["smart"]["campaign_id"]], "operation_status": "ENABLE"}, f"{idem}-sact")
            made["smart"]["activated"] = bool(st0 == 200 and env0.get("ok"))
        if known:       # كل الأكواد سبق ترويجها: تفعيل مباشر بطلب المستخدم (القاعدة العامة تبقى متوقفة لغير المعروف)
            st, env = await self._enable(ctx, ad_account, made["campaign_id"], [made["adgroup_id"]], made["ad_ids"], f"{idem}-act")      # أرقامها معروفة من الإنشاء: لا بحث
            if st == 200 and env.get("ok"):
                made.update(await self._verify_created(ctx, ad_account, made, True))
                return 200, {"ok": True, "data": {**made, "status": "ENABLE", "activated": True}}
            made["activation_error"] = str((env.get("error") or {}).get("message") or "activation failed")[:140] + " (" + str((env.get("data") or {}).get("stage") or "") + ")"
        made.update(await self._verify_created(ctx, ad_account, made, False))
        return 200, {"ok": True, "data": {**made, "status": "DISABLE", "activated": False}}

    async def _duplicate_campaign(self, ctx: str, ad_account: Optional[str], params: dict, idem: Optional[str]) -> tuple:
        """نسخ حملة واتساب/Spark موجودة بنفس إعداداتها وفيديوهاتها (أكواد التفويض الأصلية)، وتفعيلها (أمر صريح من المستخدم). تُقرأ الحملة المصدر من تيك توك ثم تُنشأ نسخة جديدة بنفس مسار launch (نفس الحقول والتحقق).
        غير المدعوم (Smart+ أو أكثر من مجموعة أو هوية غير AUTH_CODE أو غير واتساب) يُرفض بسبب واضح بدل نسخ ناقص."""
        def bad(msg):
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": msg}}
        if not (ad_account and catalog.AD_ACCOUNT_RE.fullmatch(ad_account)):
            return bad("ad_account required")
        if not idem or not (16 <= len(idem) <= 100):
            return bad("idempotency_key (16..100 chars) required")
        if set(params) - {"campaign_id", "name"} or not re.fullmatch(r"[0-9]{1,24}", str(params.get("campaign_id", ""))):
            return bad("{campaign_id,[name]} required")
        nm = params.get("name")
        if nm is not None and (not isinstance(nm, str) or not (1 <= len(nm) <= 200) or any(ord(c) < 32 for c in nm)):
            return bad("name 1..200 chars")
        src = str(params["campaign_id"])
        made: dict = {"source_campaign_id": src}

        def unsupported(why):
            return 200, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "unsupported_source"}, "data": {"stage": "source", "why": why}}

        async def step(stage, op, prm, key=None):
            st, env = await self.call(ctx, "tiktok", op, ad_account, prm, key)
            self._log_step(stage, op, ad_account, key or idem, prm, st, env)
            if st != 200 or not env.get("ok"):
                err = dict(env.get("error") or {"class": "internal", "retryable": False, "message": "step failed"})
                return None, (200 if st < 500 else st, {"ok": False, "error": err, "data": {"stage": stage, **made}})
            return (env.get("data") or {}).get("data") or {}, None
        gd, f = await step("source_adgroup", "tiktok.read_adgroups", {"campaign_ids": [src], "page_size": 10})
        if f:
            return f
        ad_, f = await step("source_ads", "tiktok.read_ads", {"campaign_ids": [src], "page_size": 50})
        if f:
            return f
        gl, al = gd.get("list") or [], ad_.get("list") or []
        if not gl:
            return unsupported("source_not_found")
        if len(gl) != 1:
            return unsupported("multiple_adgroups")
        g = gl[0]
        if g.get("messaging_app_type") != "WHATSAPP" or not g.get("message_event_set_id") or not g.get("phone_number"):
            return unsupported("not_whatsapp")
        if str(g.get("campaign_automation_type") or "MANUAL") != "MANUAL":
            return unsupported("smart_plus_not_supported")
        cre_src = []
        for a in al:
            if str(a.get("identity_type")) != "AUTH_CODE" or not a.get("tiktok_item_id") or not a.get("identity_id") or str(a.get("ad_format") or "SINGLE_VIDEO") not in ("SINGLE_VIDEO", "CAROUSEL_ADS"):
                return unsupported("ad_identity_not_auth_code")
            cre_src.append(a)
        if not cre_src:
            return unsupported("no_ads")
        try:
            budget = float(g.get("budget"))
            t0 = datetime.datetime.strptime(str(g.get("schedule_start_time")), "%Y-%m-%d %H:%M:%S")
            t1 = datetime.datetime.strptime(str(g.get("schedule_end_time")), "%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError):
            return unsupported("source_schedule_or_budget_unreadable")
        days = max(1, min(90, int(round((t1 - t0).total_seconds() / 86400))))
        cap = None
        if str(g.get("bid_type")) == "BID_TYPE_CUSTOM":
            try:
                cap = float(g.get("conversion_bid_price")) or None
            except (TypeError, ValueError):
                cap = None
        interests = [str(x) for x in (g.get("interest_keyword_ids") or [])]
        p = {"objective": "whatsapp", "budget": int(budget) if budget == int(budget) else budget, "budget_mode": "daily" if g.get("budget_mode") == "BUDGET_MODE_DAY" else "total", "days": days,
             "use_interests": bool(interests), "cost_cap": cap, "campaign_name": (nm or (str(g.get("campaign_name") or "حملة")[:160] + " - نسخة"))[:200]}
        made["source_name"] = str(g.get("campaign_name") or "")[:80]

        async def make_campaign(name, tag):
            return await step("campaign", "tiktok.create_campaign", {"campaign_name": name, "objective_type": "LEAD_GENERATION", "budget_mode": "BUDGET_MODE_INFINITE"}, f"{idem}-dc{tag}")
        c, f = await make_campaign(p["campaign_name"], "")
        if f and "already exists" in str((f[1].get("error") or {}).get("message", "")).lower():
            p["campaign_name"] = f"{p['campaign_name'][:190]} {int(time.time()) % 10000}"
            c, f = await make_campaign(p["campaign_name"], "2")
        if f:
            return f
        made["campaign_id"] = str(c.get("campaign_id") or "")
        if not made["campaign_id"]:
            return 200, {"ok": False, "error": {"class": "bad_response", "retryable": False, "message": "no campaign_id returned"}, "data": {"stage": "campaign", **made}}
        made["name"] = p["campaign_name"]
        gname = f"{p['campaign_name']}-adgroup-{int(time.time()) % 1000000}"[:200]
        ag = spark.adgroup_params(p, made["campaign_id"], gname, datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None), interests, {"local": str(g["phone_number"]), "event_set": str(g["message_event_set_id"])})
        for k in ("age_groups", "gender", "location_ids"):                       # نفس جمهور المصدر بالضبط
            if g.get(k):
                ag[k] = g[k]
        gr, f = await step("adgroup", "tiktok.create_adgroup", ag, f"{idem}-dg")
        if f:
            return f
        made["adgroup_id"] = str(gr.get("adgroup_id") or "")
        await self._search_off(ctx, ad_account, made["campaign_id"], made["adgroup_id"], idem, made)
        cre = []
        for i, a in enumerate(cre_src[:10], 1):
            x = {"ad_name": f"{gname}-{i}"[:200], "identity_id": str(a["identity_id"]), "tiktok_item_id": str(a["tiktok_item_id"]), "ad_format": str(a.get("ad_format") or "SINGLE_VIDEO"),
                 "ad_text": "".join(ch for ch in str(a.get("ad_text") or p["campaign_name"]) if ord(ch) >= 32)[:100] or p["campaign_name"][:100]}
            if x["ad_format"] != "CAROUSEL_ADS":
                x["call_to_action"] = "SEND_MESSAGE"
            cre.append(x)
        ar, f = await step("ad", "tiktok.create_ad", {"adgroup_id": made["adgroup_id"], "creatives": cre}, f"{idem}-dd")
        if f:
            return f
        made["ad_ids"] = [str(x) for x in (ar.get("ad_ids") or [])][:10]
        made["videos_ok"] = len(cre)
        made["budget"], made["budget_mode"], made["days"], made["cost_cap"] = p["budget"], p["budget_mode"], days, cap
        st, env = await self._enable(ctx, ad_account, made["campaign_id"], [made["adgroup_id"]], made["ad_ids"], f"{idem}-act")
        if st == 200 and env.get("ok"):
            made.update(await self._verify_created(ctx, ad_account, made, True))
            return 200, {"ok": True, "data": {**made, "status": "ENABLE", "activated": True}}
        made["activation_error"] = str((env.get("error") or {}).get("message") or "activation failed")[:140]
        made.update(await self._verify_created(ctx, ad_account, made, False))
        return 200, {"ok": True, "data": {**made, "status": "DISABLE", "activated": False}}

    async def _accounts_overview(self, ctx: str, op_name: str, params: dict) -> tuple:
        """قراءة فقط لعدة حسابات تيك توك بالتوازي: tiktok.balances (الرصيد والحالة) أو tiktok.active_today (الحملات اللي صرفت اليوم بأرقامها). فشل حساب لا يوقف الباقي."""
        def bad(msg):
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": msg}}
        accts = params.get("accounts")
        if set(params) != {"accounts"} or not isinstance(accts, list) or not (1 <= len(accts)) or len(accts) > 40 or any(not (isinstance(a, str) and catalog.AD_ACCOUNT_RE.fullmatch(a)) for a in accts):
            return bad("accounts: 1..40 valid ad account ids")
        sem = asyncio.Semaphore(8)
        failed = []

        async def rd(acct, op, prm):
            async with sem:
                try:
                    st, env = await self.call(ctx, "tiktok", op, acct, prm, None)
                except Exception:
                    return None
            return (((env or {}).get("data") or {}).get("data") or {}) if st == 200 and (env or {}).get("ok") else None

        def num_(v):
            try:
                return float(v)
            except (TypeError, ValueError):
                return None
        if op_name == "tiktok.balances":
            async def one(acct):
                d = await rd(acct, "tiktok.read_advertiser", {"fields": ["name", "currency", "balance", "status"]})
                l = (d or {}).get("list") or []
                if not l:
                    failed.append(acct)
                    return None
                a = l[0]
                return {"ad_account": acct, "name": str(a.get("name") or "")[:60], "currency": str(a.get("currency") or "").upper(), "balance": num_(a.get("balance")), "status": str(a.get("status") or "")[:30]}
            rows = [r for r in await asyncio.gather(*[one(a) for a in accts]) if r]
            return 200, {"ok": True, "data": {"accounts": rows, "accounts_failed": len(failed)}}
        today = datetime.date.today().isoformat()

        async def one_active(acct):
            d = await rd(acct, "tiktok.read_report", {"report_type": "BASIC", "data_level": "AUCTION_AD", "dimensions": ["ad_id"], "metrics": ["campaign_id", "campaign_name", "spend", "impressions", "clicks", "result"],
                                                      "start_date": today, "end_date": today, "page_size": 1000})
            if d is None:
                failed.append(acct)
                return []
            agg = {}
            for x in d.get("list") or []:
                m = x.get("metrics") or {}
                cid = str(m.get("campaign_id") or "")
                if not cid:
                    continue
                t = agg.setdefault(cid, {"campaign_id": cid, "ad_account": acct, "name": str(m.get("campaign_name") or "")[:80], "spend": 0.0, "impressions": 0.0, "clicks": 0.0, "results": 0.0})
                for k, mk in (("spend", "spend"), ("impressions", "impressions"), ("clicks", "clicks"), ("results", "result")):
                    v = num_(m.get(mk))
                    t[k] += v or 0.0
            rows = [t for t in agg.values() if t["spend"] > 0]
            if rows:
                ai = await rd(acct, "tiktok.read_advertiser", {"fields": ["currency"]})
                cur = str((((ai or {}).get("list") or [{}])[0]).get("currency") or "USD").upper()
                fx = 1310.0 if cur == "IQD" else 1.0
                for t in rows:
                    t["spend_usd"] = round(t["spend"] / fx, 2)
                    t["cost_per_result_usd"] = round(t["spend"] / fx / t["results"], 3) if t["results"] else None
                    for k in ("spend", "impressions", "clicks", "results"):
                        t[k] = int(round(t[k]))
                    t.pop("spend", None)
            return rows
        rows = [r for rs in await asyncio.gather(*[one_active(a) for a in accts]) for r in rs]
        rows.sort(key=lambda r: -r["spend_usd"])
        return 200, {"ok": True, "data": {"campaigns": rows[:20], "total_spend_usd": round(sum(r["spend_usd"] for r in rows), 2), "campaigns_count": len(rows), "accounts_failed": len(failed)}}

    async def _find_campaign(self, ctx: str, params: dict) -> tuple:
        """بحث عن حملة بالاسم بين حسابات تيك توك المعطاة (قراءة فقط): تقارير آخر 7 أيام بمستوى الإعلان ثم مطابقة الاسم. يُستعمل لأسئلة مثل "شلون حملة سديم". لا يفشل بفشل حساب واحد."""
        def bad(msg):
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": msg}}
        name, accts = params.get("name"), params.get("accounts")
        if set(params) - {"name", "accounts"} or not isinstance(name, str) or not (1 <= len(name) <= 80) or any(ord(c) < 32 for c in name):
            return bad("name (1..80) and accounts required")
        if not isinstance(accts, list) or not (1 <= len(accts) <= 40) or any(not (isinstance(a, str) and catalog.AD_ACCOUNT_RE.fullmatch(a)) for a in accts):
            return bad("accounts: 1..40 valid ad account ids")
        toks = _name_tokens(name)
        if not toks:
            return bad("name has no searchable words")
        end = datetime.date.today()
        start = (end - datetime.timedelta(days=6)).isoformat()
        sem = asyncio.Semaphore(8)
        failed = []

        async def one(acct):
            async with sem:
                try:
                    st, env = await self.call(ctx, "tiktok", "tiktok.read_report", acct, {"report_type": "BASIC", "data_level": "AUCTION_AD", "dimensions": ["ad_id"],
                                                                                          "metrics": ["campaign_id", "campaign_name"], "start_date": start, "end_date": end.isoformat(), "page_size": 1000}, None)
                except Exception:
                    failed.append(acct)
                    return []
            if st != 200 or not (env or {}).get("ok"):
                failed.append(acct)
                return []
            seen = {}
            for x in ((((env.get("data") or {}).get("data") or {}).get("list")) or []):
                m = x.get("metrics") or {}
                if m.get("campaign_id") and m.get("campaign_name"):
                    seen[str(m["campaign_id"])] = str(m["campaign_name"])
            return [(acct, cid, nm) for cid, nm in seen.items()]
        found = [row for rows in await asyncio.gather(*[one(a) for a in accts]) for row in rows]
        scored = []
        for acct, cid, nm in found:
            sc, exact = _name_match(toks, nm)
            if sc >= 0.5:
                scored.append({"campaign_id": cid, "ad_account": acct, "name": nm[:80], "score": round(sc, 2), "exact": exact})
        scored.sort(key=lambda r: (-r["score"], r["name"]))
        return 200, {"ok": True, "data": {"matches": scored[:5], "exact_count": sum(1 for r in scored if r["exact"]), "accounts_searched": len(accts), "accounts_failed": len(failed), "window_days": 7}}

    async def _campaign_check(self, ctx: str, ad_account: Optional[str], params: dict, idem: Optional[str]) -> tuple:
        """فحص حملة بالأرقام (قراءة فقط): Created → Enabled → Delivering → Results، وحكم مكان الاختناق. مقاييس مستوى الإعلان (مستوى الحملة يرجّع result=0 لحملات الرسائل)."""
        def bad(msg):
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": msg}}
        if not (ad_account and catalog.AD_ACCOUNT_RE.fullmatch(ad_account)) or set(params) - {"campaign_id", "days"} or not re.fullmatch(r"[0-9]{1,24}", str(params.get("campaign_id", ""))):
            return bad("ad_account and {campaign_id,[days]} required")
        days = params.get("days", 7)
        if isinstance(days, bool) or not isinstance(days, int) or not (1 <= days <= 7):
            return bad("days 1..7")
        cid = str(params["campaign_id"])

        async def rd(op, prm):
            st, env = await self.call(ctx, "tiktok", op, ad_account, prm, None)
            return (((env or {}).get("data") or {}).get("data") or {}) if st == 200 and (env or {}).get("ok") else None
        gd, ad = await rd("tiktok.read_adgroups", {"campaign_ids": [cid], "page_size": 5}), await rd("tiktok.read_ads", {"campaign_ids": [cid], "page_size": 50})
        gl, al = (gd or {}).get("list") or [], (ad or {}).get("list") or []
        if not gl:
            return 200, {"ok": True, "data": {"campaign_id": cid, "stages": {"created": False, "enabled": False, "delivering": False, "results": False}, "verdict": "NOT_FOUND (deleted, wrong account, or not readable)"}}
        g = gl[0]
        sec = str(g.get("secondary_status") or "")
        ad_ids = {str(a.get("ad_id")) for a in al}
        enabled = str(g.get("operation_status")) == "ENABLE" and any(str(a.get("operation_status")) == "ENABLE" for a in al) and not any(w in sec for w in ("DISABLE", "REJECT", "DENY"))
        adv = await rd("tiktok.read_advertiser", {"fields": ["currency"]})
        cur = str((((adv or {}).get("list") or [{}])[0]).get("currency") or "USD").upper()
        fx = 1310.0 if cur == "IQD" else 1.0
        end = datetime.date.today()
        rep = await rd("tiktok.read_report", {"report_type": "BASIC", "data_level": "AUCTION_AD", "dimensions": ["ad_id"], "metrics": ["campaign_id", "spend", "impressions", "clicks", "result"],
                                              "start_date": (end - datetime.timedelta(days=days - 1)).isoformat(), "end_date": end.isoformat(), "page_size": 1000})
        t = {"spend": 0.0, "imp": 0.0, "clk": 0.0, "res": 0.0}
        for x in (rep or {}).get("list") or []:
            m = x.get("metrics") or {}
            if str(m.get("campaign_id")) != cid and str((x.get("dimensions") or {}).get("ad_id")) not in ad_ids:
                continue
            for k, mk in (("spend", "spend"), ("imp", "impressions"), ("clk", "clicks"), ("res", "result")):
                try:
                    t[k] += float(m.get(mk) or 0)
                except (TypeError, ValueError):
                    pass
        sp = t["spend"] / fx
        met = {"currency": cur, "spend_usd": round(sp, 2), "impressions": int(t["imp"]), "clicks": int(t["clk"]), "ctr_pct": round(100 * t["clk"] / t["imp"], 2) if t["imp"] else 0.0,
               "cpc_usd": round(sp / t["clk"], 3) if t["clk"] else None, "cpm_usd": round(1000 * sp / t["imp"], 2) if t["imp"] else None, "results": int(t["res"]), "cost_per_result_usd": round(sp / t["res"], 3) if t["res"] else None}
        delivering, results = t["imp"] >= 100, t["res"] > 0
        if not enabled:
            verdict = "NOT_ENABLED (" + (sec or str(g.get("operation_status"))) + ")"
        elif sp < 0.5:
            verdict = "TOO_EARLY (spend < 0.5$)"
        elif not delivering:
            verdict = "DELIVERY (spending but almost no impressions: bid / budget / targeting / review)"
        elif results:
            verdict = "OK (getting results)"
        elif met["ctr_pct"] < 0.4:
            verdict = "CREATIVE_OR_TARGETING (impressions but almost no clicks)"
        elif t["clk"] >= 20:
            verdict = "CTA_OR_DESTINATION (many clicks, zero messages)"
        else:
            verdict = "LOW_CLICKS (not enough clicks yet to judge)"
        return 200, {"ok": True, "data": {"campaign_id": cid, "stages": {"created": True, "enabled": bool(enabled), "delivering": bool(delivering), "results": bool(results)},
                                           "status": {"adgroup": g.get("operation_status"), "secondary": sec, "ads": len(al)}, "metrics": met, "verdict": verdict}}

    def _log_step(self, stage, op, ad_account, key, prm, st, env):
        """سطر JSON واحد لكل خطوة: الطلب الفعلي (محجوب الأسرار) + بصمته + ملخص رد تيك توك. لا يرمي أبداً."""
        try:
            pj = json.dumps(prm, ensure_ascii=False, sort_keys=True, default=str)
            data = ((env or {}).get("data") or {}).get("data")
            err = (env or {}).get("error") or {}
            rec = {"evt": "launch_step", "ts": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), "stage": stage, "op": op, "ad_account": ad_account,
                   "idem": key, "payload_sha": hashlib.sha256(pj.encode()).hexdigest()[:16], "payload": redact.redact_text(pj)[:1800],
                   "http": st, "ok": bool((env or {}).get("ok")), "error_class": err.get("class"), "error_message": redact.redact_text(str(err.get("message") or ""))[:200],
                   "response": redact.redact_text(json.dumps(data, ensure_ascii=False, default=str))[:900] if data is not None else None}
            launch_log.info(json.dumps(rec, ensure_ascii=False))
        except Exception:
            pass

    async def _verify_created(self, ctx: str, ad_account: str, made: dict, activated_req: bool) -> dict:
        out = await self._verify_created_raw(ctx, ad_account, made, activated_req)
        try:        # سجل ما سجّلته تيك توك فعلياً بعد الإنشاء (الحالة + الإعدادات): للمقارنة مع الطلب المُرسل ومع الحملة اليدوية
            launch_log.info(json.dumps({"evt": "launch_verify", "ts": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), "ad_account": ad_account, "campaign_id": made.get("campaign_id"),
                                        "verify": out.get("verify"), "stages": out.get("stages")}, ensure_ascii=False, default=str)[:3000])
        except Exception:
            pass
        return out

    async def _verify_created_raw(self, ctx: str, ad_account: str, made: dict, activated_req: bool) -> dict:
        """قراءة الحملة من تيك توك بعد الإنشاء/التفعيل (لا نكتفي بـ SUCCESS): الحالة الفعلية وأهم الإعدادات كما سجّلتها تيك توك. تُرجع {verify, stages}. لا ترمي."""
        out = {"verify": {"error": "not_read"}, "stages": {"created": True, "enabled": None, "delivering": "pending", "results": "pending"}}
        try:
            cid = made.get("campaign_id")
            st1, e1 = await self.call(ctx, "tiktok", "tiktok.read_adgroups", ad_account, {"campaign_ids": [cid], "page_size": 5}, None)
            st2, e2 = await self.call(ctx, "tiktok", "tiktok.read_ads", ad_account, {"campaign_ids": [cid], "page_size": 20}, None)
            gl = (((e1 or {}).get("data") or {}).get("data") or {}).get("list") or [] if st1 == 200 and (e1 or {}).get("ok") else []
            al = (((e2 or {}).get("data") or {}).get("data") or {}).get("list") or [] if st2 == 200 and (e2 or {}).get("ok") else []
            if not gl:
                out["verify"] = {"error": "adgroup_not_readable"}
                return out
            g = gl[0]
            keys = ("operation_status", "secondary_status", "optimization_goal", "optimization_event", "promotion_type", "bid_type", "conversion_bid_price", "skip_learning_phase", "search_result_enabled",
                    "age_groups", "gender", "location_ids", "interest_keyword_ids", "placements", "budget_mode", "budget", "schedule_start_time", "schedule_end_time", "campaign_automation_type", "message_event_set_id", "phone_number")
            ag = {k: g.get(k) for k in keys if k in g}
            ads = [{"status": a.get("operation_status"), "secondary": a.get("secondary_status"), "cta": a.get("call_to_action")} for a in al[:10]]
            en = (str(g.get("operation_status")) == "ENABLE") and bool(ads) and all(str(a["status"]) == "ENABLE" for a in ads)
            sec = str(g.get("secondary_status") or "")
            blocked = ("DISABLE" in sec) or ("REJECT" in sec) or ("DENY" in sec)
            out["verify"] = {"adgroup": ag, "ads": ads, "note": "" if (en and not blocked) or not activated_req else "requested ENABLE but TikTok reports: " + sec}
            out["stages"]["enabled"] = bool(en and not blocked) if activated_req else False
        except Exception as e:                                    # القراءة اللاحقة لا تُفشل إنشاء ناجح
            out["verify"] = {"error": type(e).__name__}
        return out

    async def _launch_smart(self, ctx: str, ad_account: str, p: dict, made: dict, creatives: list, text: str, budget, wa: dict, idem: str) -> None:
        """حملة Smart+ لواتساب بجانب اليدوية (نفس حقول الورك فلو القديم). تسجّل النتيجة/الخطأ بـ made['smart'] ولا ترمي."""
        sm = made["smart"] = {"budget": budget}

        async def go(stage, op, prm, key):
            st, env = await self.call(ctx, "tiktok", op, ad_account, prm, key)
            if st != 200 or not env.get("ok"):
                sm["stage"] = stage
                sm["error"] = str((env.get("error") or {}).get("message") or "failed")[:160]
                return None
            return (env.get("data") or {}).get("data") or {}
        now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
        start = now + datetime.timedelta(minutes=10)
        end = start + datetime.timedelta(days=p["days"])
        fmt = "%Y-%m-%d %H:%M:%S"
        name = f"{p['campaign_name'][:400]}-SMART-{int(time.time()) % 1000000}"
        c = await go("campaign", "tiktok.sp_create_campaign", {"campaign_name": name, "budget": budget, "budget_mode": "BUDGET_MODE_DYNAMIC_DAILY" if p["budget_mode"] == "daily" else "BUDGET_MODE_TOTAL"}, f"{idem}-sc")
        cid = str((c or {}).get("campaign_id") or "")
        if not cid:
            sm.setdefault("error", "no campaign_id")
            return
        sm["campaign_id"] = cid
        g = await go("adgroup", "tiktok.sp_create_adgroup", {"campaign_id": cid, "adgroup_name": f"{name}-adgroup"[:512], "schedule_start_time": start.strftime(fmt), "schedule_end_time": end.strftime(fmt),
                                                              "message_event_set_id": wa["event_set"], "phone_number": wa["local"]}, f"{idem}-sg")
        gid = str((g or {}).get("adgroup_id") or "")
        if not gid:
            sm.setdefault("error", "no adgroup_id")
            return
        sm["adgroup_id"] = gid
        pf = await go("cta", "tiktok.create_cta_portfolio", {}, f"{idem}-sp")
        pid = str((pf or {}).get("creative_portfolio_id") or "")
        if not pid:
            sm.setdefault("error", "no creative_portfolio_id")
            return
        cre = [{"ad_name": f"{name}-{i}"[:200], "identity_id": cr["identity_id"], "tiktok_item_id": cr["tiktok_item_id"], "ad_format": "SINGLE_VIDEO"} for i, cr in enumerate([x for x in creatives if not x["photo"]][:10], 1)]
        if not cre:
            sm["stage"], sm["error"] = "ad", "no videos"
            return
        a = await go("ad", "tiktok.sp_create_ad", {"adgroup_id": gid, "ad_name": f"{name}-ad"[:512], "ad_text": text, "cta_portfolio_id": pid, "creatives": cre}, f"{idem}-sd")
        if a is None:
            return
        sm["ad_id"] = str(a.get("smart_plus_ad_id") or "")[:30]
        sm["ready"] = True

    async def _pull_leads(self, ctx: str, ad_account: Optional[str], params: dict, idem: Optional[str]) -> tuple:
        """طلبات استمارة TikTok: مهمة تنزيل ← انتظار اكتمالها ← تنزيل CSV ← تحليل. كل خطوة تمر عبر call (التفويض/المعدل/الأسرار). ترجع {rows:[{lead_id,time,fields}], count}."""
        def bad(msg):
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": msg}}
        if not (ad_account and catalog.AD_ACCOUNT_RE.fullmatch(ad_account)) or set(params) != {"page_id"} or not re.fullmatch(r"[0-9]{1,24}", str(params.get("page_id", ""))):
            return bad("ad_account and {page_id} required")
        if not idem or not (16 <= len(idem) <= 100):
            return bad("idempotency_key (16..100 chars) required")

        async def step(stage, op, prm, key):
            st, env = await self.call(ctx, "tiktok", op, ad_account, prm, key)
            if st != 200 or not env.get("ok"):
                err = dict(env.get("error") or {"class": "internal", "retryable": False, "message": "step failed"})
                return None, (200 if st < 500 else st, {"ok": False, "error": err, "data": {"stage": stage}})
            return (env.get("data") or {}).get("data") or {}, None
        t, f = await step("task", "tiktok.create_lead_task", {"page_id": str(params["page_id"])}, f"{idem}-t")
        if f:
            return f
        tid = str(t.get("task_id") or "")
        if not re.fullmatch(r"[0-9A-Za-z_-]{1,64}", tid) or not tid.isdigit():
            return 200, {"ok": False, "error": {"class": "bad_response", "retryable": True, "message": "no task_id returned"}, "data": {"stage": "task"}}
        status = ""
        for i in range(12):
            await self.sleep(1.5 if i else 2.0)
            r, f = await step("status", "tiktok.read_lead_task", {"task_id": tid}, f"{idem}-p{i}")
            if f:
                return f
            status = str(r.get("status") or "")
            if status == "SUCCEED":
                break
            if status in ("FAILED", "FAIL", "ERROR"):
                return 200, {"ok": False, "error": {"class": "bad_response", "retryable": True, "message": "lead task failed"}, "data": {"stage": "status"}}
        if status != "SUCCEED":
            return 200, {"ok": False, "error": {"class": "transient", "retryable": True, "message": "lead task not ready yet"}, "data": {"stage": "status"}}
        d, f = await step("download", "tiktok.download_leads", {"task_id": tid}, None)
        if f:
            return f
        rows = leads.parse(str(d.get("csv") or ""))
        return 200, {"ok": True, "data": {"page_id": str(params["page_id"]), "count": len(rows), "rows": rows}}

    async def _account_card(self, ctx: str, ad_account: str) -> str:
        """آخر card_id (بطاقة عرض تفاعلية) مستخدم بإعلانات الحساب، أو ''. قراءة فقط؛ أي فشل => ''."""
        try:
            for pg in (1, 2, 3):
                st, env = await self.call(ctx, "tiktok", "tiktok.read_ads_all", ad_account, {"fields": ["ad_id", "card_id"], "page": pg, "page_size": 100}, None)
                if not (st == 200 and env.get("ok")):
                    return ""
                d = (env.get("data") or {}).get("data") or {}
                for ad in d.get("list") or []:
                    cid = str((ad or {}).get("card_id") or "")
                    if re.fullmatch(r"[0-9]{6,24}", cid):
                        return cid
                if pg >= int((d.get("page_info") or {}).get("total_page") or 1):
                    break
        except Exception:
            pass
        return ""

    async def _search_off(self, ctx: str, ad_account: str, cid: str, gid: str, idem: str, made: dict) -> None:
        """"Include search results" يجب أن يبقى مطفياً: نقرأ القيمة الفعلية بعد الإنشاء، وإن لم تكن false نحدّثها ونعيد القراءة. لا يوقف الإطلاق أبداً."""
        async def rd():
            st, env = await self.call(ctx, "tiktok", "tiktok.read_adgroups", ad_account, {"campaign_ids": [cid], "page_size": 10}, None)
            if st == 200 and env.get("ok"):
                for g in ((env.get("data") or {}).get("data") or {}).get("list") or []:
                    if isinstance(g, dict) and str(g.get("adgroup_id")) == gid:
                        return g.get("search_result_enabled")
            return "?"
        try:
            if await rd() is False:
                made["search_result"] = "off"
                return
            st, env = await self.call(ctx, "tiktok", "tiktok.update_adgroup", ad_account, {"adgroup_id": gid, "search_result_enabled": False}, f"{idem}-s")
            if not (st == 200 and env.get("ok")):
                made["search_result"] = "update_failed: " + str((env.get("error") or {}).get("message") or st)[:100]
                return
            made["search_result"] = "off" if await rd() is False else "still_on"
        except Exception as e:      # أي خلل هنا لا يؤثر على الحملة
            made["search_result"] = "check_failed: " + type(e).__name__

    async def _enable(self, ctx: str, ad_account: str, cid: str, gids: list, aids: list, idem: str, made: dict = None) -> tuple:
        """تفعيل بالأرقام المعروفة: الإعلانات ثم المجموعات ثم الحملة (الحملة آخراً كي لا يبدأ الصرف قبل اكتمال التفعيل)."""
        made = made if made is not None else {}
        made["adgroups"], made["ads"] = len(gids), len(aids)

        async def step(stage, op, prm, key):
            st, env = await self.call(ctx, "tiktok", op, ad_account, prm, key)
            if st != 200 or not env.get("ok"):
                err = dict(env.get("error") or {"class": "internal", "retryable": False, "message": "step failed"})
                return (200 if st < 500 else st, {"ok": False, "error": err, "data": {"stage": stage, **made}})
            return None
        for stage, op, key, ids, sfx in (("ads_enable", "tiktok.set_ad_status", "ad_ids", aids, "ae"), ("adgroups_enable", "tiktok.set_adgroup_status", "adgroup_ids", gids, "ge"),
                                         ("campaign_enable", "tiktok.set_campaign_status", "campaign_ids", [cid], "c")):
            f = await step(stage, op, {key: ids, "operation_status": "ENABLE"}, f"{idem}-{sfx}")
            if f:
                return f
        return 200, {"ok": True, "data": {**made, "status": "ENABLE"}}

    async def _activate_campaign(self, ctx: str, ad_account: Optional[str], params: dict, idem: Optional[str]) -> tuple:
        """تفعيل حملة موجودة (أمر صريح /activate): يبحث عن مجموعاتها وإعلاناتها (فلتر ثم قراءة كل الإعلانات كبديل) ثم يفعّلها. كل خطوة تمر عبر call (manager+، READY، حساب مملوك)."""
        def bad(msg):
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": msg}}
        if not (ad_account and catalog.AD_ACCOUNT_RE.fullmatch(ad_account)) or set(params) != {"campaign_id"} or not isinstance(params["campaign_id"], str) \
                or not re.fullmatch(r"[0-9]{1,24}", params["campaign_id"]):
            return bad("ad_account and {campaign_id} required")
        if not idem or not (16 <= len(idem) <= 100):
            return bad("idempotency_key (16..100 chars) required")
        cid = params["campaign_id"]

        async def read(op, prm):
            st, env = await self.call(ctx, "tiktok", op, ad_account, prm, None)
            if st != 200 or not env.get("ok"):
                return None, (200 if st < 500 else st, {"ok": False, "error": dict(env.get("error") or {"class": "internal", "retryable": False, "message": "read failed"}), "data": {"stage": "lookup"}})
            return ((env.get("data") or {}).get("data") or {}), None

        gids, aids = [], []
        gs, f = await read("tiktok.read_adgroups", {"campaign_ids": [cid], "page_size": 100})
        if f:
            return f
        ads, f = await read("tiktok.read_ads", {"campaign_ids": [cid], "page_size": 100})
        if f:
            return f
        gids = [str(x["adgroup_id"]) for x in (gs.get("list") or []) if isinstance(x, dict) and x.get("adgroup_id")]
        aids = [str(x["ad_id"]) for x in (ads.get("list") or []) if isinstance(x, dict) and x.get("ad_id")]
        if not gids or not aids:          # بديل: كل إعلانات الحساب ثم تصفية بالحملة (الفلتر قد يتأخر بعد الإنشاء مباشرة)
            await self.sleep(2.0)
            for page in range(1, 6):
                d, f = await read("tiktok.read_ads_all", {"fields": ["ad_id", "adgroup_id", "campaign_id"], "page": page, "page_size": 1000})
                if f:
                    return f
                for x in d.get("list") or []:
                    if isinstance(x, dict) and str(x.get("campaign_id") or "") == cid and x.get("ad_id"):
                        aids.append(str(x["ad_id"]))
                        if x.get("adgroup_id"):
                            gids.append(str(x["adgroup_id"]))
                if page >= int((d.get("page_info") or {}).get("total_page") or 1):
                    break
            gids, aids = sorted(set(gids))[:20], sorted(set(aids))[:20]
        if not gids or not aids:
            return 200, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "campaign has no adgroup/ad to activate (wrong id or not on this account)"}, "data": {"stage": "lookup"}}
        return await self._enable(ctx, ad_account, cid, gids[:20], aids[:20], idem)

    async def _llm(self, ctx: str, op_name: str, params: dict) -> tuple:
        """llm.parse_command {text} -> {ok, data:{intent:{...}}}. التفويض: سياق مستخدم صالح لعميل READY (نفس بوابة تيليجرام). لا يعيد المفتاح ولا يكتب شيئاً."""
        def err(cls, msg, retry=False, status=200):
            return status, {"ok": False, "error": {"class": cls, "retryable": retry, "message": msg}}
        appeal = op_name == "llm.appeal_text"
        chat = op_name == "llm.chat"
        if appeal:
            ok_p = set(params) <= {"ad_text", "ad_name", "status", "reason", "attempt", "prev"} and "status" in params and str(params.get("attempt", "1")) in ("1", "2", "3", "4", "5") and all(isinstance(v, str) and len(v) <= 300 and not any(ord(c) < 32 and c not in "\n\t" for c in v) for v in params.values())
            if not ok_p:
                return err("invalid_params", "llm.appeal_text requires {status, [ad_text], [ad_name]} short strings", status=400)
        elif op_name not in ("llm.parse_command", "llm.chat") or set(params) != {"text"} or not llm.valid_text(params.get("text")):
            return err("invalid_params", "llm.parse_command / llm.chat require {text: 1..800 chars}", status=400)
        if not self.s.llm_key:
            return err("unknown_op", "llm not configured", status=400)
        try:
            az = await self.central.authorize(ctx, "telegram", None, "read")
        except AuthzError as e:
            return e.status if e.status in (400, 401, 403) else 502, {"ok": False, "error": {"class": "unauthorized" if e.status == 401 else "forbidden" if e.status == 403 else "central_unavailable", "retryable": e.status == 502, "message": e.code}}
        tenant = az["tenant_id"]
        if not self.llm_bucket.allow((tenant, "llm")):
            return err("rate_limited_local", "tenant rate limit", True, 429)
        t0 = time.monotonic()
        url = self.s.llm_base_url.rstrip("/") + f"/models/{self.s.llm_model}:generateContent"
        status, cls, result = None, None, None
        for attempt in (1, 2):
            try:
                body = llm.build_appeal_request(params.get("ad_text", ""), params.get("ad_name", ""), params["status"], params.get("reason", ""), params.get("attempt", ""), params.get("prev", "")) if appeal else llm.build_chat_request(params["text"]) if chat else llm.build_request(params["text"], self.s.llm_model)
                r = await self.client.post(url, headers={"x-goog-api-key": self.s.llm_key}, json=body, timeout=20.0)
            except httpx.HTTPError:
                status, cls = None, "transient"
                await self.sleep(0.4)
                continue
            status = r.status_code
            if status == 200:
                if appeal:
                    a_txt, a_tips = llm.parse_appeal(r.content)
                    result = {"appeal": a_txt, "tips": a_tips} if a_txt else None
                elif chat:
                    c_txt = llm.parse_chat(r.content)
                    result = {"reply": c_txt} if c_txt else None
                else:
                    result = llm.parse_response(r.content)
                cls = None if result is not None else "bad_response"
                break
            cls = "auth_expired" if status in (400, 401, 403) else "rate_limited" if status == 429 else "transient"
            if cls != "transient" and cls != "rate_limited":
                break
            await self.sleep(0.4)
        ms = int((time.monotonic() - t0) * 1000)
        await self.store.log_call(tenant, "llm", op_name, status, ms, cls, None)
        if result is None:
            return err(cls or "transient", {"auth_expired": "llm key rejected", "rate_limited": "llm rate limited", "bad_response": "llm returned invalid output"}.get(cls, "llm unavailable"), cls in ("transient", "rate_limited"))
        return 200, {"ok": True, "data": result if (appeal or chat) else {"intent": result}}

    async def admin_telegram(self, tenant: str, ref: str, op_name: str, params: dict) -> tuple:
        op = catalog.ADMIN_OPS.get(op_name)
        if not op or "telegram" not in self.s.base_urls:
            return 400, {"ok": False, "error": {"class": "unknown_op", "retryable": False, "message": "operation not allowed"}}
        clean: dict = {}
        if op_name == "telegram.set_webhook":
            prefix, url, sec = self.s.webhook_url_prefix, params.get("url"), params.get("secret_token")
            if not prefix:
                return 503, {"ok": False, "error": {"class": "disabled", "retryable": False, "message": "BROKER_WEBHOOK_URL_PREFIX not configured"}}
            if not (isinstance(url, str) and url.startswith(prefix) and WEBHOOK_BOT_RE.fullmatch(url[len(prefix):])):
                return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "url must be <prefix><bot_public_id>"}}
            if not (isinstance(sec, str) and WEBHOOK_SECRET_RE.fullmatch(sec)):
                return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "secret_token invalid"}}
            redact.KNOWN.add(sec)
            # allowed_updates وmax_connections مفروضة: البوت يستقبل الرسائل فقط، واتصالات محدودة
            clean = {"url": url, "secret_token": sec, "allowed_updates": ["message"], "max_connections": 20, "drop_pending_updates": False}
        try:
            _, kind, token = await self.store.open_latest(tenant, ref)
        except SecretMissing:
            return 424, {"ok": False, "error": {"class": "secret_missing", "retryable": False, "message": "no active secret for this ref"}}
        except IntegrityError:
            return 500, {"ok": False, "error": {"class": "integrity_error", "retryable": False, "message": "stored secret failed integrity check"}}
        if kind != "telegram_bot_token":
            return 400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "secret is not a telegram bot token"}}
        t0 = time.monotonic()
        status, raw, attempts, flag = await self._send(op, None, clean, token)
        ms = int((time.monotonic() - t0) * 1000)
        if flag:
            await self.store.log_call(tenant, "telegram", op_name, status, ms, "transient", None)
            return 200, {"ok": False, "error": {"class": "transient", "retryable": True, "message": "could not reach telegram"}, "meta": {"attempts": attempts}}
        err = classify.classify("telegram", status, raw)
        await self.store.log_call(tenant, "telegram", op_name, status, ms, err.cls if err else None, None)
        if err:
            return 200, {"ok": False, "error": err.as_dict(), "meta": {"attempts": attempts}}
        return 200, {"ok": True, "data": scrub(classify.parse_body(raw)), "meta": {"attempts": attempts}}
