"""الاتصال بالقاعدة المركزية بحساب app_broker فقط: broker_authorize / broker_report_connection."""
import psycopg
from typing import Optional


class AuthzError(Exception):
    def __init__(self, status: int, code: str):
        super().__init__(code)
        self.status, self.code = status, code


class CentralDB:
    def __init__(self, pool):
        self.pool = pool

    async def authorize(self, ctx: str, platform: str, ad_account: Optional[str], access: str) -> dict:
        try:
            async with self.pool.connection() as c:
                r = await (await c.execute("SELECT tenant_id::text, role, secret_ref, connection_id::text FROM api.broker_authorize(%s,%s,%s,%s)",
                                           (ctx, platform, ad_account, access))).fetchone()
        except psycopg.errors.Error as e:
            sq = getattr(e.diag, "sqlstate", None) or ""
            msg = (getattr(e.diag, "message_primary", None) or "denied").split()[0]
            if sq == "28000":
                raise AuthzError(401, msg)
            if sq == "42501":
                raise AuthzError(403, msg)
            if sq == "22023":
                raise AuthzError(400, msg)
            raise AuthzError(502, "central_db_error")
        return {"tenant_id": r[0], "role": r[1], "secret_ref": r[2], "connection_id": r[3]}

    async def report_connection(self, ctx: str, platform: str, secret_ref: str, status: str) -> bool:
        try:
            async with self.pool.connection() as c:
                r = await (await c.execute("SELECT api.broker_report_connection(%s,%s,%s,%s)", (ctx, platform, secret_ref, status))).fetchone()
            return bool(r[0])
        except psycopg.errors.Error:
            return False
