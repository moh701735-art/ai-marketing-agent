"""إعدادات الـ Broker. الأسرار (KEK، مفاتيح HMAC) تأتي من ملف JSON يُركَّب كـ secret، لا من الكود ولا من Git."""
import base64
import json
import os
from dataclasses import dataclass, field
from urllib.parse import urlparse

import envelope

# أسماء مضيفين حقيقية محظورة افتراضياً: الـ Broker في التطوير يرفض الإقلاع إن أُشير إليها
REAL_PLATFORM_HOSTS = {
    "graph.facebook.com", "business-api.tiktok.com", "open.tiktokapis.com", "api.telegram.org",
    "graph.instagram.com", "www.facebook.com", "generativelanguage.googleapis.com",
}


@dataclass
class Settings:
    kek: bytes = field(repr=False)
    hmac_keys: dict = field(repr=False)      # key_id -> (key_bytes, scope)  scope: runtime | admin
    central_dsn: str = field(repr=False)
    vault_dsn: str = field(repr=False)
    base_urls: dict = field(default_factory=dict)      # platform -> base url
    allow_real_platforms: bool = False
    webhook_url_prefix: str = ""      # مثل https://bot.example.com/webhook/tg-ingress?bot= ؛ فارغ = عمليات setWebhook الإدارية معطّلة
    retry_attempts: int = 3
    backoff_base: float = 0.2
    backoff_cap: float = 2.0
    breaker_threshold: int = 5
    breaker_cooldown: float = 30.0
    rate_per_sec: float = 20.0
    rate_burst: float = 40.0
    request_timeout: float = 10.0
    max_body: int = 65536
    hmac_window: int = 60
    write_stale_after: int = 600
    llm_key: str = field(default="", repr=False)      # مفتاح Gemini من ملف الأسرار (اختياري). فارغ = ميزة فهم الرسائل معطّلة
    llm_base_url: str = "https://generativelanguage.googleapis.com/v1beta"
    llm_model: str = "gemini-3.5-flash"

    def validate(self):
        urls = dict(self.base_urls)
        if self.llm_key:
            urls["llm"] = self.llm_base_url
        for name, url in urls.items():
            host = (urlparse(url).hostname or "").lower()
            if not host:
                raise ValueError(f"base url for {name} has no host")
            if host in REAL_PLATFORM_HOSTS and not self.allow_real_platforms:
                raise ValueError(f"refusing to start: {name} points to a REAL platform host ({host}); "
                                 "real platforms are disabled in this phase")
        if "runtime" not in {s for _, s in self.hmac_keys.values()}:
            raise ValueError("at least one runtime key is required")
        for kid, (k, scope) in self.hmac_keys.items():
            if len(k) < 32 or scope not in ("runtime", "admin"):
                raise ValueError(f"bad hmac key {kid}")
        return self

    @classmethod
    def from_env(cls, env=os.environ):
        """BROKER_SECRETS_FILE: {"kek":"<b64>","hmac_keys":{"id":{"key":"<b64>","scope":"runtime"}}}"""
        with open(env["BROKER_SECRETS_FILE"], encoding="utf-8") as f:
            sec = json.load(f)
        keys = {kid: (base64.b64decode(v["key"]), v["scope"]) for kid, v in sec["hmac_keys"].items()}
        return cls(
            kek=envelope.load_kek(sec["kek"]), hmac_keys=keys,
            central_dsn=env["BROKER_CENTRAL_DSN"], vault_dsn=env["BROKER_VAULT_DSN"],
            base_urls={"meta": env["BROKER_META_BASE_URL"], "tiktok": env["BROKER_TIKTOK_BASE_URL"],
                       "telegram": env.get("BROKER_TELEGRAM_BASE_URL", "")} if env.get("BROKER_TELEGRAM_BASE_URL") else
                      {"meta": env["BROKER_META_BASE_URL"], "tiktok": env["BROKER_TIKTOK_BASE_URL"]},
            llm_key=str(sec.get("llm_api_key") or ""), llm_base_url=env.get("BROKER_LLM_BASE_URL") or cls.llm_base_url,
            llm_model=env.get("BROKER_LLM_MODEL") or cls.llm_model,
            allow_real_platforms=env.get("BROKER_ALLOW_REAL_PLATFORMS") == "1", webhook_url_prefix=env.get("BROKER_WEBHOOK_URL_PREFIX", ""),
            **{k: float(env[e]) for k, e in (("request_timeout", "BROKER_REQUEST_TIMEOUT"), ("backoff_base", "BROKER_BACKOFF_BASE"), ("backoff_cap", "BROKER_BACKOFF_CAP")) if env.get(e)},
        ).validate()
