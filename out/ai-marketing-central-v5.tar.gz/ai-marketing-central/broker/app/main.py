"""واجهة HTTP للـ Broker. كل الطلبات موقّعة HMAC. لا endpoint يعيد قيمة سر. الأخطاء مُنقّاة من الأسرار."""
import json
import logging
import time
from contextlib import asynccontextmanager
from typing import Optional

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from psycopg_pool import AsyncConnectionPool

import hmac_auth
import redact
from app.central import CentralDB
from app.service import Broker
from app.store import RefMismatch, VaultStore

log = logging.getLogger("broker")


def _json(status: int, body: dict) -> JSONResponse:
    return JSONResponse(status_code=status, content=redact.redact(body) if status >= 400 and not body.get("ok", False) is True else body)


def create_app(settings, *, transport: Optional[httpx.AsyncBaseTransport] = None, **broker_kw) -> FastAPI:
    settings.validate()
    state = {}
    for noisy in ("httpx", "httpcore"):      # تسجّل عناوين الطلبات (وتيليجرام يضع التوكن بالمسار)
        logging.getLogger(noisy).setLevel(logging.WARNING)

    @asynccontextmanager
    async def lifespan(app):
        cpool = AsyncConnectionPool(settings.central_dsn, min_size=1, max_size=8, open=False, kwargs={"autocommit": True}, check=AsyncConnectionPool.check_connection)
        vpool = AsyncConnectionPool(settings.vault_dsn, min_size=1, max_size=8, open=False, kwargs={"autocommit": True}, check=AsyncConnectionPool.check_connection)
        await cpool.open(); await vpool.open()
        store = VaultStore(vpool, settings.kek)
        await store.ensure_partitions()
        client = httpx.AsyncClient(transport=transport, follow_redirects=False)      # لا إعادة توجيه: يمنع تسريب رأس التوكن لمضيف آخر
        state.update(store=store, broker=Broker(settings, store, CentralDB(cpool), client, **broker_kw))
        yield
        await client.aclose(); await cpool.close(); await vpool.close()

    app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)

    async def auth(request: Request, scope: str):
        """-> (key_id, body_bytes) أو JSONResponse عند الرفض. لا نكشف سبب الرفض بدقة للمهاجم (نسجّله فقط)."""
        body = await request.body()
        if len(body) > settings.max_body:
            return _json(413, {"ok": False, "error": {"class": "too_large", "retryable": False, "message": "body too large"}})
        kid = request.headers.get("x-key-id", "")
        entry = settings.hmac_keys.get(kid)
        reason = "unknown_key" if not entry else None
        if entry and (scope == "admin" and entry[1] != "admin"):
            reason = "scope"
        if entry and scope == "runtime" and entry[1] not in ("runtime", "admin"):
            reason = "scope"
        if not reason:
            reason = hmac_auth.check(entry[0], body, request.headers.get("x-timestamp"), request.headers.get("x-nonce", ""),
                                     request.headers.get("x-signature", ""), time.time(), settings.hmac_window)
        if not reason and not await state["store"].use_nonce(kid, request.headers["x-nonce"]):
            reason = "replay"
        if reason:
            log.warning("auth rejected: %s (key=%s)", reason, kid[:16])
            return _json(401, {"ok": False, "error": {"class": "unauthorized", "retryable": False, "message": "authentication failed"}})
        return kid, body

    @app.get("/healthz")
    async def healthz():
        return {"ok": True}

    @app.post("/v1/call")
    async def call(request: Request):
        a = await auth(request, "runtime")
        if isinstance(a, JSONResponse):
            return a
        try:
            d = json.loads(a[1])
            ctx, platform, op = d["ctx"], d["platform"], d["op"]
            ad, params, idem = d.get("ad_account"), d.get("params") or {}, d.get("idempotency_key")
            readiness = d.get("mode") == "readiness"
            if d.get("mode") not in (None, "readiness"):
                raise ValueError
            if not all(isinstance(x, str) for x in (ctx, platform, op)) or (ad is not None and not isinstance(ad, str)) or not isinstance(params, dict):
                raise ValueError
        except Exception:
            return _json(400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "malformed request"}})
        try:
            status, env = await state["broker"].call(ctx, platform, op, ad, params, idem, readiness=readiness)
        except Exception as e:      # أي خطأ غير متوقع: رسالة عامة + سجل منقّى
            log.exception("unhandled error in call")
            return _json(500, {"ok": False, "error": {"class": "internal", "retryable": False, "message": "internal error"}})
        return _json(status, env)

    @app.post("/v1/admin/secrets")
    async def put_secret(request: Request):
        a = await auth(request, "admin")
        if isinstance(a, JSONResponse):
            return a
        try:
            d = json.loads(a[1])
            tenant, kind, ref, value = d["tenant_id"], d["kind"], d["secret_ref"], d["value"]
            if not all(isinstance(x, str) and x for x in (tenant, kind, ref, value)) or len(value) > 4096:
                raise ValueError
            redact.KNOWN.add(value)
            ver = await state["store"].put(tenant, kind, ref, value)
        except RefMismatch:
            return _json(409, {"ok": False, "error": {"class": "ref_mismatch", "retryable": False, "message": "secret_ref belongs to another tenant/kind"}})
        except Exception:
            log.warning("admin put_secret rejected")
            return _json(400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "invalid request"}})
        return {"ok": True, "secret_ref": ref, "version": ver}      # القيمة لا تُعاد أبداً

    @app.post("/v1/admin/secrets/revoke")
    async def revoke(request: Request):
        a = await auth(request, "admin")
        if isinstance(a, JSONResponse):
            return a
        try:
            d = json.loads(a[1])
            n = await state["store"].revoke(d["tenant_id"], d["secret_ref"])
        except Exception:
            return _json(400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "invalid request"}})
        return {"ok": True, "revoked": n}

    @app.post("/v1/admin/telegram/{action}")
    async def admin_telegram(action: str, request: Request):
        """action: set-webhook | webhook-info | delete-webhook. الجسم: {tenant_id, secret_ref, [url, secret_token]}. لا يعيد التوكن ولا secret_token."""
        a = await auth(request, "admin")
        if isinstance(a, JSONResponse):
            return a
        op = {"set-webhook": "telegram.set_webhook", "webhook-info": "telegram.get_webhook_info", "delete-webhook": "telegram.delete_webhook"}.get(action)
        try:
            d = json.loads(a[1])
            tenant, ref = d["tenant_id"], d["secret_ref"]
            if not op or not all(isinstance(x, str) and x for x in (tenant, ref)):
                raise ValueError
        except Exception:
            return _json(400, {"ok": False, "error": {"class": "invalid_params", "retryable": False, "message": "invalid request"}})
        try:
            status, env = await state["broker"].admin_telegram(tenant, ref, op, {k: d.get(k) for k in ("url", "secret_token")})
        except Exception:
            log.exception("unhandled error in admin telegram")
            return _json(500, {"ok": False, "error": {"class": "internal", "retryable": False, "message": "internal error"}})
        return _json(status, env)

    return app
