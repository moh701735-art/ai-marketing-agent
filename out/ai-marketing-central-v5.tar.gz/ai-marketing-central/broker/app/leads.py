"""تحليل ملف طلبات استمارة TikTok (CSV) إلى صفوف نظيفة. النص مدخل غير موثوق: بلا تنفيذ، حدود صارمة على الحجم والأعمدة."""
import csv
import hashlib
import io
import re

SKIP = re.compile(r"^(lead_?id|id|ad_?id|adgroup_?id|adgroup_?name|campaign_?id|advertiser_?id|page_?id|form_?id|page_?name|form_?name|lead_?source|task_?id|task_?type)$", re.I)
TIME = re.compile(r"^(created?_?time|create_?time|submit_?time|time)$", re.I)
LEADID = re.compile(r"^lead_?id$", re.I)
MAX_ROWS, MAX_FIELDS, MAX_VAL = 300, 14, 200


def parse(text: str):
    """-> [{lead_id, time, fields:{header: value}}] الأحدث أولاً، حتى MAX_ROWS."""
    text = (text or "").lstrip("﻿")[:2_000_000]
    rows = list(csv.reader(io.StringIO(text)))
    if len(rows) < 2:
        return []
    head = [h.strip() for h in rows[0]][:60]
    li = next((i for i, h in enumerate(head) if LEADID.fullmatch(h)), None)
    ti = next((i for i, h in enumerate(head) if TIME.fullmatch(h)), None)
    out = []
    for r in rows[1:]:
        if not any(x.strip() for x in r):
            continue
        fields = {}
        for i, h in enumerate(head):
            v = (r[i] if i < len(r) else "").strip()
            if not v or not h or SKIP.fullmatch(h) or (ti is not None and i == ti):
                continue
            if len(fields) < MAX_FIELDS:
                fields[h[:40]] = "".join(c for c in v if ord(c) >= 32)[:MAX_VAL]
        lid = (r[li].strip() if li is not None and li < len(r) else "")
        if not lid:
            lid = "h" + hashlib.sha1("|".join(r).encode("utf-8", "replace")).hexdigest()[:20]
        out.append({"lead_id": lid[:60], "time": (r[ti].strip()[:40] if ti is not None and ti < len(r) else ""), "fields": fields})
    out.sort(key=lambda x: x["time"], reverse=True)
    return out[:MAX_ROWS]
