"""تصنيف أخطاء المنصات. الجداول أدناه من معرفتي بتوثيق المنصات ولم تُتحقق مقابل الحسابات الحقيقية (مهمة P8)."""
import json
from dataclasses import dataclass
from typing import Optional

import redact

RETRYABLE = {"rate_limited", "transient"}


@dataclass(frozen=True)
class Err:
    cls: str
    retryable: bool
    platform_code: Optional[str]
    message: str

    def as_dict(self):
        return {"class": self.cls, "retryable": self.retryable, "platform_code": self.platform_code, "message": self.message}


def _msg(s) -> str:
    return redact.redact_text(str(s or ""))[:300]


def _by_http(status: int) -> str:
    if status == 401:
        return "auth_expired"
    if status == 403:
        return "permission_denied"
    if status == 404:
        return "not_found"
    if status == 429:
        return "rate_limited"
    if status >= 500:
        return "transient"
    return "bad_request"


def _meta(status: int, body) -> Optional[Err]:
    e = body.get("error") if isinstance(body, dict) else None
    if 200 <= status < 300 and not e:
        return None
    code = e.get("code") if isinstance(e, dict) else None
    msg = e.get("message") if isinstance(e, dict) else None
    cls = _by_http(status)
    if code in (190, 102):
        cls = "auth_expired"
    elif code in (4, 17, 32, 613) or (isinstance(code, int) and 80000 <= code <= 80099):
        cls = "rate_limited"
    elif code in (1, 2):
        cls = "transient"
    elif code == 10 or (isinstance(code, int) and 200 <= code <= 299):
        cls = "permission_denied"
    elif code == 368:
        cls = "policy_rejected"
    elif code == 100:
        cls = "bad_request"
    return Err(cls, cls in RETRYABLE, str(code) if code is not None else str(status), _msg(msg))


def _tiktok(status: int, body) -> Optional[Err]:
    code = body.get("code") if isinstance(body, dict) else None
    if 200 <= status < 300 and (code in (0, None) and isinstance(body, dict)):
        return None
    msg = body.get("message") if isinstance(body, dict) else None
    if isinstance(code, int) and code != 0:
        if code in (40104, 40105):
            cls = "auth_expired"
        elif code == 40100:
            cls = "rate_limited"
        elif code >= 50000:
            cls = "transient"
        elif code in (40001, 40002):
            cls = "bad_request"
        else:
            cls = _by_http(status) if status >= 400 else "bad_request"
        return Err(cls, cls in RETRYABLE, str(code), _msg(msg))
    cls = _by_http(status)
    return Err(cls, cls in RETRYABLE, str(status), _msg(msg))


def _telegram(status: int, body) -> Optional[Err]:
    if 200 <= status < 300 and isinstance(body, dict) and body.get("ok") is True:
        return None
    desc = body.get("description") if isinstance(body, dict) else None
    code = body.get("error_code") if isinstance(body, dict) and isinstance(body.get("error_code"), int) else status
    cls = _by_http(code if isinstance(code, int) else status)
    if code == 401:
        cls = "auth_expired"
    elif code == 403:
        cls = "permission_denied"         # المستخدم أوقف البوت/حظره
    return Err(cls, cls in RETRYABLE, str(code), _msg(desc))


def parse_body(raw: bytes):
    try:
        return json.loads(raw.decode("utf-8")) if raw else None
    except Exception:
        return None


def classify(platform: str, status: int, raw: bytes) -> Optional[Err]:
    """None = نجاح."""
    body = parse_body(raw)
    return {"meta": _meta, "tiktok": _tiktok, "telegram": _telegram}[platform](status, body)
