#!/usr/bin/env bash
# يجهّز قاعدتي P4 (p4_central, p4_vault) بالمخطط وبيانات وهمية (4 عملاء تجريبيين)، وحسابات الخدمة (LOGIN).
set -euo pipefail
cd "$(dirname "$0")/.."
PW=$(grep ^P4_SVC_PW .env | cut -d= -f2)
P="docker exec -i central-pg psql -U postgres -q -v ON_ERROR_STOP=1"
$P -d postgres -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname IN ('p4_central','p4_vault') AND pid <> pg_backend_pid()" >/dev/null
$P -d postgres -c "DROP DATABASE IF EXISTS p4_central" -c "DROP DATABASE IF EXISTS p4_vault" -c "CREATE DATABASE p4_central" -c "CREATE DATABASE p4_vault" >/dev/null
$P -d postgres -f /work/db/00_roles.sql >/dev/null
$P -d p4_central -c "REVOKE ALL ON DATABASE p4_central FROM PUBLIC; GRANT CONNECT ON DATABASE p4_central TO app_runtime, app_jobs, app_ops, app_owner, app_resolver, app_ops_fn, app_broker; GRANT TEMPORARY ON DATABASE p4_central TO app_owner;" >/dev/null
for f in 10_schema 20_rls 30_functions 35_broker_auth 40_partitions; do $P -d p4_central -f /work/db/$f.sql >/dev/null; done
$P -d p4_central -f /work/db/tests/00_harness.sql >/dev/null
$P -d p4_central -f /work/db/tests/10_setup.sql >/dev/null          # عملاء وهميون A,B,C,D
$P -d p4_central -f /work/ops/p4_fixture_e.sql >/dev/null          # عميل E قيد الإعداد (TESTING)
$P -d p4_central -c "DROP SCHEMA t CASCADE" >/dev/null
$P -d p4_vault -f /work/db/50_vault.sql >/dev/null; $P -d p4_vault -f /work/db/51_vault_broker.sql >/dev/null
for spec in "broker_central_svc:app_broker" "broker_vault_svc:broker_rw" "n8n_runtime_svc:app_runtime" "n8n_jobs_svc:app_jobs"; do
  u=${spec%%:*}; r=${spec##*:}
  $P -d postgres -c "DO \$\$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='$u') THEN CREATE ROLE $u LOGIN IN ROLE $r; END IF; END \$\$" -c "ALTER ROLE $u PASSWORD '$PW' LOGIN" >/dev/null
done
$P -d p4_vault -c "GRANT CONNECT ON DATABASE p4_vault TO broker_rw" >/dev/null 2>&1 || true
echo "p4_central / p4_vault جاهزتان (عملاء وهميون)"
