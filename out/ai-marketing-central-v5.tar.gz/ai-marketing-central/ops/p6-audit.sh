#!/usr/bin/env bash
# P6: اختبارات الأمان الحية على بيئة P4 المحلية. يتطلب ./ops/p4-up.sh. يعيد الحالة أولاً (p4-reset) ما لم يُمرَّر --no-reset.
set -uo pipefail
cd "$(dirname "$0")/.."
[ "${1:-}" = "--no-reset" ] || ./ops/p4-reset.sh >/dev/null 2>&1 || { echo "FAIL: p4-reset"; exit 1; }
PW=$(grep ^POSTGRES_PASSWORD .env | cut -d= -f2); HK=$(grep ^BROKER_HMAC_KEY .env | cut -d= -f2); EK=$(grep ^N8N_ENCRYPTION_KEY .env | cut -d= -f2)
docker run --rm --network central_internal_only -e PGPASSWORD="$PW" -e BROKER_HMAC_KEY="$HK" -e N8N_ENCRYPTION_KEY="$EK" \
  -v "$PWD/ops/p6_inject.py:/w/x.py:ro" -v "$PWD/.secrets/p4_fake_tokens.json:/w/fake.json:ro" -w /w --entrypoint python central-broker:dev x.py
