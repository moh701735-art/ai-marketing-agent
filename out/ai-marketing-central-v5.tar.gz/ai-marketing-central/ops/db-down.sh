#!/usr/bin/env bash
# إيقاف الحاوية؛ مع --wipe يحذف أيضاً حجم البيانات (محلي فقط).
cd "$(dirname "$0")/.."
docker compose --env-file .env -f ops/docker-compose.yml down ${1:+-v}
