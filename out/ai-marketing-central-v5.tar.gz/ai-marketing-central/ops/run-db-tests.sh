#!/usr/bin/env bash
# يشغّل اختبارات القاعدة داخل حاوية postgres المحلية ويحفظ السجل الكامل في docs/results/.
set -euo pipefail
cd "$(dirname "$0")/.."
LOG="docs/results/db-tests-$(date -u +%Y%m%dT%H%M%SZ).log"
{ echo "# db tests  $(date -u +%FT%TZ)  postgres: $(docker exec central-pg psql -U postgres -Atc 'show server_version')";
  docker exec central-pg bash /work/db/run_tests.sh; } 2>&1 | tee "$LOG"
docker exec central-pg psql -U postgres -d central_test -AtF $'\t' -c "select id, case when ok then 'PASS' else 'FAIL' end, name, coalesce(detail,'') from t.results order by id" > "${LOG%.log}.results.tsv"
echo "log: $LOG"; echo "per-test results: ${LOG%.log}.results.tsv ($(wc -l < "${LOG%.log}.results.tsv") rows)"
