#!/usr/bin/env bash
# يولّد .env و .secrets/ بقيم عشوائية جديدة (لا قيم من أي نظام آخر). لا يستبدل ما هو موجود.
set -euo pipefail
cd "$(dirname "$0")/.."
umask 077; mkdir -p .secrets
touch .env
add() { grep -q "^$1=" .env || echo "$1=$2" >> .env; }
add POSTGRES_PASSWORD "$(openssl rand -hex 24)"
add P4_SVC_PW "$(openssl rand -hex 16)"
add N8N_ENCRYPTION_KEY "$(openssl rand -hex 24)"
add BROKER_HMAC_KEY "$(openssl rand -hex 32)"        # مفتاح n8n->Broker (نص ASCII: نفس البايتات بالطرفين)
add BROKER_ADMIN_KEY "$(openssl rand -hex 32)"
[ -f .secrets/backup.pass ] || openssl rand -hex 32 > .secrets/backup.pass
if [ ! -f .secrets/broker_secrets.json ]; then
  K=$(grep ^BROKER_HMAC_KEY .env | cut -d= -f2); A=$(grep ^BROKER_ADMIN_KEY .env | cut -d= -f2)
  printf '{"kek":"%s","hmac_keys":{"n8n-runtime":{"key":"%s","scope":"runtime"},"ops-admin":{"key":"%s","scope":"admin"}}}' \
    "$(openssl rand -base64 32)" "$(printf %s "$K" | base64 -w0)" "$(printf %s "$A" | base64 -w0)" > .secrets/broker_secrets.json
fi
echo ".env و .secrets/ جاهزة (غير مرفوعة إلى Git)"
