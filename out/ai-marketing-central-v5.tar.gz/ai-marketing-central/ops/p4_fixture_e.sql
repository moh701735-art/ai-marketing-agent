-- عميل تجريبي وهمي E (قيد الاعداد TESTING): لتجربة مسار onboarding -> فحوصات الجاهزية -> READY على n8n المحلي. بيانات وهمية فقط.
\set E '\'e0000000-0000-0000-0000-000000000001\''
INSERT INTO core.tenants (tenant_id, slug, display_name, status, features) VALUES (:E,'tenant-e','E','CONFIGURATION_REQUIRED','{"meta":true,"tiktok":true,"schedule":true}');
INSERT INTO core.subscriptions (tenant_id, plan, status, current_period_end, grace_days, limits) VALUES (:E,'standard','active', now() + interval '30 days', 3, '{}');
INSERT INTO core.config_versions (tenant_id, version, config, author) VALUES (:E, 1, '{"lang":"ar"}', 'p4-fixture');
UPDATE core.tenants SET active_config_version = 1, status = 'TESTING' WHERE tenant_id = :E;
INSERT INTO core.bots (tenant_id, bot_public_id, telegram_bot_id, secret_ref, webhook_secret_hash, status)
  VALUES (:E,'botEEEEEEEEEEEEEEEEEEEEEEEE', 555, 'ref-bot-e', ext.digest('secret-e','sha256'), 'active');
INSERT INTO core.tenant_users (tenant_id, telegram_user_id, role) VALUES (:E,5001,'owner'),(:E,5002,'viewer');
INSERT INTO core.platform_connections (connection_id, tenant_id, platform, auth_mode, external_user_id, secret_ref) VALUES
 ('e1000000-0000-0000-0000-000000000001',:E,'meta','oauth_user','fbE','ref-e-meta'),
 ('e1000000-0000-0000-0000-000000000002',:E,'tiktok','tiktok_oauth','ttE','ref-e-tt');
INSERT INTO core.ad_accounts (tenant_id, platform, external_id, connection_id, name) VALUES
 (:E,'meta','act_E1','e1000000-0000-0000-0000-000000000001','E meta'),
 (:E,'tiktok','tt_E1','e1000000-0000-0000-0000-000000000002','E tiktok');
INSERT INTO core.pages (tenant_id, page_id, connection_id) VALUES (:E,'page_E1','e1000000-0000-0000-0000-000000000001');
