#!/usr/bin/env bash
# يعيد حالة P4 المحلية إلى نقطة معروفة (قاعدتان جديدتان + أسرار وهمية + workflows) دون إعادة بناء الصور.
set -euo pipefail
cd "$(dirname "$0")/.."
./ops/p4-db.sh | tail -1
docker restart central-broker central-n8n >/dev/null
for i in $(seq 1 40); do docker exec central-n8n wget -qO- http://localhost:5678/healthz >/dev/null 2>&1 && break; sleep 2; done
sleep 4
./ops/p4-seed.sh
./ops/p4-import.sh | tail -4
