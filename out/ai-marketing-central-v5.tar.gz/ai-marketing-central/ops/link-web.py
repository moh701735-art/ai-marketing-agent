#!/usr/bin/env python3
"""صفحة ربط وكالة تيك توك (مؤقتة): تفتحها بالمتصفح، تكتب App Secret وتلصق رابط الرجوع (أو الـauth_code)، تختار الحسابات، وتربطها.
- تشتغل على المضيف بـ HTTPS بشهادة الموقع الحقيقية (من Caddy) على منفذ مؤقت، برابط فيه رمز عشوائي طويل؛ أي مسار آخر = 404.
- تغلق نفسها بعد نجاح الربط أو 20 دقيقة أو 8 محاولات خاطئة، وتغلق المنفذ بالجدار الناري وتحذف نسخة الشهادة المؤقتة.
- الأسرار (App Secret، auth_code، التوكن) تبقى بالذاكرة فقط: التوكن يذهب للخزنة، ولا شيء يُكتب بملف أو يُطبع.
التشغيل (من /opt/central):  python3 ops/link-web.py"""
import hmac, html, http.server, importlib.util, os, re, secrets, shutil, socketserver, ssl, subprocess, sys, tempfile, threading, time, urllib.parse
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("la", HERE / "link-tiktok-agency.py")
la = importlib.util.module_from_spec(spec); spec.loader.exec_module(la)
at = la.at

PORT = int(os.environ.get("LW_PORT", "8443"))
LIFETIME = int(os.environ.get("LW_LIFETIME", str(20 * 60)))
MAX_BAD = 8
MAX_BODY = 8192
TOKEN = secrets.token_urlsafe(24)
SESSIONS = {}          # sid -> dict(token, granted, info, taken, slug, tid, ts)   (ذاكرة فقط)
STATE = {"bad": 0, "done": False}
LOCK = threading.Lock()
DB = os.environ.get("TENANT_DB", "central")

CSS = ("body{font-family:system-ui,Segoe UI,Tahoma,sans-serif;background:#0f1115;color:#e8eaed;margin:0;padding:16px}"
       ".c{max-width:640px;margin:0 auto;background:#171a21;border:1px solid #2a2f3a;border-radius:12px;padding:20px}"
       "h1{font-size:20px;margin:0 0 12px}label{display:block;margin:14px 0 6px;font-weight:600}"
       "input[type=text],input[type=password],textarea{width:100%;box-sizing:border-box;padding:10px;border-radius:8px;border:1px solid #3a4150;background:#0f1115;color:#e8eaed;font-size:15px}"
       "textarea{min-height:70px}button{margin-top:16px;padding:12px 18px;border:0;border-radius:8px;background:#2f7bf5;color:#fff;font-size:16px;cursor:pointer}"
       ".m{color:#9aa4b2;font-size:13px;margin-top:6px}.e{background:#3a1d1d;border:1px solid #7a2e2e;padding:10px;border-radius:8px;margin:10px 0}"
       ".ok{background:#16301f;border:1px solid #2e7a45;padding:10px;border-radius:8px;margin:10px 0}"
       "table{width:100%;border-collapse:collapse;margin-top:8px}td{padding:6px 4px;border-bottom:1px solid #242a35;font-size:14px}.t{color:#9aa4b2}")


def page(body, status=200):
    doc = ('<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
           '<title>ربط وكالة تيك توك</title><style>%s</style></head><body><div class="c">%s</div></body></html>' % (CSS, body))
    return status, doc.encode("utf-8")


def form_page(err=""):
    e = '<div class="e">%s</div>' % html.escape(err) if err else ""
    return page('<h1>ربط وكالة تيك توك بالبوت</h1>%s'
                '<form method="post" action="list" autocomplete="off">'
                '<label>1) App Secret (من صفحة تطبيقك بتيك توك للمطورين، 40 حرف وأرقام)</label><input type="password" name="secret" autocomplete="off">'
                '<label>2) رابط الرجوع كامل بعد الموافقة (الصقه كما هو من شريط العنوان) أو الـauth_code فقط</label><textarea name="link" autocomplete="off"></textarea>'
                '<div class="m">الرابط يبدأ بـ agent.mohammedai.tech/tiktok-cb?auth_code=... وقد تظهر صفحة خطأ، هذا طبيعي. الكود ينتهي بدقائق ولمرة وحدة، فالصقه فوراً.</div>'
                '<label>اسم العميل (tenant)</label><input type="text" name="slug" value="mohm">'
                '<button type="submit">عرض الحسابات</button></form>' % e)


def extract_code(s):
    s = (s or "").strip()
    m = re.search(r"auth_code=([0-9A-Za-z_\-]{16,128})", s)
    if m:
        return m.group(1)
    s = s.split("&")[0].strip()
    return s if re.fullmatch(r"[0-9A-Za-z_\-]{16,128}", s) else ""


def purge_sessions():
    now = time.time()
    for k in [k for k, v in SESSIONS.items() if now - v["ts"] > 600]:
        SESSIONS.pop(k, None)


def do_list(form):
    secret = form.get("secret", "").strip()
    code = extract_code(form.get("link", ""))
    slug = form.get("slug", "mohm").strip() or "mohm"
    if not re.fullmatch(r"[0-9a-fA-F]{20,64}", secret):
        return form_page("App Secret لازم يكون حروف وأرقام فقط (40 حرف) بدون مسافات. تأكد إنك نسخته من خانة App Secret (مو App ID).")
    if not code:
        return form_page("ما لقيت auth_code. الصق رابط الرجوع كامل من شريط العنوان، أو الكود فقط.")
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,48}", slug):
        return form_page("اسم العميل غير صالح.")
    tid = at.psql(DB, "SELECT tenant_id FROM core.tenants WHERE slug = :'slug'", {"slug": slug}, tx=False)
    if not tid:
        return form_page("ما لقيت عميلاً بهذا الاسم.")
    try:
        r = la.call(f"{la.API}/oauth2/access_token/", {"app_id": la.DEFAULT_APP_ID, "secret": secret, "auth_code": code})
    except Exception as e:      # شبكة/تيك توك
        return form_page("ما كدرت أوصل لتيك توك: %s" % type(e).__name__)
    if r.get("code") != 0:
        return form_page("رفضها تيك توك (%s): %s. غالباً الكود انتهى أو انستعمل، أو الـApp Secret غلط. افتح رابط التفويض من جديد وجيب كود جديد." % (r.get("code"), str(r.get("message"))[:120]))
    d = r["data"]
    token = d["access_token"]
    granted = [str(x) for x in d.get("advertiser_ids", []) if re.fullmatch(r"[0-9]{5,24}", str(x))]
    if not granted:
        return form_page("هذا التفويض ما فيه حسابات إعلانية.")
    info = la.account_info(token, granted)
    taken = set(at.psql(DB, "SELECT external_id FROM core.ad_accounts WHERE platform = 'tiktok' AND unlinked_at IS NULL", {}, tx=False).split())
    sid = secrets.token_hex(16)
    with LOCK:
        purge_sessions()
        SESSIONS[sid] = {"token": token, "granted": granted, "info": info, "taken": taken, "slug": slug, "tid": tid, "ts": time.time()}
    rows = []
    for a in granted:
        nm, cur = info.get(a, ("", ""))
        if a in taken:
            rows.append('<tr><td></td><td class="t">%s</td><td>%s</td><td class="t">%s</td><td class="t">مربوط مسبقاً</td></tr>' % (a, html.escape(nm or "-"), html.escape(cur or "?")))
        else:
            rows.append('<tr><td><input type="checkbox" name="acc" value="%s" checked></td><td>%s</td><td>%s</td><td>%s</td><td></td></tr>' % (a, a, html.escape(nm or "-"), html.escape(cur or "?")))
    n_new = sum(1 for a in granted if a not in taken)
    return page('<h1>اختر الحسابات</h1><div class="m">%d حساب بالتفويض، %d جديد. الكل محدد افتراضياً. ملاحظة: حسابات الدينار (IQD) تنقرأ تقاريرها بس ما ينرفع عليها حملات.</div>'
                '<form method="post" action="link"><input type="hidden" name="sid" value="%s"><table>%s</table>'
                '<button type="submit">ربط المحدد</button></form>' % (len(granted), n_new, sid, "".join(rows)))


def do_link(form_multi):
    sid = (form_multi.get("sid") or [""])[0]
    with LOCK:
        purge_sessions()
        s = SESSIONS.pop(sid, None)
    if not s:
        return form_page("انتهت الجلسة (10 دقايق). ابدأ من جديد بكود جديد.")
    chosen = [a for a in dict.fromkeys(form_multi.get("acc", [])) if a in s["granted"] and a not in s["taken"]]
    if not chosen:
        return form_page("ما اخترت حسابات جديدة.")
    try:
        la.do_link(DB, s["slug"], s["tid"], s["token"], chosen, s["info"])
    except SystemExit as e:
        return form_page("فشل الربط بالقاعدة وانلغى (التوكن انبطل). التفاصيل بالطرفية.")
    STATE["done"] = True
    names = "".join("<tr><td>%s</td><td>%s</td></tr>" % (a, html.escape(s["info"].get(a, ("", ""))[0] or "-")) for a in chosen)
    return page('<h1>تم الربط</h1><div class="ok">ربطت %d حساب بالـtenant %s.</div><table>%s</table>'
                '<div class="m">هسه ارجع للطرفية وشغّل: bash deploy/run-readiness.sh 2>&1 | tail -3 (المتوقع READY). الصفحة تغلق نفسها.</div>' % (len(chosen), html.escape(s["slug"]), names))


class H(http.server.BaseHTTPRequestHandler):
    server_version = "x"
    sys_version = ""

    def log_message(self, *a):      # لا سجلات (قد تحوي مسارات/قيم)
        pass

    def send(self, status, body, ctype="text/html; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)

    def route(self):
        parts = urllib.parse.urlsplit(self.path).path.split("/")      # ['', TOKEN, action]
        if len(parts) < 3 or not hmac.compare_digest(parts[1].encode(), TOKEN.encode()):
            return None
        return parts[2]

    def not_found(self):
        self.send(404, b"")

    def do_GET(self):
        if self.route() != "":
            return self.not_found()
        self.send(*form_page())

    def do_POST(self):
        act = self.route()
        if act not in ("list", "link"):
            with LOCK:
                STATE["bad"] += 1
            return self.not_found()
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0 or n > MAX_BODY:
            return self.send(413, b"")
        raw = self.rfile.read(n).decode("utf-8", "replace")
        multi = urllib.parse.parse_qs(raw, keep_blank_values=True)
        form = {k: v[0] for k, v in multi.items()}
        status, body = do_list(form) if act == "list" else do_link(multi)
        if b"e\">" in body or status != 200:
            with LOCK:
                STATE["bad"] += 1
        self.send(status, body)


class Srv(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def watchdog(srv):
    t0 = time.time()
    while True:
        time.sleep(1)
        if STATE["done"]:
            time.sleep(3)
            break
        if STATE["bad"] >= MAX_BAD or time.time() - t0 > LIFETIME:
            break
    srv.shutdown()


def read_domain():
    for line in Path("deploy/.env").read_text().splitlines():
        if line.startswith("DOMAIN="):
            return line.split("=", 1)[1].strip()
    sys.exit("DOMAIN غير موجود بـ deploy/.env")


def fetch_cert(domain, tmp):
    cname = (os.environ.get("COMPOSE_PROJECT_NAME") or "central-stg") + "-caddy"
    out = {}
    for ext, mode in (("crt", 0o644), ("key", 0o600)):
        r = subprocess.run(["docker", "exec", cname, "sh", "-c", f"cat /data/caddy/certificates/*/{domain}/{domain}.{ext}"], capture_output=True)
        if r.returncode or not r.stdout:
            sys.exit("ما كدرت أقرأ شهادة الموقع من Caddy (%s)" % ext)
        p = Path(tmp) / f"s.{ext}"
        p.write_bytes(r.stdout); os.chmod(p, mode)
        out[ext] = str(p)
    return out


def fw(action):
    if os.environ.get("LW_NO_UFW"):
        return
    subprocess.run(["ufw", action, f"{PORT}/tcp"] if action == "allow" else ["ufw", "delete", "allow", f"{PORT}/tcp"], capture_output=True)


def main():
    if os.geteuid() != 0 and not os.environ.get("LW_TEST"):
        sys.exit("شغّله كـ root من /opt/central")
    domain = os.environ.get("LW_DOMAIN") or read_domain()
    tmp = tempfile.mkdtemp(prefix="lw-")
    os.chmod(tmp, 0o700)
    try:
        cert = (os.environ.get("LW_CERT"), os.environ.get("LW_KEY")) if os.environ.get("LW_CERT") else None
        if cert:
            files = {"crt": cert[0], "key": cert[1]}
        else:
            files = fetch_cert(domain, tmp)
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(files["crt"], files["key"])
        srv = Srv(("0.0.0.0", PORT), H)
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
        fw("allow")
        print("\nافتح هذا الرابط بالمتصفح (لازم ينفتح بقفل أخضر):\n\n  https://%s:%d/%s/\n" % (domain, PORT, TOKEN))
        print("الصفحة تشتغل 20 دقيقة وتغلق نفسها بعد الربط. لا ترسل الرابط لأحد. للإلغاء اضغط Ctrl+C.\n")
        threading.Thread(target=watchdog, args=(srv,), daemon=True).start()
        try:
            srv.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            srv.server_close()
    finally:
        fw("delete")
        shutil.rmtree(tmp, ignore_errors=True)
        print("أغلقت الصفحة والمنفذ.")


if __name__ == "__main__":
    main()
