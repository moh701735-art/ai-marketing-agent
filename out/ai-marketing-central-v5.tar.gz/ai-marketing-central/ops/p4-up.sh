#!/usr/bin/env bash
# يشغّل بيئة P4 المحلية كاملة: Postgres + p4 DBs + Broker + منصات وهمية + n8n جديد. كله على الشبكة المعزولة، بدون أي اتصال خارجي.
set -euo pipefail
cd "$(dirname "$0")/.."
./ops/init-env.sh >/dev/null
./ops/db-up.sh | tail -1
./ops/p4-db.sh
CA=""; [ -f /root/.ccr/ca-bundle.crt ] && CA="--secret id=ca,src=/root/.ccr/ca-bundle.crt"
DOCKER_BUILDKIT=1 docker build -q $CA -t central-broker:dev broker/ >/dev/null
chgrp 10001 .secrets/broker_secrets.json && chmod 440 .secrets/broker_secrets.json
docker compose --env-file .env -f ops/docker-compose.yml --profile p4 up -d --force-recreate platform-mock broker n8n >/dev/null 2>&1
for i in $(seq 1 60); do
  docker exec central-n8n wget -qO- http://localhost:5678/healthz >/dev/null 2>&1 && break; sleep 2
done
docker exec central-n8n wget -qO- http://localhost:5678/healthz >/dev/null && echo "n8n: healthy"
docker run --rm --network central_internal_only python:3.11-slim python -c "import urllib.request;print('broker:',urllib.request.urlopen('http://broker:8080/healthz',timeout=10).read().decode())"
docker run --rm --network central_internal_only python:3.11-slim python -c "import urllib.request,json;print('mock:',urllib.request.urlopen('http://platform-mock:8080/__control/calls',timeout=10).read().decode())"
