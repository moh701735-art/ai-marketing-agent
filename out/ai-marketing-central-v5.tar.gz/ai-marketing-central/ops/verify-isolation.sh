#!/usr/bin/env bash
# يثبت عملياً: المشروع لا يتصل بأي نظام آخر، والحاوية معزولة شبكياً. كل بند PASS/FAIL مع الدليل.
set -uo pipefail
cd "$(dirname "$0")/.."
LOG="docs/results/isolation-$(date -u +%Y%m%dT%H%M%SZ).log"; exec > >(tee "$LOG") 2>&1
F=0; chk() { if [ "$2" = "0" ]; then echo "PASS  $1"; else echo "FAIL  $1  [$3]"; F=1; fi; }
echo "isolation check $(date -u +%FT%TZ)"

python3 scripts/scan_repo.py >/tmp/scan.out; chk "فاحص الأسرار + معرّفات النظام القديم: $(tail -1 /tmp/scan.out)" $? "$(head -3 /tmp/scan.out)"
NR=$(git remote -v | awk '{print $2}' | grep -Ec '^(https?://|ssh://|git://|[A-Za-z0-9_.-]+@)' || true)
[ "$NR" = 0 ]; chk "لا remote شبكي في Git (remote محلي إلى ملف bundle بعد الاستنساخ مسموح)" $? "$(git remote -v | head -1)"
N=$(grep -rEl "import (requests|urllib|http\.client|socket|aiohttp|httpx)|from (requests|urllib|http|socket|aiohttp|httpx)" broker/*.py | wc -l)
[ "$N" = 0 ]; chk "كود الـ Broker الحالي لا يستورد أي مكتبة شبكة" $? "files=$N"
N=$(grep -rlE --include=*.py "graph\.facebook\.com|business-api\.tiktok\.com|api\.telegram\.org" broker/app | grep -vc "config.py" || true)
[ "$N" = 0 ]; chk "أسماء مضيفي المنصات الحقيقية لا تظهر في كود الخدمة إلا في حارس config.py" $? "files=$N"
[ -z "$(grep -n 'ports:\|network_mode\|extra_hosts' ops/docker-compose.yml)" ]; chk "compose بلا ports/host network/extra_hosts" $? "found"

docker network inspect central_internal_only -f '{{.Internal}}' | grep -qx true; chk "الشبكة internal=true" $? "$(docker network inspect central_internal_only -f '{{.Internal}}')"
[ "$(docker inspect central-pg -f '{{json .HostConfig.PortBindings}}')" = "{}" ]; chk "لا منافذ منشورة على المضيف" $? "$(docker inspect central-pg -f '{{json .HostConfig.PortBindings}}')"
[ "$(docker inspect central-pg -f '{{.HostConfig.NetworkMode}}')" = "central_internal_only" ]; chk "الحاوية على الشبكة المعزولة فقط" $? "$(docker inspect central-pg -f '{{.HostConfig.NetworkMode}}')"
docker exec central-pg bash -c 'timeout 5 bash -c "echo > /dev/tcp/1.1.1.1/443"' 2>/dev/null; R=$?
[ $R -ne 0 ]; chk "اتصال TCP خارجي (1.1.1.1:443) من الحاوية يفشل [exit=$R]" $? "اتصل!"
docker exec central-pg getent hosts example.com >/dev/null 2>&1; R=$?
[ $R -ne 0 ]; chk "حل DNS لعنوان خارجي من الحاوية يفشل [exit=$R]" $? "حلّ!"
M=$(docker inspect central-pg -f '{{range .Mounts}}{{.Source}}->{{.Destination}}({{.RW}}) {{end}}')
echo "  mounts: $M"
echo "$M" | grep -q "/work/db(false)" && echo "$M" | grep -q "/work/ops(false)"; chk "مجلدات المستودع مركّبة للقراءة فقط" $? ""
echo "  حاويات تعمل الآن: $(docker ps --format '{{.Names}}' | tr '\n' ' ')"
[ "$(docker ps --format '{{.Names}}' | grep -vc '^central-')" = 0 ]; chk "لا حاويات أخرى على هذا المضيف" $? ""
echo; [ $F = 0 ] && echo "ISOLATION: PASS" || echo "ISOLATION: FAIL"; exit $F
