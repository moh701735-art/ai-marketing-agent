#!/usr/bin/env python3
"""إضافة عميل جديد للورك فلو المركزي بأمر واحد (يعمل على بيئة Docker المحلية، P4_DB افتراضياً p4_central).

الأسرار (توكن البوت/ميتا/تيك توك) لا تُمرَّر كوسائط: من متغيرات بيئة TENANT_BOT_TOKEN / TENANT_META_TOKEN / TENANT_TIKTOK_TOKEN
أو تُسأل بإخفاء (getpass). تُخزَّن بالـ vault عبر Broker فقط؛ القاعدة المركزية تحمل المؤشر (secret_ref) لا القيمة.
الناتج: عميل بحالة TESTING (لا READY إلا بعد نجاح فحوصات R01–R15)، وسر الـ webhook يُكتب مرة واحدة في .secrets/webhook-<slug>.txt (0600).

مثال:
  TENANT_BOT_TOKEN=... python3 ops/add-tenant.py --slug acme --name "شركة أكمي" --features meta,tiktok,schedule \\
     --owner 123456789 --user 987654321:viewer --plan standard --days 30 \\
     --meta-user fb_user_id --meta-ad-account act_123 --page 1122334455 \\
     --tiktok-user tt_open_id --tiktok-ad-account 7610438442517954567
  أضف --dry-run لعرض الخطة بدون أي كتابة."""
import argparse, getpass, hashlib, json, os, re, secrets, subprocess, sys, uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FEATURES = {"meta", "tiktok", "schedule"}
ROLES = {"owner", "manager", "viewer"}
# قابلة للتهيئة لبيئة staging/prod (deploy/): افتراضياً بيئة P4 المحلية
PG_CONTAINER = os.environ.get("PG_CONTAINER", "central-pg")
BROKER_NETWORK = os.environ.get("BROKER_NETWORK", "central_internal_only")
BROKER_IMAGE = os.environ.get("BROKER_IMAGE", "central-broker:dev")
ENV_FILE = os.environ.get("ENV_FILE", ".env")


def die(msg):
    print("خطأ:", msg, file=sys.stderr); sys.exit(2)


def env_key(name):
    for line in (ROOT / ENV_FILE).read_text().splitlines():
        if line.startswith(name + "="):
            return line.split("=", 1)[1]
    die(f"{name} غير موجود في .env (شغّل ops/init-env.sh)")


def secret(env, prompt, required):
    v = os.environ.get(env) or (getpass.getpass(prompt + ": ") if sys.stdin.isatty() else "")
    v = v.strip()
    if required and not v:
        die(f"{prompt} مطلوب (متغير {env})")
    return v


def psql(db, sql, vars_, tx=True):
    cmd = ["docker", "exec", "-i", PG_CONTAINER, "psql", "-U", "postgres", "-d", db, "-q", "-v", "ON_ERROR_STOP=1", "-At"]
    if tx:
        cmd.append("-1")
    for k, v in vars_.items():
        cmd += ["-v", f"{k}={v}"]
    r = subprocess.run(cmd + ["-f", "-"], input=sql, text=True, capture_output=True)
    if r.returncode:
        raise RuntimeError(r.stderr.strip().splitlines()[-1] if r.stderr.strip() else "psql failed")
    return r.stdout.strip()


def tg_admin(payload):
    """يستدعي ops/telegram_admin.py داخل شبكة Broker (توقيع admin). يرجع (ok, dict)."""
    cmd = ["docker", "run", "--rm", "-i", "--network", BROKER_NETWORK, "-e", "BROKER_ADMIN_KEY",
           "-v", f"{ROOT}/ops/telegram_admin.py:/w/t.py:ro", "-v", f"{ROOT}/broker/hmac_auth.py:/w/hmac_auth.py:ro", "-w", "/w", "--entrypoint", "python", BROKER_IMAGE, "t.py"]
    r = subprocess.run(cmd, input=json.dumps(payload), text=True, capture_output=True, env={**os.environ, "BROKER_ADMIN_KEY": env_key("BROKER_ADMIN_KEY")})
    try:
        return r.returncode == 0, json.loads(r.stdout.strip().splitlines()[-1])
    except Exception:
        return False, {"error": {"message": (r.stderr or r.stdout).strip()[-200:]}}


def vault(items, mode="put"):
    cmd = ["docker", "run", "--rm", "-i", "--network", BROKER_NETWORK, "-e", "BROKER_ADMIN_KEY",   # القيمة تُورَّث من بيئة العملية (لا تظهر بـ ps)
           "-v", f"{ROOT}/ops/vault_put.py:/w/v.py:ro", "-v", f"{ROOT}/broker/hmac_auth.py:/w/hmac_auth.py:ro", "-w", "/w", "--entrypoint", "python",
           BROKER_IMAGE, "v.py"] + ([] if mode == "put" else ["revoke"])
    r = subprocess.run(cmd, input=json.dumps(items), text=True, capture_output=True, env={**os.environ, "BROKER_ADMIN_KEY": env_key("BROKER_ADMIN_KEY")})
    if r.returncode:
        raise RuntimeError("vault: " + r.stderr.strip()[-200:])


SQL = r"""
BEGIN;
INSERT INTO core.tenants (tenant_id, slug, display_name, status, timezone, currency, features)
  VALUES (:'tid', :'slug', :'name', 'CONFIGURATION_REQUIRED', :'tz', :'cur', :'features'::jsonb);
INSERT INTO core.config_versions (tenant_id, version, config, author, reason)
  VALUES (:'tid', 1, jsonb_build_object('lang', :'lang'), 'add-tenant', 'initial');
UPDATE core.tenants SET active_config_version = 1, status = 'TESTING' WHERE tenant_id = :'tid';
INSERT INTO core.bots (tenant_id, bot_public_id, telegram_bot_id, username, secret_ref, webhook_secret_hash, status)
  VALUES (:'tid', :'bot_public', :'bot_id'::bigint, nullif(:'bot_user',''), :'bot_ref', decode(:'wh_hash', 'hex'), 'active');
\if :has_meta
INSERT INTO core.platform_connections (tenant_id, platform, auth_mode, external_user_id, secret_ref)
  VALUES (:'tid', 'meta', 'oauth_user', :'meta_user', :'meta_ref');
INSERT INTO core.ad_accounts (tenant_id, platform, external_id, connection_id, name)
  SELECT :'tid', 'meta', :'meta_acct', connection_id, :'name' FROM core.platform_connections WHERE tenant_id = :'tid' AND platform = 'meta';
\if :has_page
INSERT INTO core.pages (tenant_id, page_id, connection_id)
  SELECT :'tid', :'page', connection_id FROM core.platform_connections WHERE tenant_id = :'tid' AND platform = 'meta';
\endif
\endif
\if :has_tt
INSERT INTO core.platform_connections (tenant_id, platform, auth_mode, external_user_id, secret_ref)
  VALUES (:'tid', 'tiktok', 'tiktok_oauth', :'tt_user', :'tt_ref');
INSERT INTO core.ad_accounts (tenant_id, platform, external_id, connection_id, name)
  SELECT :'tid', 'tiktok', :'tt_acct', connection_id, :'name' FROM core.platform_connections WHERE tenant_id = :'tid' AND platform = 'tiktok';
\endif
SELECT api_admin.set_subscription(:'tid'::uuid, :'plan', 'active', now() + (:'days' || ' days')::interval, 3, '{}'::jsonb);
"""


def main():
    ap = argparse.ArgumentParser(description="إضافة عميل للورك فلو المركزي", formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    ap.add_argument("--slug", required=True, help="معرّف قصير: a-z 0-9 وشرطة")
    ap.add_argument("--name", required=True)
    ap.add_argument("--features", default="meta,tiktok,schedule")
    ap.add_argument("--owner", required=True, type=int, help="Telegram user id للمالك")
    ap.add_argument("--user", action="append", default=[], help="TG_ID:role (manager|viewer|owner)، يتكرر")
    ap.add_argument("--bot-username", default="")
    ap.add_argument("--plan", default="standard")
    ap.add_argument("--days", type=int, default=30)
    ap.add_argument("--tz", default="Asia/Baghdad")
    ap.add_argument("--currency", default="USD")
    ap.add_argument("--lang", default="ar")
    ap.add_argument("--meta-user"); ap.add_argument("--meta-ad-account"); ap.add_argument("--page")
    ap.add_argument("--tiktok-user"); ap.add_argument("--tiktok-ad-account")
    ap.add_argument("--db", default=os.environ.get("TENANT_DB", os.environ.get("P4_DB", "p4_central")))
    ap.add_argument("--set-webhook", action="store_true", help="بعد الإضافة: setWebhook لتيليجرام (يحتاج Broker بـ BROKER_WEBHOOK_URL_PREFIX وDOMAIN بملف البيئة). P8: منصات حقيقية")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,48}", a.slug): die("slug غير صالح")
    feats = {f for f in a.features.split(",") if f}
    if not feats <= FEATURES: die(f"ميزات غير معروفة: {feats - FEATURES}")
    if not re.fullmatch(r"[a-z0-9_]{2,32}", a.plan): die("plan غير صالح")
    if not 1 <= a.days <= 3650: die("days خارج النطاق")
    if not re.fullmatch(r"[A-Z]{3}", a.currency): die("currency غير صالحة")
    users = [(a.owner, "owner")]
    for u in a.user:
        m = re.fullmatch(r"(\d{3,15}):(owner|manager|viewer)", u)
        if not m: die(f"--user يجب TG_ID:role، وصل: {u}")
        users.append((int(m[1]), m[2]))
    if len({u[0] for u in users}) != len(users): die("مستخدم مكرر")
    has_meta, has_tt = "meta" in feats, "tiktok" in feats
    if has_meta and not (a.meta_user and a.meta_ad_account): die("ميزة meta تحتاج --meta-user و--meta-ad-account")
    if has_tt and not (a.tiktok_user and a.tiktok_ad_account): die("ميزة tiktok تحتاج --tiktok-user و--tiktok-ad-account")

    print(f"الخطة: عميل {a.slug} ({a.name}) · ميزات {sorted(feats)} · مستخدمون {len(users)} · اشتراك {a.plan}/{a.days} يوم · قاعدة {a.db}")
    if psql(a.db, "SELECT 1 FROM core.tenants WHERE slug = :'slug'", {"slug": a.slug}, tx=False):
        die(f"العميل {a.slug} موجود مسبقاً")
    if a.dry_run:
        print("dry-run: لا كتابة."); return

    bot_tok = secret("TENANT_BOT_TOKEN", "توكن بوت تيليجرام", True)
    m = re.fullmatch(r"(\d{6,12}):[A-Za-z0-9_-]{30,}", bot_tok)
    if not m: die("شكل توكن البوت غير صحيح (id:secret)")
    meta_tok = secret("TENANT_META_TOKEN", "توكن Meta", True) if has_meta else ""
    tt_tok = secret("TENANT_TIKTOK_TOKEN", "توكن TikTok", True) if has_tt else ""

    tid = str(uuid.uuid4())
    refs = {"bot": f"ref-{a.slug}-bot-{secrets.token_hex(4)}", "meta": f"ref-{a.slug}-meta-{secrets.token_hex(4)}", "tt": f"ref-{a.slug}-tt-{secrets.token_hex(4)}"}
    items = [{"tenant_id": tid, "kind": "telegram_bot_token", "secret_ref": refs["bot"], "value": bot_tok}]
    if has_meta: items.append({"tenant_id": tid, "kind": "meta_user_token", "secret_ref": refs["meta"], "value": meta_tok})
    if has_tt: items.append({"tenant_id": tid, "kind": "tiktok_token", "secret_ref": refs["tt"], "value": tt_tok})
    bot_public, wh_secret = secrets.token_urlsafe(18), secrets.token_hex(32)

    vault(items)
    print("vault: الأسرار محفوظة (لا تُعرض)")
    v = {"tid": tid, "slug": a.slug, "name": a.name, "tz": a.tz, "cur": a.currency, "lang": a.lang, "features": json.dumps({f: True for f in sorted(feats)}),
         "bot_public": bot_public, "bot_id": m[1], "bot_user": a.bot_username, "bot_ref": refs["bot"], "wh_hash": hashlib.sha256(wh_secret.encode()).hexdigest(),
         "has_meta": str(has_meta).lower(), "has_page": str(bool(a.page)).lower(), "has_tt": str(has_tt).lower(),
         "meta_user": a.meta_user or "", "meta_acct": a.meta_ad_account or "", "page": a.page or "", "meta_ref": refs["meta"],
         "tt_user": a.tiktok_user or "", "tt_acct": a.tiktok_ad_account or "", "tt_ref": refs["tt"], "plan": a.plan, "days": str(a.days)}
    sql = SQL + "".join(f"INSERT INTO core.tenant_users (tenant_id, telegram_user_id, role) VALUES (:'tid', {uid}, '{role}');\n" for uid, role in users) + "COMMIT;\n"
    try:
        psql(a.db, sql, v, tx=False)
    except RuntimeError as e:
        try:
            vault([{"tenant_id": tid, "secret_ref": r["secret_ref"]} for r in items], "revoke")
        except RuntimeError as e2:
            print("تحذير: فشل إبطال الأسرار بعد الخطأ:", e2, file=sys.stderr)
        die(f"فشل إدخال القاعدة (تراجعت العملية وأُبطلت الأسرار): {e}")

    d = ROOT / ".secrets"; d.mkdir(exist_ok=True)
    f = d / f"webhook-{a.slug}.txt"
    fd = os.open(f, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        fh.write(f"bot_public_id={bot_public}\nwebhook_secret_token={wh_secret}\n")
    if a.set_webhook:
        url = f"https://{env_key('DOMAIN')}/webhook/tg-ingress?bot={bot_public}"
        ok, j = tg_admin({"action": "set-webhook", "tenant_id": tid, "secret_ref": refs["bot"], "url": url, "secret_token": wh_secret})
        ok2, info = tg_admin({"action": "webhook-info", "tenant_id": tid, "secret_ref": refs["bot"]}) if ok else (False, {})
        if ok and ok2 and (info.get("data", {}).get("result", {}) or {}).get("url") == url:
            psql(a.db, "UPDATE core.bots SET webhook_set_at = now() WHERE tenant_id = :'tid' AND status = 'active'", {"tid": tid}, tx=False)
            print("webhook: تيليجرام يشير الآن إلى", url.split("?")[0], "(وسُجّل webhook_set_at)")
        else:
            print("تحذير: فشل setWebhook/التحقق:", json.dumps(j if not ok else info, ensure_ascii=False)[:300], "— العميل أُضيف؛ أعد المحاولة بـ deploy/set-webhook.sh", a.slug, file=sys.stderr)
    print(f"تم. tenant_id={tid} الحالة TESTING")
    print(f"bot_public_id={bot_public}  (سر الـ webhook في {f.relative_to(ROOT)}؛ استعمل --set-webhook أو deploy/set-webhook.sh)")
    print("الخطوة التالية: شغّل منفِّذ الجاهزية (wfReadiness00001)؛ العميل يصير READY فقط لما تنجح كل الفحوصات الإلزامية.")


if __name__ == "__main__":
    main()
