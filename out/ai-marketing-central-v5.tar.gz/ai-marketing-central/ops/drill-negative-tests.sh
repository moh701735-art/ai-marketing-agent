#!/usr/bin/env bash
# اختبارات سلبية: التأكد أن آليات التحقق تفشل فعلاً عند العبث (لا نجاح فارغ). تعمل على نسخة مؤقتة ولا تغيّر النسخة الأصلية.
set -uo pipefail
cd "$(dirname "$0")/.."
LOG="docs/results/drill-negative-$(date -u +%Y%m%dT%H%M%SZ).log"; exec > >(tee "$LOG") 2>&1
SRC=$(ls -d ops/backups/drill-* | tail -1); T=$(mktemp -d); cp -r "$SRC"/. "$T"/; F=0
chk() { if [ "$2" = "0" ]; then echo "PASS  $1"; else echo "FAIL  $1"; F=1; fi; }
echo "negative tests on copy of $SRC"
# 1) عبث ببايت واحد في ملف النسخة -> يجب رفض الاستعادة قبل لمس أي شيء
printf '\x00' | dd of="$T/central_dev.dump.gpg" bs=1 seek=100 conv=notrunc 2>/dev/null
( cd "$T" && sha256sum -c SHA256SUMS >/dev/null 2>&1 ); [ $? -ne 0 ]; chk "بايت واحد معدّل في النسخة -> sha256 يكشفه" $?
./ops/restore.sh "$T" >/dev/null 2>&1; [ $? -ne 0 ]; chk "restore.sh يرفض النسخة المعبوث بها" $?
# 2) عبارة تشفير خاطئة -> فك التشفير يفشل
cp -r "$SRC"/. "$T"/; echo wrong-passphrase > "$T/p"; 
gpg --batch --quiet --pinentry-mode loopback --passphrase-file "$T/p" -d "$T/vault_dev.dump.gpg" >/dev/null 2>&1; [ $? -ne 0 ]; chk "عبارة تشفير خاطئة -> فشل فك التشفير" $?
# 3) استعادة على عنقود غير فارغ -> مرفوضة
./ops/restore.sh "$SRC" >/dev/null 2>&1; [ $? -ne 0 ]; chk "الاستعادة فوق قاعدة موجودة تُرفض" $?
# 4) تغيير صف واحد في القاعدة -> بصمة البيانات تكشف الفرق
docker exec central-pg psql -U postgres -d central_dev -qc "BEGIN; UPDATE core.campaigns SET name = name || ' x' WHERE external_id='fake-camp-A1'; COMMIT;" 2>&1 | head -1
docker exec central-pg psql -U postgres -d central_dev -Atq -F'|' -f /work/ops/seed/checksums.sql > "$T/now.txt"
diff -q "$SRC/central_dev.checksums.txt" "$T/now.txt" >/dev/null; [ $? -ne 0 ]; chk "تعديل صف واحد -> مقارنة البصمات تكتشفه" $?
docker exec central-pg psql -U postgres -d central_dev -qc "UPDATE core.campaigns SET name = replace(name,' x','') WHERE external_id='fake-camp-A1'" >/dev/null
docker exec central-pg psql -U postgres -d central_dev -Atq -F'|' -f /work/ops/seed/checksums.sql > "$T/now2.txt"
diff -q "$SRC/central_dev.checksums.txt" "$T/now2.txt" >/dev/null; chk "بعد إرجاع التعديل البصمات تتطابق ثانية" $?
rm -rf "$T"; [ $F = 0 ] && echo "NEGATIVE: PASS" || echo "NEGATIVE: FAIL"; exit $F
