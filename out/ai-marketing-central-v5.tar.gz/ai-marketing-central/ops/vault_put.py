#!/usr/bin/env python3
"""يعمل داخل حاوية على الشبكة المعزولة: يقرأ JSON من stdin ([{tenant_id,kind,secret_ref,value}]) ويخزّنها بالـ vault عبر Broker الإداري.
mode=revoke: يقرأ [{tenant_id,secret_ref}] ويُبطلها. القيم لا تُطبع أبداً. المفتاح من BROKER_ADMIN_KEY."""
import json, os, secrets, sys, time
import httpx
import hmac_auth

KEY = os.environ["BROKER_ADMIN_KEY"].encode()
PATH = "/v1/admin/secrets/revoke" if (len(sys.argv) > 1 and sys.argv[1] == "revoke") else "/v1/admin/secrets"
for it in json.load(sys.stdin):
    body = json.dumps(it).encode()
    ts, nonce = int(time.time()), secrets.token_hex(12)
    r = httpx.post("http://broker:8080" + PATH, content=body, timeout=15, headers={
        "content-type": "application/json", "x-key-id": "ops-admin", "x-timestamp": str(ts), "x-nonce": nonce, "x-signature": hmac_auth.sign(KEY, body, ts, nonce)})
    if r.status_code != 200:
        print("FAILED", it["secret_ref"], r.status_code, r.text[:200], file=sys.stderr); sys.exit(1)
    print("ok", it["secret_ref"])
