#!/usr/bin/env bash
# يملأ central_dev/vault_dev ببيانات وهمية: 4 عملاء، حملتان (A,B) عبر الـ API، لقطات تقارير، سرّان وهميان مشفّران.
set -euo pipefail
cd "$(dirname "$0")/.."
PS="docker exec -i central-pg psql -U postgres -q -v ON_ERROR_STOP=1"
V=$(./scripts/ensure_venv.sh)
$PS -d central_dev < ops/seed/seed_fake_data.sql >/dev/null
ctx() { # bot secret user -> ctx
  local h; h=$($PS -d central_dev -Atc "select encode(ext.digest('$2','sha256'),'hex')")
  docker exec -e PGOPTIONS='-c role=app_runtime' central-pg psql -U postgres -qAt -d central_dev -c "select ctx from api.resolve_context('$1', decode('$h','hex'), $3)"
}
CA=$(ctx botAAAAAAAAAAAAAAAAAAAAAAAA secret-a 1003); CB=$(ctx botBBBBBBBBBBBBBBBBBBBBBBBB secret-b 2002)
JOB() { docker exec -e PGOPTIONS='-c role=app_jobs' central-pg psql -U postgres -qAt -d central_dev -c "select ctx from api.job_contexts('schedule',10) where tenant_id='$1'"; }
RT() { docker exec -e PGOPTIONS="-c role=$1" central-pg psql -U postgres -qAt -d central_dev -c "$2"; }
RT app_runtime "select api.record_campaign('$CA','meta','act_A1','fake-camp-A1','حملة وهمية A','OUTCOME_TRAFFIC',20)" >/dev/null
RT app_runtime "select api.record_campaign('$CB','meta','act_B1','fake-camp-B1','حملة وهمية B','OUTCOME_TRAFFIC',30)" >/dev/null
JA=$(JOB a0000000-0000-0000-0000-000000000001); JB=$(JOB b0000000-0000-0000-0000-000000000001)
RT app_jobs "select api.add_report_snapshot('$JA','meta','fake-camp-A1',now(),12.5,1000,40,3,'USD')" >/dev/null
RT app_jobs "select api.add_report_snapshot('$JB','meta','fake-camp-B1',now(),7.25,500,9,1,'USD')" >/dev/null
"$V/bin/python" ops/seed/vault_seed.py seal | $PS -d vault_dev >/dev/null
echo "seed: $($PS -d central_dev -Atc "select count(*) from core.tenants") tenants, $($PS -d central_dev -Atc "select count(*) from core.campaigns") campaigns, $($PS -d central_dev -Atc "select count(*) from core.report_snapshots") snapshots, $($PS -d vault_dev -Atc "select count(*) from vault.secrets") vault secrets (كلها وهمية)"
