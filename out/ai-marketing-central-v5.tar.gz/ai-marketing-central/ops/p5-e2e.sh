#!/usr/bin/env bash
# P5: سيناريوهات E2E الستة على عميلين مستقلين (A,B) عبر n8n محلي + Broker + قاعدة + منصات وهمية. يعيد الحالة أولاً ما لم يُمرَّر --no-reset.
# يتطلب ./ops/p4-up.sh مرة واحدة. الإيقاف الفعلي للقاعدة 60 ثانية (سيناريو 5).
set -uo pipefail
cd "$(dirname "$0")/.."
[ "${1:-}" = "--no-reset" ] || ./ops/p4-reset.sh >/dev/null 2>&1 || { echo "FAIL: p4-reset"; exit 1; }
PW=$(grep ^POSTGRES_PASSWORD .env | cut -d= -f2); AK=$(grep ^BROKER_ADMIN_KEY .env | cut -d= -f2)
PH() { docker run --rm --network central_internal_only -e PGPASSWORD="$PW" -e BROKER_ADMIN_KEY="$AK" -v "$PWD/ops/p5_e2e.py:/w/x.py:ro" -v "$PWD/.secrets/p4_fake_tokens.json:/w/fake_tokens.json:ro" -w /w --entrypoint python central-broker:dev x.py "$@"; }
RESETMOCK() { docker run --rm --network central_internal_only python:3.11-slim python -c "import urllib.request;urllib.request.urlopen(urllib.request.Request('http://platform-mock:8080/__control/reset',data=b'{}',method='POST'))"; }
EXEC() { docker exec -e N8N_RUNNERS_BROKER_PORT=5690 -e N8N_PORT=5690 central-n8n n8n execute --id="$1" 2>&1 | grep -q '"status": "success"'; }
rc=0
echo "── سيناريو 1: عزل البوتات والعملاء ──";           PH isolation || rc=1
echo "── سيناريو 2: تكرار/توازٍ لنفس الطلب ──";          PH parallel || rc=1
echo "── سيناريو 3: إبطال توكن Meta لعميل A ──";         PH revoke || rc=1
RESETMOCK; EXEC wfConnAlerts0001 || { echo "FAIL: alerts job run"; rc=1; }; PH alerts || rc=1
RESETMOCK; EXEC wfConnAlerts0001 || { echo "FAIL: alerts job run 2"; rc=1; }; PH alerts2 || rc=1
PH recover || rc=1
echo "── سيناريو 4: أعطال المنصة عبر n8n (429/500/مهلة) ──"; PH platform || rc=1
echo "── سيناريو 5: إيقاف القاعدة 60 ثانية ──"
T0=$(date +%s); docker stop central-pg >/dev/null
OUT=$(PH outage_during); echo "$OUT" | grep -v "^IDS"; echo "$OUT" | grep -q "1/1 passed" || rc=1
IDS=$(echo "$OUT" | sed -n 's/^IDS //p')
while [ $(( $(date +%s) - T0 )) -lt 60 ]; do sleep 2; done
docker start central-pg >/dev/null
for i in $(seq 1 60); do docker exec central-pg pg_isready -U postgres >/dev/null 2>&1 && break; sleep 1; done
echo "(القاعدة كانت متوقفة $(( $(date +%s) - T0 )) ثانية)"
PH outage_after $IDS || rc=1
echo "── سيناريو 6: تسريب مقصود ──";                   PH leaks || rc=1
echo "── فحص الأسرار بعد كل السيناريوهات (مع كاناري المستخدم) ──"
XV="LEAKCANARY""987654321:AAF""canary0123456789abcdefghijklmnopq,EAAB""xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
echo "قبل التنظيف (معلومة: نص المستخدم يبقى مؤقتاً داخل SQLite الخاص بـ n8n):"
EXTRA_VALUES="$XV" ./ops/p4-scan-secrets.sh 2>&1 | grep -E "database.sqlite|^SCAN"
./ops/p4-purge-n8n-executions.sh
echo "بعد التنظيف (يجب أن يكون نظيفاً في كل مكان):"
EXTRA_VALUES="$XV" ./ops/p4-scan-secrets.sh 2>&1 | tail -12; [ "${PIPESTATUS[0]}" = 0 ] || rc=1
exit $rc
