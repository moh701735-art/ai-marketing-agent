#!/usr/bin/env python3
"""P6: اختبار حقن/تجاوز على مدخل n8n الحقيقي (webhook تيليجرام الوهمي). يعمل داخل الشبكة المعزولة (ops/p6-audit.sh).
المهاجم: مستخدم مسجّل بعميل A (1001). الهدف: تنفيذ SQL/تعبير n8n/قراءة متغيرات سرية، أو تجاوز عزل العملاء، أو تسريب أسرار بالرد/السجلات."""
import json, os, sys, time, urllib.request
import psycopg

N8N, MOCK = "http://n8n:5678", "http://platform-mock:8080"
BOT_A, SEC_A = "botAAAAAAAAAAAAAAAAAAAAAAAA", "secret-a"
BOT_B, SEC_B = "botBBBBBBBBBBBBBBBBBBBBBBBB", "secret-b"
res = []


def http(method, url, body=None, headers=None, raw=None):
    data = raw if raw is not None else (None if body is None else json.dumps(body).encode())
    req = urllib.request.Request(url, data=data, method=method, headers={"content-type": "application/json", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def calls(): return json.loads(http("GET", MOCK + "/__control/calls")[1])["calls"]
def reset(): http("POST", MOCK + "/__control/reset", {})
def replies(cs): return [c for c in cs if c["platform"] == "telegram" and c["path"].endswith("/sendMessage")]
def chk(i, d, c, det=""):
    res.append(bool(c)); print(("PASS " if c else "FAIL ") + i + " " + d + ("" if c else "  -> " + str(det)[:300]), flush=True)


_u = [int(time.time()) % 10**8 * 10 + 5000]
def send(text, user=1001, bot=BOT_A, sec=SEC_A, wait=4.0):
    reset(); _u[0] += 1
    upd = {"update_id": _u[0], "message": {"message_id": 1, "from": {"id": user}, "chat": {"id": user, "type": "private"}, "text": text, "date": int(time.time())}}
    st, body = http("POST", f"{N8N}/webhook/tg-ingress?bot={bot}", upd, {"x-telegram-bot-api-secret-token": sec})
    time.sleep(wait)
    return st, calls()


db = psycopg.connect(f"postgresql://postgres:{os.environ['PGPASSWORD']}@postgres:5432/p4_central", autocommit=True)
SECRETS = [os.environ.get("BROKER_HMAC_KEY", ""), os.environ.get("N8N_ENCRYPTION_KEY", "")] + [v["value"] for v in json.load(open("/w/fake.json")).values()]
SECRETS = [s for s in SECRETS if len(s) > 8]
tenants_before = db.execute("SELECT count(*) FROM core.tenants").fetchone()[0]
users_before = db.execute("SELECT count(*) FROM core.tenant_users").fetchone()[0]


def leaked(cs):
    # توكن البوت يظهر بمسار sendMessage بطبيعة API تيليجرام (إلى الجهة الصحيحة)؛ التسريب = ظهور سر بنص الرد أو بأي نداء لمنصة أخرى
    body = json.dumps([c["body"] for c in replies(cs)], ensure_ascii=False) + json.dumps([c for c in cs if c["platform"] != "telegram"])
    return [s for s in SECRETS if s in body]


# 1) حقن SQL بنص الرسالة/الأوامر
payloads = ["'; DROP TABLE core.tenants; --", "/campaigns' OR '1'='1", "/accounts; UPDATE core.tenant_users SET role='owner'", "$1", "\\'); SELECT pg_sleep(8); --"]
t0 = time.time()
for p in payloads:
    st, cs = send(p, wait=2.5)
    chk("INJ-SQL", f"sql payload {p[:28]!r}: handled, no stack/SQL text leaked", st in (200, 204) and not any(k in json.dumps(replies(cs)).lower() for k in ("syntax error", "pg_", "psycopg", "postgres", "stack")), replies(cs))
chk("INJ-SQL-T", "no pg_sleep effect (whole batch fast)", time.time() - t0 < 45, time.time() - t0)
chk("INJ-SQL-D", "tenants/users unchanged after injection attempts", db.execute("SELECT count(*) FROM core.tenants").fetchone()[0] == tenants_before and db.execute("SELECT count(*) FROM core.tenant_users").fetchone()[0] == users_before)
chk("INJ-SQL-R", "viewer role not escalated", db.execute("SELECT count(*) FROM core.tenant_users WHERE tenant_id='a0000000-0000-0000-0000-000000000001' AND role='owner'").fetchone()[0] == 1)

# 2) حقن تعبيرات n8n وقراءة المتغيرات السرية
exprs = ["{{ $env.BROKER_HMAC_KEY }}", "={{ $env.N8N_ENCRYPTION_KEY }}", "{{ process.env.BROKER_HMAC_KEY }}", "{{ $json }}", "{{ require('child_process').execSync('id') }}", "${process.env.BROKER_HMAC_KEY}", "{{$workflow.id}}"]
for e in exprs:
    st, cs = send(e, wait=3)
    r = json.dumps(replies(cs))
    chk("INJ-EXPR", f"expression {e[:34]!r} is data: not evaluated / no secret in reply or calls", not leaked(cs) and "uid=" not in r and "wfIngress" not in r, r[:200])

# 3) نص كبير/أحرف تحكم/يونيكود
for name, txt in [("huge 60KB", "A" * 60000), ("control chars", "/help\x00\x1b[31m\r\n\r\nX-Injected: 1"), ("rtl+zero-width", "‮/help​"), ("nested json", '{"a":' * 500)]:
    st, cs = send(txt, wait=3)
    chk("INJ-FUZZ", f"{name}: no 5xx crash, no secret leak", st < 500 and not leaked(cs), (st, replies(cs)))

# 4) تجاوز العزل: مستخدم A يحاول بوت B، وبوت A بمعرّف حملة/حساب B
st, cs = send("/campaigns", user=1001, bot=BOT_B, sec=SEC_B, wait=3)
chk("ISO-X1", "A's user on B's bot gets no data reply", not replies(cs), replies(cs))
st, cs = send("/accounts", user=1001, bot=BOT_A, sec=SEC_B, wait=3)
chk("ISO-X2", "B's webhook secret on A's bot rejected silently", not replies(cs) and not [c for c in cs if c["platform"] in ("meta", "tiktok")], cs)
st, cs = send("ارفع حملة على الحساب act_B1 ميزانية 5 دولار", wait=4)
chk("ISO-X3", "creating on another tenant's ad account never reaches the platform for that account", not [c for c in cs if "act_B1" in json.dumps(c)], [c["path"] for c in cs])

# 5) webhook: رأس السر
for hdr, desc in [({}, "missing secret header"), ({"x-telegram-bot-api-secret-token": ""}, "empty secret"), ({"x-telegram-bot-api-secret-token": SEC_A + "x"}, "wrong secret")]:
    reset()
    st, _ = http("POST", f"{N8N}/webhook/tg-ingress?bot={BOT_A}", {"update_id": 1, "message": {"message_id": 1, "from": {"id": 1001}, "chat": {"id": 1001, "type": "private"}, "text": "/help", "date": 1}}, hdr)
    time.sleep(2)
    chk("WH-SEC", f"{desc}: silent no reply", not replies(calls()), (st, replies(calls())))
for q in ["", "?bot=", "?bot=../../etc/passwd", "?bot=" + "A" * 5000, "?bot=botAAAAAAAAAAAAAAAAAAAAAAAA'--"]:
    st, _ = http("POST", f"{N8N}/webhook/tg-ingress{q}", {"update_id": 2}, {"x-telegram-bot-api-secret-token": SEC_A})
    chk("WH-BOT", f"odd bot param {q[:30]!r}: no 5xx stack", st < 500 or st == 503, st)
st, body = http("POST", f"{N8N}/webhook/tg-ingress?bot={BOT_A}", raw=b"{not json", headers={"x-telegram-bot-api-secret-token": SEC_A})
chk("WH-JSON", "malformed JSON body: clean 4xx, no internals", st < 500 and b"node_modules" not in body and b"stack" not in body.lower(), (st, body[:200]))

# 6) تسريب: السجلات المركزية وقاعدة n8n
errs = db.execute("SELECT coalesce(string_agg(message,' '),'') FROM core.error_log").fetchone()[0]
chk("LEAK-ERR", "no secret/env value in central error_log after attacks", not [s for s in SECRETS if s in errs], errs[:200])
print(f"P6[inject]: {sum(res)}/{len(res)} passed"); sys.exit(0 if all(res) else 1)
