#!/usr/bin/env python3
"""اختبار E2E لـ P4: يرسل تحديثات تيليجرام وهمية إلى n8n المحلي ويتحقق من (ردود البوت، نداءات المنصات الوهمية، صفوف قاعدة البيانات).
يعمل داخل حاوية على الشبكة المعزولة (انظر ops/p4-e2e.sh). لا أي اتصال خارجي."""
import json, os, sys, time, urllib.request
import psycopg

N8N, MOCK = "http://n8n:5678", "http://platform-mock:8080"
BOTS = {"A": ("botAAAAAAAAAAAAAAAAAAAAAAAA", "secret-a", "111"), "B": ("botBBBBBBBBBBBBBBBBBBBBBBBB", "secret-b", "222")}
results = []
RUN = str(int(time.time()))[-6:]

def http(method, url, body=None, headers=None):
    req = urllib.request.Request(url, data=None if body is None else json.dumps(body).encode(), method=method, headers={"content-type": "application/json", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=30) as r: return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e: return e.code, {}

def calls(): return http("GET", MOCK + "/__control/calls")[1]["calls"]
def reset(): http("POST", MOCK + "/__control/reset", {})
def tg(cs): return [c for c in cs if c["platform"] == "telegram" and c["path"].endswith("/sendMessage")]
_uid = [int(time.time()) % 10**8 * 10]
def next_update(): _uid[0] += 1; return _uid[0]

def send(tenant, user, text, secret=None, update_id=None, expect_replies=1, settle=3.0):
    bot, sec, _ = BOTS[tenant]
    reset()
    upd = {"update_id": update_id or next_update(), "message": {"message_id": 1, "from": {"id": user}, "chat": {"id": user, "type": "private"}, "text": text, "date": int(time.time())}}
    st, _ = http("POST", f"{N8N}/webhook/tg-ingress?bot={bot}", upd, {"x-telegram-bot-api-secret-token": sec if secret is None else secret})
    deadline = time.time() + 25
    while time.time() < deadline:
        if len(tg(calls())) >= expect_replies: break
        time.sleep(0.5)
    time.sleep(settle)                                           # فرصة لظهور رد زائد غير مرغوب
    cs = calls()
    return upd["update_id"], cs, tg(cs)

def check(cid, desc, cond, detail=""):
    results.append((cid, bool(cond)))
    print(("PASS " if cond else "FAIL ") + cid + " " + desc + ("" if cond else "  -> " + str(detail)[:400]), flush=True)

def txt(replies): return " || ".join(str(r["body"].get("text", "")) for r in replies)
def posts(cs, plat, frag): return [c for c in cs if c["platform"] == plat and c["method"] == "POST" and frag in c["path"]]

db = psycopg.connect(f"postgresql://postgres:{os.environ['PGPASSWORD']}@postgres:5432/p4_central", autocommit=True)
def q(sql, *a): return db.execute(sql, a).fetchall()

# E01 help
_, cs, r = send("A", 1001, "/help")
check("E01", "A owner /help -> one reply from bot 111 to chat 1001", len(r) == 1 and "/111:" in r[0]["path"].replace("bot111:", "/111:") and r[0]["body"].get("chat_id") == 1001 and "/accounts" in txt(r), r)
# E02 wrong secret / E03 unregistered
_, cs, r = send("A", 1001, "/help", secret="wrong-secret", expect_replies=0)
check("E02", "wrong webhook secret -> silent (no reply, no platform call)", len(cs) == 0, cs)
_, cs, r = send("A", 9999, "/help", expect_replies=0)
check("E03", "unregistered Telegram user -> silent", len(cs) == 0, cs)
# E04/E05 accounts + isolation
_, cs, r = send("A", 1001, "/accounts"); t = txt(r)
check("E04", "A /accounts lists A accounts only", "act_A1" in t and "tt_A1" in t and "_B1" not in t, t)
_, cs, r = send("B", 2001, "/accounts"); t = txt(r)
check("E05", "B /accounts lists B accounts only, via bot 222", "act_B1" in t and "tt_B1" in t and "_A1" not in t and "/telegram/bot222:" in r[0]["path"], (t, r and r[0]["path"][:40]))
# E06 campaigns
_, cs, r = send("A", 1001, "/campaigns")
check("E06", "A /campaigns replies", len(r) == 1, r)
# E07 report
_, cs, r = send("A", 1001, "/report"); t = txt(r)
check("E07", "A /report reads Meta+TikTok through Broker with A tokens only", len(r) == 1 and "12.34" in t and any("act_A1" in c["path"] for c in cs if c["platform"] == "meta") and all("FAKE-B" not in (c["auth"] + c["access_token"]) for c in cs), t)
# E08 create
uid = next_update()
_, cs, r = send("A", 1003, f"/create meta act_A1 20 حملة اختبار {RUN}", update_id=uid); t = txt(r); p = posts(cs, "meta", "/campaigns")
check("E08", "manager creates Meta campaign: exactly one POST, forced PAUSED, success reply", len(p) == 1 and p[0]["body"].get("status") == "PAUSED" and "✅" in t, (p, t))
rows = q("SELECT status::text FROM core.campaigns WHERE name = %s", f"حملة اختبار {RUN}")
check("E09", "campaign recorded in central DB", len(rows) == 1, rows)
# E10 duplicate update (Telegram retry)
_, cs, r = send("A", 1003, f"/create meta act_A1 20 حملة اختبار {RUN}", update_id=uid, expect_replies=0)
check("E10", "duplicate update_id -> no second platform POST, no reply", len(posts(cs, "meta", "/campaigns")) == 0 and len(r) == 0, cs)
# E11 same command, new update (user retried): must not duplicate silently? -> new request key -> creates another (allowed); we only assert exactly one POST
# E12 viewer
_, cs, r = send("A", 1002, "/create meta act_A1 20 viewer حملة"); t = txt(r)
check("E12", "viewer cannot create: no platform call, clear refusal", len(posts(cs, "meta", "/campaigns")) == 0 and "صلاحية" in t, (cs, t))
# E13 budget over personal limit (manager cap 50)
_, cs, r = send("A", 1003, "/create meta act_A1 200 كبيرة"); t = txt(r)
check("E13", "budget above user's limit refused before any platform call", len(posts(cs, "meta", "/campaigns")) == 0 and "الميزانية" in t, (cs, t))
# E14 cross-tenant account
_, cs, r = send("A", 1003, "/create meta act_B1 10 عبر"); t = txt(r)
check("E14", "A manager cannot create on B's ad account", len(posts(cs, "meta", "/campaigns")) == 0 and "غير مرتبط" in t, (cs, t))
# E15 B tiktok isolation
_, cs, r = send("B", 2001, f"/create tiktok tt_B1 10 حملة بي {RUN}"); t = txt(r); p = posts(cs, "tiktok", "/campaign/create")
check("E15", "B owner creates TikTok campaign with B token only", len(p) == 1 and "FAKE-B-TT" in p[0]["access_token"] and p[0]["body"].get("operation_status") in ("DISABLE", "DISABLED") and "✅" in t, (p, t))
# E16 usage error
_, cs, r = send("A", 1003, "/create foo"); t = txt(r)
check("E16", "bad /create syntax -> usage, no platform call", len(cs) == len(r) and "الصيغة" in t, (cs, t))
# E17 platform hard failure on a write -> no blind retry, honest message, recorded as failed/needs_manual_check
reset()
http("POST", MOCK + "/__control/fail", {"platform": "meta", "n": 5, "status": 500, "body": {"error": {"message": "boom"}}})
bot, sec, _ = BOTS["A"]
upd = {"update_id": next_update(), "message": {"message_id": 1, "from": {"id": 1003}, "chat": {"id": 1003, "type": "private"}, "text": f"/create meta act_A1 15 فاشلة {RUN}", "date": int(time.time())}}
http("POST", f"{N8N}/webhook/tg-ingress?bot={bot}", upd, {"x-telegram-bot-api-secret-token": sec})
time.sleep(10); cs = calls(); r = tg(cs); t = txt(r)
check("E17", "write hits 500: exactly one attempt (never resent), user told it is unconfirmed/failed", len(posts(cs, "meta", "/campaigns")) == 1 and len(r) == 1 and ("❌" in t or "⚠️" in t), (len(posts(cs, "meta", "/campaigns")), t))
rows = q("SELECT count(*) FROM core.campaigns WHERE name = %s", f"فاشلة {RUN}")
check("E18", "failed create is NOT recorded as a campaign", rows[0][0] == 0, rows)
rq = q("SELECT status::text FROM core.campaign_requests WHERE idempotency_key = %s", f"tgupd-1003-{upd['update_id']}-create")
check("E19", "ambiguous write recorded as needs_manual_check (never auto-retried)", rq == [("needs_manual_check",)], rq)
reset()
bad = [c for c, ok in results if not ok]
print(f"\nE2E: {len(results) - len(bad)}/{len(results)} passed" + (f"  FAILED: {bad}" if bad else ""))
sys.exit(1 if bad else 0)
