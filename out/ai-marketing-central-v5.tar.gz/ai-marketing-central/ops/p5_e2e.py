#!/usr/bin/env python3
"""P5: سيناريوهات E2E الستة (design-v3 §8) على عميلين مستقلين A و B عبر n8n + Broker + قاعدة مركزية + منصات وهمية.
يعمل داخل الشبكة المعزولة. المراحل تُستدعى من ops/p5-e2e.sh (بعضها يحتاج إيقاف قاعدة/تشغيل Workflow بين مرحلة وأخرى)."""
import hashlib, hmac, json, os, secrets, sys, threading, time, urllib.request
import psycopg
N8N, MOCK, BROKER = "http://n8n:5678", "http://platform-mock:8080", "http://broker:8080"
BOTS = {"A": ("botAAAAAAAAAAAAAAAAAAAAAAAA", "secret-a", "111"), "B": ("botBBBBBBBBBBBBBBBBBBBBBBBB", "secret-b", "222")}
phase = sys.argv[1]
res = []
def chk(i, d, c, det=""): res.append(bool(c)); print(("PASS " if c else "FAIL ") + i + " " + d + ("" if c else " -> " + str(det)[:420]), flush=True)
def db():
    return psycopg.connect(f"postgresql://postgres:{os.environ['PGPASSWORD']}@postgres:5432/p4_central", autocommit=True)
def q(sql, *a):
    with db() as c: return c.execute(sql, a).fetchall()
def mock(path, body=None):
    req = urllib.request.Request(MOCK + path, data=None if body is None else json.dumps(body).encode(), headers={"content-type": "application/json"}, method="POST" if body is not None else "GET")
    return json.loads(urllib.request.urlopen(req, timeout=20).read() or b"{}")
def calls(): return mock("/__control/calls")["calls"]
def reset(): mock("/__control/reset", {})
def tgs(cs, bot=None): return [c for c in cs if c["platform"] == "telegram" and c["path"].endswith("/sendMessage") and (bot is None or f"/bot{bot}:" in c["path"])]
def posts(cs, plat): return [c for c in cs if c["platform"] == plat and c["method"] == "POST"]
def txt(cs): return " || ".join(str(c["body"].get("text", "")) for c in cs)
_uid = [int(time.time()) % 10**7 * 100]
def nu(): _uid[0] += 1; return _uid[0]
def webhook(bot_tenant, user, text, secret_of=None, update_id=None, chat=None):
    bot = BOTS[bot_tenant][0]; sec = BOTS[secret_of or bot_tenant][1]
    upd = {"update_id": update_id or nu(), "message": {"message_id": 1, "from": {"id": user}, "chat": {"id": chat or user, "type": "private"}, "text": text, "date": int(time.time())}}
    req = urllib.request.Request(f"{N8N}/webhook/tg-ingress?bot={bot}", data=json.dumps(upd).encode(), headers={"content-type": "application/json", "x-telegram-bot-api-secret-token": sec}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as r: return r.status, upd["update_id"]
    except urllib.error.HTTPError as e: return e.code, upd["update_id"]
    except Exception: return 0, upd["update_id"]
def wait_tg(n=1, timeout=25):
    end = time.time() + timeout
    while time.time() < end:
        if len(tgs(calls())) >= n: break
        time.sleep(0.4)
    time.sleep(2.5)
    return calls()
def say(t, u, text, **kw):
    reset(); st, uid = webhook(t, u, text, **kw); cs = wait_tg(); return st, cs, txt(tgs(cs))
def admin_put(ref, tenant, kind, value):
    body = json.dumps({"tenant_id": tenant, "kind": kind, "secret_ref": ref, "value": value}).encode()
    ts, nonce = int(time.time()), secrets.token_hex(12)
    sig = hmac.new(os.environ["BROKER_ADMIN_KEY"].encode(), f"{ts}.{nonce}.".encode() + body, hashlib.sha256).hexdigest()
    req = urllib.request.Request(BROKER + "/v1/admin/secrets", data=body, headers={"content-type": "application/json", "x-key-id": "ops-admin", "x-timestamp": str(ts), "x-nonce": nonce, "x-signature": sig}, method="POST")
    return urllib.request.urlopen(req, timeout=20).status
TA, TB = "a0000000-0000-0000-0000-000000000001", "b0000000-0000-0000-0000-000000000001"
RUN = str(int(time.time()))[-6:]
CANARY = "LEAKCANARY" + "987654321:" + "AAF" + "canary0123456789abcdefghijklmnopq"      # يُركَّب وقت التشغيل كي لا يظهر حرفياً بالمستودع (فحص الأسرار)

# ───────────── 1) عزل البوتات والعملاء ─────────────
if phase == "isolation":
    before = q("SELECT count(*) FROM core.processed_updates")[0][0]
    cases = [("A", 2001, "A"), ("A", 2001, "B"), ("B", 1001, "B"), ("B", 1001, "A"), ("A", 3001, "A"), ("B", 999999, "B")]
    for tenant, user, sec in cases:
        st, cs, t = say(tenant, user, "/accounts", secret_of=sec)
        chk("P5-1" + tenant + str(user) + sec, f"user {user} -> bot {tenant} (secret of {sec}): HTTP 200, no reply, no platform call, no data", st == 200 and not cs, (st, cs))
    chk("P5-1z", "no processed_updates rows were created by rejected requests", q("SELECT count(*) FROM core.processed_updates")[0][0] == before)

# ───────────── 2) تكرار/توازٍ لنفس الطلب ─────────────
elif phase == "parallel":
    reset(); uid = nu(); name = f"توازي {RUN}"; codes = []
    def go(): codes.append(webhook("A", 1003, f"/create meta act_A1 10 {name}", update_id=uid)[0])
    ts = [threading.Thread(target=go) for _ in range(10)]
    [t.start() for t in ts]; [t.join() for t in ts]
    cs = wait_tg(); time.sleep(3); cs = calls()
    chk("P5-2a", "10 parallel deliveries of the SAME update: exactly one platform create", len(posts(cs, "meta")) == 1, [c["path"] for c in posts(cs, "meta")])
    chk("P5-2b", "exactly one success reply; deliveries got 200 (done) or 5xx (in flight elsewhere -> Telegram would retry), at least one 200", len(tgs(cs)) == 1 and "✅" in txt(tgs(cs)) and 200 in codes and set(codes) <= {200, 500}, (codes, txt(tgs(cs))))
    chk("P5-2c", "exactly one campaign row + one request row", q("SELECT count(*) FROM core.campaigns WHERE name = %s", name)[0][0] == 1 and q("SELECT count(*) FROM core.campaign_requests WHERE idempotency_key LIKE %s", f"%-{uid}-create")[0][0] == 1)
    reset(); st, _ = webhook("A", 1003, f"/create meta act_A1 10 {name}", update_id=uid); time.sleep(4)
    chk("P5-2d", "a later Telegram retry of the same update is ignored", st == 200 and not calls())

# ───────────── 3) إبطال توكن Meta لعميل A ─────────────
elif phase == "revoke":
    reset()
    mock("/__control/fail", {"platform": "meta", "n": 1, "status": 400, "body": {"error": {"message": "Error validating access token: Session has expired", "type": "OAuthException", "code": 190}}})
    st, uid = webhook("A", 1003, f"/create meta act_A1 10 إبطال {RUN}"); cs = wait_tg(); t = txt(tgs(cs))
    chk("P5-3a", "A's create hits revoked token: one attempt only, honest reply", len(posts(cs, "meta")) == 1 and "❌" in t and "منتهي" in t, (len(posts(cs, "meta")), t))
    chk("P5-3b", "A's Meta connection is marked expired centrally; A's TikTok connection untouched", q("SELECT status FROM core.platform_connections WHERE secret_ref = 'ref-a-meta'")[0][0] == "expired" and q("SELECT status FROM core.platform_connections WHERE secret_ref = 'ref-a-tt'")[0][0] == "active")
    st, cs, t = say("A", 1003, f"/create meta act_A1 10 بعد الإبطال {RUN}")
    chk("P5-3c", "A's next create fails fast: NO platform call", len(posts(cs, "meta")) == 0 and "❌" in t, (cs, t))
    st, cs, t = say("B", 2002, f"/create meta act_B1 10 بي {RUN}")
    chk("P5-3d", "B (other tenant, same platform) creates fine meanwhile", "✅" in t and len(posts(cs, "meta")) == 1, (t, cs))
    st, cs, t = say("A", 1001, "/report")
    chk("P5-3e", "A's TikTok still reports while its Meta is down", "TikTok tt_A1" in t and "3.21" in t, t)
elif phase == "alerts":
    cs = calls(); a = tgs(cs, "111"); b = tgs(cs, "222")
    chk("P5-3f", "A's owner got exactly ONE alert about Meta via A's bot", len(a) == 1 and a[0]["body"]["chat_id"] == 1001 and "Meta" in txt(a) and "متوقف" in txt(a), txt(a))
    chk("P5-3g", "B's owner got no alert", not b, txt(b))
elif phase == "alerts2":
    cs = calls()
    chk("P5-3h", "second alert run sends nothing (no repeated alerts)", not tgs(cs), txt(tgs(cs)))
elif phase == "recover":
    sec = json.load(open("/w/fake_tokens.json"))
    admin_put("ref-a-meta", TA, "meta_user_token", "FAKE-A-META-recovered" + secrets.token_hex(6))
    with db() as c: c.execute("UPDATE core.platform_connections SET status='active', alerted_at=NULL WHERE secret_ref='ref-a-meta'")      # إعادة تفعيل من التشغيل بعد إعادة التفويض
    st, cs, t = say("A", 1003, f"/create meta act_A1 10 تعافي {RUN}")
    chk("P5-3i", "after re-authorization (new secret + reactivation) A creates again", "✅" in t and len(posts(cs, "meta")) == 1 and "FAKE-A-META-recovered" in posts(cs, "meta")[0]["auth"], (t, cs))

# ───────────── 4) أعطال المنصة عبر n8n ─────────────
elif phase == "platform":
    reset(); mock("/__control/fail", {"platform": "meta", "n": 1, "status": 429, "headers": {"Retry-After": "1"}, "body": {"error": {"message": "Application request limit reached", "code": 17}}})
    st, uid = webhook("A", 1001, "/report"); cs = wait_tg(); t = txt(tgs(cs))
    ins = [c for c in cs if c["platform"] == "meta" and "insights" in c["path"]]
    chk("P5-4a", "read gets 429+Retry-After: Broker retried and the report still arrived", len(ins) == 2 and "12.34" in t, (len(ins), t))
    reset(); mock("/__control/fail", {"platform": "meta", "n": 10, "status": 500, "body": {"error": {"message": "server error"}}})
    st, uid = webhook("A", 1001, "/report"); cs = wait_tg(); t = txt(tgs(cs))
    ins = [c for c in cs if c["platform"] == "meta" and "insights" in c["path"]]
    chk("P5-4b", "persistent 500 on a read: bounded retries (3), honest degraded report, TikTok part still delivered", len(ins) == 3 and "⚠️" in t and "TikTok tt_A1" in t and "3.21" in t, (len(ins), t))
    reset(); mock("/__control/fail", {"platform": "meta", "n": 1, "status": 200, "delay": 6, "body": {"id": "late"}})
    n0 = q("SELECT count(*) FROM core.campaigns")[0][0]
    st, uid = webhook("A", 1003, f"/create meta act_A1 10 مهلة {RUN}"); cs = wait_tg(timeout=30); t = txt(tgs(cs)); time.sleep(5); cs = calls()
    chk("P5-4c", "WRITE times out: exactly one attempt (never resent), reply says unconfirmed", len(posts(cs, "meta")) == 1 and "ما أكدت" in txt(tgs(cs)), (len(posts(cs, "meta")), txt(tgs(cs))))
    rq = q("SELECT status FROM core.campaign_requests WHERE idempotency_key LIKE %s", f"%-{uid}-create")
    chk("P5-4d", "timed-out create is needs_manual_check and recorded as NO campaign", rq == [("needs_manual_check",)] and q("SELECT count(*) FROM core.campaigns")[0][0] == n0, (rq,))
    reset(); mock("/__control/fail", {"platform": "meta", "n": 1, "status": 429, "headers": {"Retry-After": "1"}, "body": {"error": {"message": "limit", "code": 17}}})
    st, uid = webhook("A", 1003, f"/create meta act_A1 10 حد {RUN}"); cs = wait_tg(); t = txt(tgs(cs))
    chk("P5-4e", "429 on a WRITE: one attempt, clear 'busy' reply, nothing recorded", len(posts(cs, "meta")) == 1 and "مشغولة" in t, (len(posts(cs, "meta")), t))

# ───────────── 5) إيقاف القاعدة ─────────────
elif phase == "outage_during":
    reset(); UA, UB = 910000001 + int(RUN) % 1000 * 10, 910000002 + int(RUN) % 1000 * 10
    open("/tmp/ids", "w").write(f"{UA},{UB}")
    s1, _ = webhook("A", 1001, "/accounts", update_id=UA); s2, _ = webhook("A", 1003, f"/create meta act_A1 10 انقطاع {RUN}", update_id=UB)
    time.sleep(3); cs = calls()
    print(f"IDS {UA} {UB}")
    chk("P5-5a", "DB down: webhooks answer 5xx (so Telegram retries) and NOTHING is sent/created", s1 >= 500 and s2 >= 500 and not cs, (s1, s2, cs))
elif phase == "outage_after":
    UA, UB = int(sys.argv[2]), int(sys.argv[3])
    reset(); rs = []
    for attempt in range(6):                                  # تيليجرام يعيد المحاولة حتى ينجح (200)
        s1, _ = webhook("A", 1001, "/accounts", update_id=UA)
        if s1 == 200: break
        time.sleep(5)
    for attempt in range(6):
        s2, _ = webhook("A", 1003, f"/create meta act_A1 10 انقطاع {RUN}", update_id=UB)
        if s2 == 200: break
        time.sleep(5)
    cs = wait_tg(2, 40); time.sleep(3); cs = calls()
    chk("P5-5b", "after recovery the retried updates are processed: one reply each, ONE platform create", s1 == 200 and s2 == 200 and len(tgs(cs)) == 2 and len(posts(cs, "meta")) == 1, (s1, s2, len(tgs(cs)), len(posts(cs, "meta"))))
    reset(); a, _ = webhook("A", 1001, "/accounts", update_id=UA); b, _ = webhook("A", 1003, f"/create meta act_A1 10 انقطاع {RUN}", update_id=UB); time.sleep(4)
    chk("P5-5c", "further retries of the same updates change nothing (no duplicate campaign / reply)", a == 200 and b == 200 and not calls())
    chk("P5-5d", "exactly one campaign row for the outage create", q("SELECT count(*) FROM core.campaigns WHERE name = %s", f"انقطاع {RUN}")[0][0] == 1)

# ───────────── 6) تسريب مقصود ─────────────
elif phase == "leaks":
    sec = json.load(open("/w/fake_tokens.json"))
    a_meta = sec["ref-a-meta"]["value"]; a_bot = sec["ref-bot-a"]["value"]
    st, cs, t = say("A", 1001, "هذا التوكن تبعي " + CANARY + " " + a_meta)
    chk("P5-6a", "user pasting tokens in chat: bot answers generically, never echoes them", a_meta not in t and "LEAKCANARY" not in t, t)
    reset(); mock("/__control/fail", {"platform": "meta", "n": 1, "status": 400, "body": {"error": {"message": f"Invalid OAuth access token {a_meta} for bot {a_bot} (EAAB{'x' * 30})", "type": "OAuthException", "code": 100}}})
    st, uid = webhook("A", 1003, f"/create meta act_A1 10 تسريب {RUN}"); cs = wait_tg(); t = txt(tgs(cs))
    chk("P5-6b", "platform error echoing the tenant's own tokens: reply is generic and contains none of them", a_meta not in t and a_bot not in t and "EAAB" not in t and "❌" in t, t)
    rows = q("SELECT count(*) FROM core.error_log WHERE message LIKE %s OR message LIKE %s OR message LIKE %s", f"%{a_meta}%", "%LEAKCANARY%", "%EAABxxx%")[0][0]
    chk("P5-6c", "none of them in the central error_log", rows == 0, rows)
print(f"P5[{phase}]: {sum(res)}/{len(res)} passed"); sys.exit(0 if all(res) else 1)
