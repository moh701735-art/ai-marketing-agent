#!/usr/bin/env python3
"""ربط وكالة تيك توك إضافية (توكن جديد) بعميل موجود، مع عدة حسابات إعلانية دفعة وحدة، وجلب أسمائها وعملتها من تيك توك تلقائياً.
الأسرار (App Secret + auth_code) تُكتب مخفية ولا تُطبع. التوكن يُخزَّن بالخزنة فقط. يشتغل من /opt/central:  python3 ops/link-tiktok-agency.py"""
import getpass, importlib.util, json, os, re, secrets, sys, urllib.parse, urllib.request
from pathlib import Path

for k, v in {"PG_CONTAINER": "central-stg-pg", "BROKER_NETWORK": "central-stg_backend", "BROKER_IMAGE": "central-broker:prod", "ENV_FILE": "deploy/.env"}.items():
    os.environ.setdefault(k, v)
spec = importlib.util.spec_from_file_location("at", Path(__file__).with_name("add-tenant.py"))
at = importlib.util.module_from_spec(spec); spec.loader.exec_module(at)

API = "https://business-api.tiktok.com/open_api/v1.3"
DEFAULT_APP_ID = "7688235455380193301"


def call(url, body=None, token=None):
    h = {"Content-Type": "application/json"}
    if token:
        h["Access-Token"] = token
    req = urllib.request.Request(url, data=json.dumps(body).encode() if body is not None else None, headers=h)
    return json.load(urllib.request.urlopen(req, timeout=30))


def account_info(token, ids):
    """-> {id: (name, currency)}"""
    out = {}
    for i in range(0, len(ids), 50):
        part = ids[i:i + 50]
        q = urllib.parse.urlencode({"advertiser_ids": json.dumps(part), "fields": json.dumps(["advertiser_id", "name", "currency"])})
        r = call(f"{API}/advertiser/info/?{q}", token=token)
        if r.get("code") == 0:
            for a in (r.get("data") or {}).get("list") or []:
                out[str(a.get("advertiser_id"))] = (str(a.get("name") or "")[:80], str(a.get("currency") or "").upper()[:3])
    return out


def main(inp=input, hidden=getpass.getpass):
    db = os.environ.get("TENANT_DB", "central")
    slug = (inp("Tenant slug [mohm]: ").strip() or "mohm")
    app_id = inp("TikTok App ID (أرقام فقط، اضغط Enter لاستعمال %s): " % DEFAULT_APP_ID).strip() or DEFAULT_APP_ID
    if not re.fullmatch(r"[0-9]{15,25}", app_id):
        at.die("App ID لازم يكون أرقام فقط (مثل %s). اللي كتبته يشبه سراً (App Secret أو auth_code)، لا تكتبه هنا." % DEFAULT_APP_ID)
    secret = (os.environ.get("LT_SECRET") or hidden("App Secret (مخفي، 40 حرف): ")).strip()
    code = (os.environ.get("LT_CODE") or hidden("auth_code (مخفي، الجديد): ")).strip().split("&")[0]
    if not re.fullmatch(r"[0-9a-fA-F]{20,64}", secret) or not re.fullmatch(r"[0-9a-zA-Z_\-]{16,128}", code):
        at.die("App Secret أو auth_code بصيغة غير متوقعة (لازم حروف وأرقام بدون مسافات). تأكد إنك لصقتهم صح.")
    tid = at.psql(db, "SELECT tenant_id FROM core.tenants WHERE slug = :'slug'", {"slug": slug}, tx=False)
    if not tid:
        at.die("tenant not found")
    r = call(f"{API}/oauth2/access_token/", {"app_id": app_id, "secret": secret, "auth_code": code})
    if r.get("code") != 0:
        at.die(f"TikTok error {r.get('code')}: {r.get('message')}")
    d = r["data"]
    token = d["access_token"]
    granted = [str(x) for x in d.get("advertiser_ids", []) if re.fullmatch(r"[0-9]{5,24}", str(x))]
    if not granted:
        at.die("هذا التفويض ما فيه حسابات إعلانية")
    info = account_info(token, granted)
    taken = set(at.psql(db, "SELECT external_id FROM core.ad_accounts WHERE platform = 'tiktok' AND unlinked_at IS NULL", {}, tx=False).split())
    print(f"\nالحسابات المسموحة بهذا التفويض ({len(granted)}):")
    for i, a in enumerate(granted, 1):
        nm, cur = info.get(a, ("", ""))
        print(f"  {i:>2}) {a}  {nm or '(بدون اسم)'}  {cur or '?'}" + ("   [مربوط مسبقاً]" if a in taken else ""))
    pick = inp("\nاكتب all لربط كلها (عدا المربوط)، أو أرقام السطور مفصولة بفاصلة (مثال 1,3): ").strip().lower()
    if pick in ("all", "كل"):
        chosen = [a for a in granted if a not in taken]
    else:
        idx = [int(x) for x in re.findall(r"\d+", pick)]
        chosen = [granted[i - 1] for i in idx if 1 <= i <= len(granted) and granted[i - 1] not in taken]
    if not chosen:
        at.die("ما اخترت حسابات جديدة")
    do_link(db, slug, tid, token, chosen, info)
    print("\nالخطوة التالية: bash deploy/run-readiness.sh 2>&1 | tail -3   (المتوقع: {} READY)".format(slug))


def do_link(db, slug, tid, token, chosen, info):
    """يخزّن التوكن بالخزنة ويربط الحسابات المختارة بالـtenant (تراجع كامل عند فشل القاعدة). تُستعمل من سطر الأوامر ومن صفحة الربط."""
    ref = f"ref-{slug}-tt-{secrets.token_hex(4)}"
    at.vault([{"tenant_id": tid, "kind": "tiktok_token", "secret_ref": ref, "value": token}])
    print("vault: token stored (not shown)")
    vars_ = {"tid": tid, "user": f"tt_agency_{secrets.token_hex(4)}", "ref": ref}
    sql = ["BEGIN;",
           "INSERT INTO core.platform_connections (tenant_id, platform, auth_mode, external_user_id, secret_ref) VALUES (:'tid', 'tiktok', 'tiktok_oauth', :'user', :'ref');"]
    for i, a in enumerate(chosen):
        nm, cur = info.get(a, ("", ""))
        vars_[f"a{i}"], vars_[f"n{i}"], vars_[f"c{i}"] = a, nm or f"TikTok {a}", cur if re.fullmatch(r"[A-Z]{3}", cur) else ""
        sql.append(f"INSERT INTO core.ad_accounts (tenant_id, platform, external_id, connection_id, name, currency) "
                   f"SELECT :'tid', 'tiktok', :'a{i}', connection_id, :'n{i}', nullif(:'c{i}','')::char(3) FROM core.platform_connections WHERE secret_ref = :'ref' "
                   f"ON CONFLICT (tenant_id, platform, external_id) DO UPDATE SET connection_id = EXCLUDED.connection_id, name = EXCLUDED.name, currency = EXCLUDED.currency, unlinked_at = NULL, enabled = true;")
    sql += ["UPDATE core.tenants SET features = features || '{\"tiktok\": true}'::jsonb WHERE tenant_id = :'tid';", "COMMIT;"]
    try:
        at.psql(db, "\n".join(sql), vars_, tx=False)
    except RuntimeError as e:
        try:
            at.vault([{"tenant_id": tid, "secret_ref": ref}], "revoke")
        except RuntimeError as e2:
            print("warning: revoke failed:", e2)
        at.die(f"DB insert failed, token revoked: {e}")
    print(f"\nتم: ربطت {len(chosen)} حساب بالـtenant {slug}:")
    for a in chosen:
        print("  -", a, info.get(a, ("", ""))[0])


if __name__ == "__main__":
    main()
