#!/usr/bin/env bash
# يزرع أسراراً وهمية (توكنات بوت/ميتا/تيك توك) في الـ vault عبر Broker. لا قيمة حقيقية. الناتج في .secrets/p4_fake_tokens.json (غير مرفوع).
set -euo pipefail
cd "$(dirname "$0")/.."
KEY=$(grep ^BROKER_ADMIN_KEY .env | cut -d= -f2)
mkdir -p .secrets
docker run --rm --network central_internal_only -e BROKER_ADMIN_KEY="$KEY" -v "$PWD/ops/p4_bootstrap.py:/w/b.py:ro" -v "$PWD/broker/hmac_auth.py:/w/hmac_auth.py:ro" -w /w --entrypoint python central-broker:dev b.py > .secrets/p4_fake_tokens.json
echo "seeded $(python3 -c 'import json;print(len(json.load(open(".secrets/p4_fake_tokens.json"))))') fake secrets"
