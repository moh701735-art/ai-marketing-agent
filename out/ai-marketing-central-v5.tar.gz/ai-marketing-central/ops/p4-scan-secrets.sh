#!/usr/bin/env bash
# يبحث عن أي قيمة سرّية وهمية (من .secrets/p4_fake_tokens.json) في: بيانات n8n (SQLite) + سجلات الحاويات + dump القاعدة المركزية + ملفات المستودع.
# نتيجة نظيفة = لا سر بأي مكان غير الـ vault المشفر. (يُكمّل R14 الذي يغطي error_log فقط.)
set -uo pipefail
cd "$(dirname "$0")/.."
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
python3 -c "import json;[print(v['value']) for v in json.load(open('.secrets/p4_fake_tokens.json')).values()]" > "$T/vals"
[ -n "${EXTRA_VALUES:-}" ] && echo "$EXTRA_VALUES" | tr ',' '\n' >> "$T/vals"        # قيم إضافية (مثل كاناري ألصقه مستخدم)
docker cp central-n8n:/home/node/.n8n "$T/n8n_dir" >/dev/null 2>&1                    # كامل مجلد n8n: SQLite + WAL + سجلات الأحداث
# n8n: بحث «منطقي» داخل SQLite (كل أعمدة النص) لأن الصفحات المحذوفة/WAL تبقي بايتات قديمة لا تمثل بيانات حيّة؛ ملفات السجل النصية تُفحص خاماً.
python3 - "$T" <<'PY' > "$T/n8n_logical.txt"
import sqlite3, sys, pathlib
T = pathlib.Path(sys.argv[1]); vals = [v for v in (T / "vals").read_text(encoding="utf-8").splitlines() if v]
c = sqlite3.connect(str(T / "n8n_dir" / "database.sqlite"))
hits = 0
for (t,) in c.execute("select name from sqlite_master where type='table'").fetchall():
    cols = [r[1] for r in c.execute(f'pragma table_info("{t}")')]
    for col in cols:
        for v in vals:
            try: n = c.execute(f'select count(*) from "{t}" where cast("{col}" as text) like ? escape "\\"', ("%" + v.replace("%", "\\%").replace("_", "\\_") + "%",)).fetchone()[0]
            except Exception: continue
            if n: hits += n; print(f"HIT {t}.{col}: {n}", file=sys.stderr)
print(f"{hits}")
PY
cat "$T"/n8n_dir/*.log > "$T/n8n_eventlogs.txt" 2>/dev/null
for c in central-n8n central-broker central-mock central-pg; do docker logs "$c" > "$T/log-$c.txt" 2>&1; done
docker exec central-pg pg_dump -U postgres -d p4_central > "$T/central.sql" 2>/dev/null
docker exec central-pg pg_dump -U postgres -d p4_vault --exclude-table-data='vault.secrets' > "$T/vault_nodata.sql" 2>/dev/null
git ls-files -z | xargs -0 cat > "$T/repo.txt" 2>/dev/null
bad=0; n=$(sort -u "$T/vals" | wc -l)
for f in "$T"/n8n_eventlogs.txt "$T"/log-*.txt "$T"/central.sql "$T"/vault_nodata.sql "$T"/repo.txt; do
  [ -f "$f" ] || continue
  hits=$(grep -a -c -F -f "$T/vals" "$f" 2>/dev/null || true); hits=${hits:-0}
  printf '%-26s %s lines with a secret value\n' "$(basename "$f")" "$hits"; [ "$hits" != "0" ] && bad=1
done
lh=$(cat "$T/n8n_logical.txt" 2>/dev/null || echo 0); printf '%-26s %s rows with a secret value (live SQLite data, logical search)\n' "n8n database.sqlite" "$lh"; [ "$lh" != "0" ] && bad=1
echo "scanned for $n distinct fake secret values"
[ $bad = 0 ] && echo "SCAN: clean" || { echo "SCAN: FOUND SECRETS"; exit 1; }
