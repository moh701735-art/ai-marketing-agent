"""عميل اختبار الدخان (يعمل داخل حاوية على الشبكة المعزولة). يخاطب الخدمة الحقيقية عبر HTTP ويوقّع الطلبات كما سيفعل n8n."""
import base64, hashlib, json, os, secrets, sys, time

import httpx, psycopg
import hmac_auth

S = json.load(open("/s.json"))
KEY = {k: base64.b64decode(v["key"]) for k, v in S["hmac_keys"].items()}
BROKER, MOCK = "http://central-broker:8080", "http://central-mock:8080"
TOKEN = "SMOKE-TOKEN-" + secrets.token_hex(10)
fails = []


def post(path, payload, key_id="n8n-runtime", signed=True):
    body = json.dumps(payload).encode()
    h = {"content-type": "application/json"}
    if signed:
        ts, n = int(time.time()), secrets.token_hex(12)
        h.update({"x-key-id": key_id, "x-timestamp": str(ts), "x-nonce": n, "x-signature": hmac_auth.sign(KEY[key_id], body, ts, n)})
    return httpx.post(BROKER + path, content=body, headers=h, timeout=15)


def ctx(bot, secret, user):
    with psycopg.connect(f"postgresql://postgres:{os.environ['DBPW']}@central-pg:5432/central_dev", autocommit=True) as c:
        c.execute("SET ROLE app_runtime")
        return c.execute("SELECT ctx FROM api.resolve_context(%s, decode(%s,'hex'), %s)", (bot, hashlib.sha256(secret.encode()).hexdigest(), user)).fetchone()[0]


def check(name, cond, extra=""):
    print(("PASS  " if cond else "FAIL  ") + name + (f"  [{extra}]" if not cond else ""))
    if not cond:
        fails.append(name)


r = None
for _ in range(20):
    try:
        r = httpx.get(BROKER + "/healthz", timeout=3); break
    except Exception:
        time.sleep(1)
if r is None:
    print("FAIL  service unreachable"); sys.exit(1)
check("GET /healthz", r.status_code == 200 and r.json() == {"ok": True})
check("unsigned /v1/call -> 401", post("/v1/call", {"ctx": "x", "platform": "meta", "op": "meta.me"}, signed=False).status_code == 401)
r = post("/v1/admin/secrets", {"tenant_id": "a0000000-0000-0000-0000-000000000001", "kind": "meta_user_token", "secret_ref": "ref-a-meta", "value": TOKEN}, key_id="ops-admin")
check("admin stores secret (new version, value not echoed)", r.status_code == 200 and r.json().get("version", 0) >= 2 and TOKEN not in r.text, r.text)
ca = ctx("botAAAAAAAAAAAAAAAAAAAAAAAA", "secret-a", 1001); cb = ctx("botBBBBBBBBBBBBBBBBBBBBBBBB", "secret-b", 2001)
r = post("/v1/call", {"ctx": ca, "platform": "meta", "op": "meta.read_account", "ad_account": "act_A1", "params": {"fields": "id,name"}})
check("signed read via the real service -> ok", r.status_code == 200 and r.json().get("ok") is True, r.text)
check("token not in response", TOKEN not in r.text)
last = httpx.get(MOCK + "/last").json()
check("platform received Bearer <stored token> on /act_A1", last.get("headers", {}).get("authorization") == "Bearer " + TOKEN and "/act_A1" in last.get("path", ""), str(last)[:200])
check("token not in URL", TOKEN not in last.get("path", ""))
r = post("/v1/call", {"ctx": cb, "platform": "meta", "op": "meta.read_account", "ad_account": "act_A1"})
check("tenant B on tenant A account -> 403", r.status_code == 403, r.text)
r = post("/v1/call", {"ctx": ca, "platform": "meta", "op": "meta.create_campaign", "ad_account": "act_A1", "params": {"name": "x", "objective": "OUTCOME_TRAFFIC"}})
check("write without idempotency_key -> 400", r.status_code == 400, r.text)
sys.exit(1 if fails else 0)
