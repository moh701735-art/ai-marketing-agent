#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
./ops/init-env.sh >/dev/null
docker compose --env-file .env -f ops/docker-compose.yml up -d --wait postgres
echo "postgres جاهز: $(docker exec central-pg psql -U postgres -Atc 'select version()' | cut -c1-40)"
