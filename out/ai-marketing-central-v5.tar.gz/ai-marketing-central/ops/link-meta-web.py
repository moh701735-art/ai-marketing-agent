#!/usr/bin/env python3
"""صفحة ربط Meta (فيسبوك) مؤقتة، بنفس آلية صفحة تيك توك (HTTPS، رابط برمز عشوائي، تغلق نفسها، الأسرار بالذاكرة فقط).
تكتب توكن الـSystem User ورقم الحساب الإعلاني، فتفحص الصفحة التوكن مع Meta (الهوية، الصلاحيات، الحساب، الصفحات، فحص إنشاء حملة)
وترفض الربط إذا فحص جاهزية سيفشل (حتى لا يسكت البوت). التشغيل (من /opt/central):  python3 ops/link-meta-web.py"""
import html, importlib.util, json, os, re, secrets, sys, time, urllib.error, urllib.parse, urllib.request
from pathlib import Path

spec = importlib.util.spec_from_file_location("lw", Path(__file__).resolve().parent / "link-web.py")
lw = importlib.util.module_from_spec(spec); spec.loader.exec_module(lw)
at, page = lw.at, lw.page

GRAPH = os.environ.get("LM_GRAPH", "https://graph.facebook.com/v21.0")
NEED = ("ads_management", "ads_read")


def graph(path, token, method="GET", body=None):
    req = urllib.request.Request(GRAPH + path, data=json.dumps(body).encode() if body is not None else None, method=method,
                                 headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"})
    try:
        return 200, json.load(urllib.request.urlopen(req, timeout=30))
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, {"error": {"message": "HTTP %d" % e.code}}
    except Exception as e:
        return 0, {"error": {"message": type(e).__name__}}


def emsg(r):
    return str(((r or {}).get("error") or {}).get("message") or "خطأ غير معروف")[:160]


def form_page(err=""):
    e = '<div class="e">%s</div>' % html.escape(err) if err else ""
    return page('<h1>ربط فيسبوك (Meta) بالبوت</h1>%s'
                '<form method="post" action="list" autocomplete="off">'
                '<label>1) توكن الـSystem User (يبدأ عادة بـ EA)</label><input type="password" name="token" autocomplete="off">'
                '<label>2) رقم الحساب الإعلاني (أرقام فقط، أو act_...)</label><input type="text" name="acct" autocomplete="off">'
                '<label>3) اسم العميل (tenant)</label><input type="text" name="slug" value="mohm">'
                '<button type="submit">فحص التوكن والحساب</button></form>'
                '<div class="m">ما يتخزن شي إلا بعد ما تضغط "ربط". التوكن يروح للخزنة فقط.</div>' % e)


def do_list(form):
    token = form.get("token", "").strip()
    acct = re.sub(r"^act_", "", form.get("acct", "").strip())
    slug = form.get("slug", "mohm").strip() or "mohm"
    if not re.fullmatch(r"[A-Za-z0-9_\-]{30,600}", token):
        return form_page("التوكن بصيغة غير متوقعة (حروف وأرقام بدون مسافات، طويل). انسخه كامل من Business Settings.")
    if not re.fullmatch(r"[0-9]{5,25}", acct):
        return form_page("رقم الحساب الإعلاني لازم أرقام فقط (مثل 1143673748321865).")
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,48}", slug):
        return form_page("اسم العميل غير صالح.")
    tid = at.psql(lw.DB, "SELECT tenant_id FROM core.tenants WHERE slug = :'slug'", {"slug": slug}, tx=False)
    if not tid:
        return form_page("ما لقيت عميلاً بهذا الاسم.")
    st, me = graph("/me?fields=id,name", token)
    if st != 200 or not me.get("id"):
        return form_page("Meta رفضت التوكن (R06): %s" % emsg(me))
    st, pr = graph("/me/permissions", token)
    granted = {x.get("permission") for x in (pr.get("data") or []) if x.get("status") == "granted"} if st == 200 else set()
    missing = [p for p in NEED if p not in granted]
    if missing:
        return form_page("التوكن ناقصه صلاحيات (R07): %s. ولّد توكن جديد بهذي الصلاحيات: ads_management, ads_read, pages_show_list, business_management." % ", ".join(missing))
    st, ac = graph("/act_%s?fields=id,name,currency,account_status" % acct, token)
    if st != 200 or not ac.get("id"):
        return form_page("ما كدرت أقرأ الحساب الإعلاني (R08): %s. تأكد إنك ضفت الحساب للـSystem User بصلاحية Manage." % emsg(ac))
    st, pg = graph("/me/accounts?fields=id,name&limit=25", token)
    pages = (pg.get("data") or []) if st == 200 else []
    if not pages:
        return form_page("ما لقيت أي صفحة فيسبوك لهذا التوكن (R09): %s. ضف الصفحة للـSystem User بصلاحية Manage page وفعّل pages_show_list، وولّد التوكن من جديد." % (emsg(pg) if st != 200 else "القائمة فاضية"))
    st, vc = graph("/act_%s/campaigns" % acct, token, "POST", {"name": "readiness-probe", "objective": "OUTCOME_TRAFFIC", "status": "PAUSED", "special_ad_categories": [], "execution_options": ["validate_only"]})
    if st != 200:
        return form_page("فحص إنشاء الحملة فشل (R11): %s. هذا يعني إن البوت ما راح يقدر ينشئ حملات Meta بهذا التوكن/الحساب." % emsg(vc))
    sid = secrets.token_hex(16)
    with lw.LOCK:
        lw.purge_sessions()
        lw.SESSIONS[sid] = {"token": token, "me": me, "acct": acct, "ac": ac, "pages": pages, "slug": slug, "tid": tid, "ts": time.time()}
    opts = "".join('<tr><td><input type="radio" name="pg" value="%s" %s></td><td>%s</td><td class="t">%s</td></tr>' % (html.escape(p["id"]), "checked" if i == 0 else "", html.escape(p.get("name", "-")), html.escape(p["id"])) for i, p in enumerate(pages))
    return page('<h1>الفحص نجح</h1><div class="ok">المستخدم: %s<br>الحساب: %s (%s) | العملة: %s<br>الصلاحيات: ads_management و ads_read موجودة.<br>فحص إنشاء حملة: نجح.</div>'
                '<form method="post" action="link"><input type="hidden" name="sid" value="%s"><label>اختار الصفحة اللي تنربط:</label><table>%s</table>'
                '<button type="submit">ربط</button></form>' % (html.escape(str(me.get("name", ""))), html.escape(str(ac.get("name", "-"))), acct, html.escape(str(ac.get("currency", "?"))), sid, opts))


def do_link(multi):
    sid = (multi.get("sid") or [""])[0]
    with lw.LOCK:
        lw.purge_sessions()
        s = lw.SESSIONS.pop(sid, None)
    if not s:
        return form_page("انتهت الجلسة (10 دقايق). ابدأ من جديد.")
    pid = (multi.get("pg") or [""])[0]
    pg = next((p for p in s["pages"] if p["id"] == pid), None)
    if not pg:
        return form_page("اختار صفحة.")
    ref = "ref-%s-meta-%s" % (s["slug"], secrets.token_hex(4))
    try:
        at.vault([{"tenant_id": s["tid"], "kind": "meta_user_token", "secret_ref": ref, "value": s["token"]}])
    except RuntimeError:
        return form_page("فشل حفظ التوكن بالخزنة. التفاصيل بالطرفية.")
    cur = str(s["ac"].get("currency") or "").upper()
    sql = """BEGIN;
INSERT INTO core.platform_connections (tenant_id, platform, auth_mode, external_user_id, secret_ref) VALUES (:'tid', 'meta', 'system_user', :'user', :'ref');
INSERT INTO core.ad_accounts (tenant_id, platform, external_id, connection_id, name, currency)
  SELECT :'tid', 'meta', :'acct', connection_id, :'aname', nullif(:'cur','')::char(3) FROM core.platform_connections WHERE secret_ref = :'ref'
  ON CONFLICT (tenant_id, platform, external_id) DO UPDATE SET connection_id = EXCLUDED.connection_id, name = EXCLUDED.name, currency = EXCLUDED.currency, unlinked_at = NULL, enabled = true;
INSERT INTO core.pages (tenant_id, page_id, name, connection_id)
  SELECT :'tid', :'pid', :'pname', connection_id FROM core.platform_connections WHERE secret_ref = :'ref'
  ON CONFLICT (tenant_id, page_id) DO UPDATE SET connection_id = EXCLUDED.connection_id, name = EXCLUDED.name, unlinked_at = NULL;
UPDATE core.tenants SET features = features || '{"meta": true}'::jsonb WHERE tenant_id = :'tid';
COMMIT;"""
    vars_ = {"tid": s["tid"], "user": "fb_" + str(s["me"]["id"])[:60], "ref": ref, "acct": "act_" + s["acct"], "aname": str(s["ac"].get("name") or ("Meta " + s["acct"]))[:80],
             "cur": cur if re.fullmatch(r"[A-Z]{3}", cur) else "", "pid": pg["id"], "pname": str(pg.get("name") or "")[:80]}
    try:
        at.psql(lw.DB, sql, vars_, tx=False)
    except RuntimeError as e:
        try:
            at.vault([{"tenant_id": s["tid"], "secret_ref": ref}], "revoke")
        except RuntimeError:
            pass
        print("DB insert failed, token revoked:", e)
        return form_page("فشل الربط بالقاعدة وانلغى (التوكن انبطل). غالباً الحساب أو الصفحة مربوطة مسبقاً بعميل ثاني.")
    lw.STATE["done"] = True
    print("تم: ربطت Meta act_%s وصفحة %s بالـtenant %s" % (s["acct"], pg["id"], s["slug"]))
    return page('<h1>تم الربط</h1><div class="ok">ربطت الحساب act_%s والصفحة %s بالـtenant %s.</div>'
                '<div class="m">هسه ارجع للطرفية وشغّل: bash deploy/run-readiness.sh 2>&1 | tail -3 (المتوقع READY). الصفحة تغلق نفسها.</div>' % (html.escape(s["acct"]), html.escape(pg["id"]), html.escape(s["slug"])))


lw.form_page, lw.do_list, lw.do_link = form_page, do_list, do_link
if __name__ == "__main__":
    lw.main()
