#!/usr/bin/env python3
"""يتحقق من نتيجة تشغيل Workflow التقرير المجدول (بعد `n8n execute`): نداءات المنصات الوهمية فقط. يعمل داخل الشبكة المعزولة."""
import json, sys, urllib.request
MOCK = "http://platform-mock:8080"
if len(sys.argv) > 1 and sys.argv[1] == "reset":
    urllib.request.urlopen(urllib.request.Request(MOCK + "/__control/reset", data=b"{}", method="POST")); sys.exit(0)
cs = json.loads(urllib.request.urlopen(MOCK + "/__control/calls").read())["calls"]
tg = [c for c in cs if c["platform"] == "telegram"]
res = []
def chk(i, d, ok): res.append(ok); print(("PASS " if ok else "FAIL ") + i + " " + d, flush=True)
a = [c for c in tg if "/bot111:" in c["path"]]; b = [c for c in tg if "/bot222:" in c["path"]]
chk("J01", "scheduled report: A owner (1001) gets A's numbers only via bot 111", len(a) == 1 and a[0]["body"]["chat_id"] == 1001 and "act_A1" in a[0]["body"]["text"] and "_B1" not in a[0]["body"]["text"])
chk("J02", "scheduled report: B owner (2001) gets B's numbers only via bot 222", len(b) == 1 and b[0]["body"]["chat_id"] == 2001 and "act_B1" in b[0]["body"]["text"] and "_A1" not in b[0]["body"]["text"])
chk("J03", "exactly 2 Telegram messages (tenant D/C skipped without breaking the run)", len(tg) == 2)
chk("J04", "platform reads used each tenant's own fake token only", all(("FAKE-B" not in c["auth"] + c["access_token"]) for c in cs if "act_A1" in c["path"]) and all(("FAKE-A" not in c["auth"] + c["access_token"]) for c in cs if "act_B1" in c["path"]))
print(f"JOB: {sum(res)}/{len(res)} passed"); sys.exit(0 if all(res) else 1)
