#!/usr/bin/env python3
"""اختبار الاشتراكات عبر n8n: فعّال -> فترة سماح (قراءة فقط) -> منتهٍ (رسالة تجديد فقط، والمهمة المجدولة تتجاهله) -> تجديد + حد يومي.
أوضاع: chat | job | renew. العميل B هو المتأثر؛ A يجب ألا يتأثر. يعمل داخل الشبكة المعزولة (القاعدة بحساب postgres لتبديل الاشتراك فقط)."""
import json, os, sys, time, urllib.request
import psycopg
N8N, MOCK = "http://n8n:5678", "http://platform-mock:8080"
db = psycopg.connect(f"postgresql://postgres:{os.environ['PGPASSWORD']}@postgres:5432/p4_central", autocommit=True)
TB = "b0000000-0000-0000-0000-000000000001"
mode = sys.argv[1]
res = []
def chk(i, d, c, det=""): res.append(bool(c)); print(("PASS " if c else "FAIL ") + i + " " + d + ("" if c else " -> " + str(det)[:350]), flush=True)
def sub(status, days, limits="{}", grace=3): db.execute("SELECT api_admin.set_subscription(%s::uuid, 'standard', %s, now() + (%s || ' days')::interval, %s, %s::jsonb)", (TB, status, str(days), grace, limits))
def mock(path, body=None):
    req = urllib.request.Request(MOCK + path, data=None if body is None else b"{}", method="POST" if body is not None else "GET")
    return json.loads(urllib.request.urlopen(req).read() or b"{}")
def calls(): return mock("/__control/calls")["calls"]
_u = [int(time.time()) % 10**8 * 10 + 5]
def say(tenant, user, text, wait=3):
    bot, sec = ("botAAAAAAAAAAAAAAAAAAAAAAAA", "secret-a") if tenant == "A" else ("botBBBBBBBBBBBBBBBBBBBBBBBB", "secret-b")
    mock("/__control/reset", {}); _u[0] += 1
    upd = {"update_id": _u[0], "message": {"message_id": 1, "from": {"id": user}, "chat": {"id": user, "type": "private"}, "text": text, "date": int(time.time())}}
    urllib.request.urlopen(urllib.request.Request(f"{N8N}/webhook/tg-ingress?bot={bot}", data=json.dumps(upd).encode(), headers={"content-type": "application/json", "x-telegram-bot-api-secret-token": sec}, method="POST"), timeout=20).read()
    for _ in range(40):
        if [c for c in calls() if c["platform"] == "telegram"]: break
        time.sleep(0.5)
    time.sleep(wait); cs = calls()
    return cs, " || ".join(str(c["body"].get("text", "")) for c in cs if c["platform"] == "telegram")
def no_platform(cs): return not [c for c in cs if c["platform"] in ("meta", "tiktok")]

if mode == "chat":
    sub("active", 30)
    cs, t = say("B", 2001, "/accounts"); chk("S01", "B active: /accounts works", "act_B1" in t, t)
    sub("past_due", -1)
    cs, t = say("B", 2001, "/accounts"); chk("S02", "B in grace: reads still work", "act_B1" in t, t)
    cs, t = say("B", 2002, "/create meta act_B1 5 سماح"); chk("S03", "B in grace: create refused with a clear renewal message, no platform write", "القراءة فقط" in t and not [c for c in cs if c["method"] == "POST" and c["platform"] in ("meta", "tiktok")], (t, cs))
    sub("past_due", -10)
    cs, t = say("B", 2001, "/accounts"); chk("S04", "B expired: only a renewal notice (no data, no platform call)", "منتهي" in t and "act_B1" not in t and no_platform(cs), t)
    cs, t = say("B", 2001, "/help"); chk("S05", "B expired: even /help gives the renewal notice", "منتهي" in t, t)
    cs, t = say("B", 2002, "/create meta act_B1 5 منتهي"); chk("S06", "B expired: create impossible", "منتهي" in t and no_platform(cs), (t, cs))
    cs, t = say("A", 1001, "/accounts"); chk("S07", "A unaffected while B is expired", "act_A1" in t and "_B1" not in t, t)
elif mode == "job":
    cs = calls(); tg = [c for c in cs if c["platform"] == "telegram" and c["path"].endswith("/sendMessage")]
    chk("S08", "scheduled report skips expired B but still serves A", len([c for c in tg if "/bot111:" in c["path"]]) == 1 and not [c for c in tg if "/bot222:" in c["path"]], [c["path"][:30] for c in tg])
elif mode == "renew":
    n = db.execute("SELECT count(*) FROM core.campaign_requests WHERE tenant_id = %s AND created_at >= date_trunc('day', now())", (TB,)).fetchone()[0]
    sub("active", 30, json.dumps({"max_creates_per_day": n + 1}))
    cs, t = say("B", 2001, "/accounts"); chk("S09", "B renewed: service is back", "act_B1" in t, t)
    cs, t = say("B", 2002, "/create meta act_B1 5 بعد التجديد"); chk("S10", "B renewed: create works within plan limit", "✅" in t, t)
    cs, t = say("B", 2002, "/create meta act_B1 5 فوق الحد"); chk("S11", "B over its plan's daily create limit: refused before any platform call", "الحد اليومي" in t and no_platform(cs), (t, cs))
    sub("active", 30)
print(f"SUBS[{mode}]: {sum(res)}/{len(res)} passed"); sys.exit(0 if all(res) else 1)
