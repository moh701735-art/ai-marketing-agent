#!/usr/bin/env bash
# نسخة احتياطية مشفّرة (GPG AES256) لقاعدتي central_dev و vault_dev + الأدوار + بصمات البيانات.
# الاستعمال: ops/backup.sh [مجلد_الهدف]   (افتراضي ops/backups/<UTC>). عبارة التشفير: .secrets/backup.pass
set -euo pipefail
cd "$(dirname "$0")/.."
D="${1:-ops/backups/$(date -u +%Y%m%dT%H%M%SZ)}"; mkdir -p "$D"; chmod 700 "$D"
ENC() { gpg --batch --yes --pinentry-mode loopback --passphrase-file .secrets/backup.pass --symmetric --cipher-algo AES256 -o "$1"; }
PG="docker exec -i central-pg"
$PG pg_dumpall -U postgres --globals-only --no-role-passwords | grep -vE '^(CREATE|ALTER) ROLE postgres' | ENC "$D/globals.sql.gpg"
for db in central_dev vault_dev; do
  $PG pg_dump -U postgres -Fc --create "$db" | ENC "$D/$db.dump.gpg"
  $PG psql -U postgres -d "$db" -Atq -F'|' -f /work/ops/seed/checksums.sql > "$D/$db.checksums.txt"
done
( cd "$D" && sha256sum *.gpg > SHA256SUMS )
echo "backup: $D ($(du -sh "$D" | cut -f1))"
