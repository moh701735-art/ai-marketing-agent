#!/usr/bin/env python3
"""يعمل داخل حاوية على شبكة Broker: يقرأ JSON من stdin {action: set-webhook|webhook-info|delete-webhook, tenant_id, secret_ref, [url, secret_token]}
ويرسله موقّعاً بمفتاح admin إلى /v1/admin/telegram/<action>. يطبع الرد (منقّى من الأسرار بالـ Broker). خروج 1 إن لم ينجح. المفتاح من BROKER_ADMIN_KEY."""
import json, os, secrets, sys, time
import httpx
import hmac_auth

d = json.load(sys.stdin)
action = d.pop("action")
body = json.dumps(d).encode()
ts, nonce = int(time.time()), secrets.token_hex(12)
r = httpx.post(f"http://broker:8080/v1/admin/telegram/{action}", content=body, timeout=40, headers={
    "content-type": "application/json", "x-key-id": "ops-admin", "x-timestamp": str(ts), "x-nonce": nonce,
    "x-signature": hmac_auth.sign(os.environ["BROKER_ADMIN_KEY"].encode(), body, ts, nonce)})
try:
    j = r.json()
except Exception:
    j = {"ok": False, "error": {"message": f"http {r.status_code}"}}
print(json.dumps(j, ensure_ascii=False))
sys.exit(0 if (r.status_code == 200 and j.get("ok")) else 1)
