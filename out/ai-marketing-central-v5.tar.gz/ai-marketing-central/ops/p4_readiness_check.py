#!/usr/bin/env python3
"""يتحقق من نتائج Workflow الجاهزية (بعد `n8n execute wfReadiness00001`). أوضاع: before | after | again. يعمل داخل الشبكة المعزولة."""
import json, os, re, sys, time, urllib.request
import psycopg
MOCK, N8N = "http://platform-mock:8080", "http://n8n:5678"
mode = sys.argv[1]
db = psycopg.connect(f"postgresql://postgres:{os.environ['PGPASSWORD']}@postgres:5432/p4_central", autocommit=True)
def q(sql, *a): return db.execute(sql, a).fetchall()
def status(slug): return q("SELECT status::text FROM core.tenants WHERE slug = %s", slug)[0][0]
def calls(): return json.loads(urllib.request.urlopen(MOCK + "/__control/calls").read())["calls"]
res = []
def chk(i, d, ok, detail=""):
    res.append(bool(ok)); print(("PASS " if ok else "FAIL ") + i + " " + d + ("" if ok else "  -> " + str(detail)[:400]), flush=True)

if mode == "before":
    urllib.request.urlopen(urllib.request.Request(MOCK + "/__control/reset", data=b"{}", method="POST"))
    chk("K00", "before: E is TESTING (not usable yet), D is READY", status("tenant-e") == "TESTING" and status("tenant-d") == "READY", (status("tenant-e"), status("tenant-d")))
    # E ما زال لا يستقبل أوامر (ليس READY): الـ webhook يصمت
    upd = {"update_id": int(time.time()) % 10**8 * 10 + 1, "message": {"message_id": 1, "from": {"id": 5001}, "chat": {"id": 5001, "type": "private"}, "text": "/accounts", "date": int(time.time())}}
    req = urllib.request.Request(N8N + "/webhook/tg-ingress?bot=botEEEEEEEEEEEEEEEEEEEEEEEE", data=json.dumps(upd).encode(), headers={"content-type": "application/json", "x-telegram-bot-api-secret-token": "secret-e"}, method="POST")
    urllib.request.urlopen(req, timeout=20).read(); time.sleep(4)
    chk("K00b", "before: a TESTING tenant's bot stays silent to commands", not [c for c in calls() if c["platform"] == "telegram"], calls())
    urllib.request.urlopen(urllib.request.Request(MOCK + "/__control/reset", data=b"{}", method="POST"))
elif mode == "after":
    chk("K01", "E reached READY through the DB gate after the runner", status("tenant-e") == "READY", status("tenant-e"))
    rows = q("SELECT c.check_code, c.status::text FROM core.readiness_checks c JOIN core.tenants t USING (tenant_id) WHERE t.slug = 'tenant-e' ORDER BY 1")
    chk("K02", "E has all 15 checks recorded and passing", len(rows) == 15 and all(s == "pass" for _, s in rows), rows)
    chk("K03", "D (bot token/connections missing in vault) was demoted to NEEDS_REVIEW", status("tenant-d") == "NEEDS_REVIEW", status("tenant-d"))
    d2 = q("SELECT c.status::text FROM core.readiness_checks c JOIN core.tenants t USING (tenant_id) WHERE t.slug = 'tenant-d' AND c.check_code = 'R02'")
    chk("K03b", "D's R02 failed with evidence", d2 == [("fail",)], d2)
    chk("K04", "A and B stay READY", status("tenant-a") == "READY" and status("tenant-b") == "READY", (status("tenant-a"), status("tenant-b")))
    ev = q("SELECT count(*) FROM core.readiness_checks WHERE evidence::text ~ 'FAKE-|[0-9]{8,10}:[A-Za-z0-9_-]{30,}|EAA[A-Za-z0-9]{20,}'")[0][0]
    chk("K05", "no token-like text in readiness evidence", ev == 0, ev)
    cs = calls()
    own = {"act_E1": "FAKE-E-META", "tt_E1": "FAKE-E-TT", "act_A1": "FAKE-A-META", "tt_A1": "FAKE-A-TT", "act_B1": "FAKE-B-META", "tt_B1": "FAKE-B-TT"}
    mixed = [c["path"] for c in cs if c["platform"] in ("meta", "tiktok") for acct, tok in own.items()
             if (acct in c["path"] or acct in json.dumps(c["query"]) or acct in json.dumps(c["body"])) and tok not in (c["auth"] + c["access_token"])]
    chk("K06", "every platform probe used only the owning tenant's own token", not mixed, mixed)
    posts = [c for c in cs if c["method"] == "POST" and c["platform"] in ("meta", "tiktok")]
    chk("K07", "readiness made NO real create: every platform POST is validate_only", all("validate_only" in (c["body"].get("execution_options") or []) for c in posts) and not [c for c in cs if "/campaign/create" in c["path"]], posts)
    tg = [c for c in cs if c["platform"] == "telegram" and c["path"].endswith("/sendMessage")]
    chk("K08", "R04 round-trip message went to E's owner via bot 555 only", len(tg) == 1 and "/bot555:" in tg[0]["path"] and tg[0]["body"]["chat_id"] == 5001, tg)
    crossing = [c["path"] for c in cs if c["platform"] in ("meta", "tiktok") and (("act_B1" in c["path"] or "tt_B1" in c["path"]) and "FAKE-B" not in (c["auth"] + c["access_token"]))]
    chk("K09", "isolation probes (R10) were refused before reaching any platform", not crossing, crossing)
    # E صار READY: مالكه يستطيع استعمال البوت
    urllib.request.urlopen(urllib.request.Request(MOCK + "/__control/reset", data=b"{}", method="POST"))
    upd = {"update_id": int(time.time()) % 10**8 * 10 + 2, "message": {"message_id": 1, "from": {"id": 5001}, "chat": {"id": 5001, "type": "private"}, "text": "/accounts", "date": int(time.time())}}
    req = urllib.request.Request(N8N + "/webhook/tg-ingress?bot=botEEEEEEEEEEEEEEEEEEEEEEEE", data=json.dumps(upd).encode(), headers={"content-type": "application/json", "x-telegram-bot-api-secret-token": "secret-e"}, method="POST")
    urllib.request.urlopen(req, timeout=20).read()
    for _ in range(30):
        tg = [c for c in calls() if c["platform"] == "telegram"]
        if tg: break
        time.sleep(0.5)
    t = " ".join(str(c["body"].get("text", "")) for c in tg)
    chk("K10", "once READY, E's owner gets E's accounts (and only E's) from the bot", len(tg) == 1 and "act_E1" in t and "_A1" not in t and "_B1" not in t and "/bot555:" in tg[0]["path"], t)
elif mode == "again":
    tg = [c for c in calls() if c["platform"] == "telegram" and c["path"].endswith("/sendMessage")]
    chk("K11", "second runner pass is idempotent: no repeated R04 message to the owner", not tg, tg)
    chk("K12", "E still READY, A/B still READY after second pass", status("tenant-e") == "READY" and status("tenant-a") == "READY" and status("tenant-b") == "READY")
print(f"READINESS[{mode}]: {sum(res)}/{len(res)} passed"); sys.exit(0 if all(res) else 1)
