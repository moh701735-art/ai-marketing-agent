#!/usr/bin/env python3
"""يزرع أسراراً وهمية في الـ vault عبر واجهة الـ Broker الإدارية (كما سيفعل مسار الربط الحقيقي لاحقاً). يعمل داخل حاوية على الشبكة المعزولة.
الدخل: متغيرات بيئة BROKER_ADMIN_KEY (ASCII). الناتج: يطبع JSON بالتوكنات الوهمية (لا قيمة حقيقية هنا)."""
import json, os, secrets, sys, time
import httpx
import hmac_auth

KEY = os.environ["BROKER_ADMIN_KEY"].encode()
A, B, E = "a0000000-0000-0000-0000-000000000001", "b0000000-0000-0000-0000-000000000001", "e0000000-0000-0000-0000-000000000001"
ITEMS = [("ref-bot-a", A, "telegram_bot_token", "111:AAF" + secrets.token_hex(16)), ("ref-bot-b", B, "telegram_bot_token", "222:AAF" + secrets.token_hex(16)),
         ("ref-a-meta", A, "meta_user_token", "FAKE-A-META-" + secrets.token_hex(10)), ("ref-a-tt", A, "tiktok_token", "FAKE-A-TT-" + secrets.token_hex(10)),
         ("ref-b-meta", B, "meta_user_token", "FAKE-B-META-" + secrets.token_hex(10)), ("ref-b-tt", B, "tiktok_token", "FAKE-B-TT-" + secrets.token_hex(10)),
         ("ref-bot-e", E, "telegram_bot_token", "555:AAF" + secrets.token_hex(16)), ("ref-e-meta", E, "meta_user_token", "FAKE-E-META-" + secrets.token_hex(10)), ("ref-e-tt", E, "tiktok_token", "FAKE-E-TT-" + secrets.token_hex(10))]
out = {}
for ref, tenant, kind, value in ITEMS:
    body = json.dumps({"tenant_id": tenant, "kind": kind, "secret_ref": ref, "value": value}).encode()
    ts, nonce = int(time.time()), secrets.token_hex(12)
    r = httpx.post("http://broker:8080/v1/admin/secrets", content=body, timeout=15, headers={
        "content-type": "application/json", "x-key-id": "ops-admin", "x-timestamp": str(ts), "x-nonce": nonce, "x-signature": hmac_auth.sign(KEY, body, ts, nonce)})
    if r.status_code != 200:
        print("FAILED", ref, r.status_code, r.text, file=sys.stderr); sys.exit(1)
    out[ref] = {"version": r.json()["version"], "value": value}
    if kind == "telegram_bot_token":      # المنصة الوهمية صارت تحفظ حالة الـ webhook: نسجّل واحداً للبوتات الوهمية (R03 يشترط url غير فارغ)
        w = httpx.post(f"http://platform-mock:8080/telegram/bot{value}/setWebhook", json={"url": "https://n8n.mock.local/webhook/tg-ingress?bot=mock", "secret_token": "mock"}, timeout=15)
        if w.status_code != 200:
            print("FAILED mock setWebhook", ref, w.status_code, file=sys.stderr); sys.exit(1)
print(json.dumps(out))
