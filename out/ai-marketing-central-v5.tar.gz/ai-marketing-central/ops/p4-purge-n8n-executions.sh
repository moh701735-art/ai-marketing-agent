#!/usr/bin/env bash
# يحذف فعلياً (hard delete) كل بيانات التنفيذ من قاعدة n8n المحلية (SQLite) ثم يفرّغ WAL.
# السبب: n8n يضع نص webhook (رسالة المستخدم، وقد يلصق توكناً) في execution_data حتى مع save=none، ومنظّف n8n الداخلي فشل
# عندنا («A system task run failed») فتبقى الصفوف المحذوفة منطقياً. هذا التنظيف يُجدوَل دورياً بالتشغيل (cron) ويُشغَّل قبل كل فحص أسرار.
set -euo pipefail
docker exec "${N8N_CONTAINER:-central-n8n}" node -e '
const sqlite3 = require("/usr/local/lib/node_modules/n8n/node_modules/.pnpm/sqlite3@5.1.7_bluebird@3.7.2_supports-color@8.1.1/node_modules/sqlite3");
const db = new sqlite3.Database("/home/node/.n8n/database.sqlite");
db.configure("busyTimeout", 15000);
db.serialize(() => {
  db.run("DELETE FROM execution_data");
  db.run("DELETE FROM execution_metadata");
  db.run("DELETE FROM execution_entity");
  db.run("PRAGMA wal_checkpoint(TRUNCATE)");
  db.get("SELECT (SELECT count(*) FROM execution_entity) AS e, (SELECT count(*) FROM execution_data) AS d", (err, row) => { console.log(err ? "ERR " + err.message : "purged: executions=" + row.e + " data=" + row.d); db.close(); });
});'
