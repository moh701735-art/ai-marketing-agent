#!/usr/bin/env bash
# يستورد الاعتمادات والـ Workflows إلى n8n المحلي الجديد وينشرها. الاعتمادات تُولَّد من .env إلى n8n/generated/ (غير مرفوع إلى Git).
set -euo pipefail
cd "$(dirname "$0")/.."
python3 n8n/build.py >/dev/null
PW=$(grep ^P4_SVC_PW .env | cut -d= -f2); HK=$(grep ^BROKER_HMAC_KEY .env | cut -d= -f2)
mkdir -p n8n/generated
python3 - "$PW" "$HK" <<'PY'
import json, sys
pw, hk = sys.argv[1], sys.argv[2]
def pg(i, name, user): return {"id": i, "name": name, "type": "postgres", "data": {"host": "postgres", "port": 5432, "database": "p4_central", "user": user, "password": pw, "maxConnections": 10, "allowUnauthorizedCerts": False, "ssl": "disable", "sshTunnel": False, "sshAuthenticateWith": "password"}}
json.dump([pg("credPgRuntime0001", "central DB (runtime)", "n8n_runtime_svc"), pg("credPgJobs000001", "central DB (jobs)", "n8n_jobs_svc"),
           {"id": "credCryptoBroker1", "name": "Broker HMAC (n8n runtime)", "type": "crypto", "data": {"hmacSecret": hk}}], open("n8n/generated/credentials.json", "w"))
PY
chmod 644 n8n/generated/credentials.json   # الحاوية (node) تقرؤه عبر bind mount مهما كان umask
N="docker exec central-n8n n8n"
$N import:credentials --input=/import/generated/credentials.json 2>&1 | tail -1
$N import:workflow --separate --input=/import/workflows/ 2>&1 | tail -1
for id in $(ls n8n/workflows/*.json | xargs -n1 python3 -c "import json,sys;d=json.load(open(sys.argv[1]));print(d['id'])"); do $N publish:workflow --id=$id >/dev/null 2>&1 || true; done
docker restart central-n8n >/dev/null
for i in $(seq 1 40); do docker exec central-n8n wget -qO- http://localhost:5678/healthz >/dev/null 2>&1 && break; sleep 2; done
echo "n8n: workflows imported & published"; $N list:workflow 2>&1 | tail -8
