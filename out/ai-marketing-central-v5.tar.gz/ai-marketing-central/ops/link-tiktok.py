#!/usr/bin/env python3
"""Link a TikTok advertiser to an EXISTING tenant. Secrets are typed hidden and never printed.
Run from /opt/central with: PG_CONTAINER=... BROKER_NETWORK=... BROKER_IMAGE=... ENV_FILE=deploy/.env TENANT_DB=central python3 ops/link-tiktok.py"""
import getpass, importlib.util, json, os, secrets, urllib.request
from pathlib import Path

spec = importlib.util.spec_from_file_location("at", Path(__file__).with_name("add-tenant.py"))
at = importlib.util.module_from_spec(spec); spec.loader.exec_module(at)

SQL = r"""
BEGIN;
INSERT INTO core.platform_connections (tenant_id, platform, auth_mode, external_user_id, secret_ref)
  VALUES (:'tid', 'tiktok', 'tiktok_oauth', :'user', :'ref');
INSERT INTO core.ad_accounts (tenant_id, platform, external_id, connection_id, name)
  SELECT :'tid', 'tiktok', :'adv', connection_id, :'name' FROM core.platform_connections WHERE tenant_id = :'tid' AND platform = 'tiktok';
UPDATE core.tenants SET features = features || '{"tiktok": true}'::jsonb WHERE tenant_id = :'tid';
COMMIT;
"""


def main():
    db = os.environ.get("TENANT_DB", "central")
    slug = os.environ.get("LT_SLUG") or input("Tenant slug (e.g. mohm): ").strip()
    app_id = os.environ.get("LT_APP_ID") or input("TikTok App ID: ").strip()
    adv = os.environ.get("LT_ADV") or input("Advertiser ID: ").strip()
    secret = getpass.getpass("App Secret (hidden): ").strip()
    code = getpass.getpass("auth_code (hidden): ").strip()
    tid = at.psql(db, "SELECT tenant_id FROM core.tenants WHERE slug = :'slug'", {"slug": slug}, tx=False)
    if not tid:
        at.die("tenant not found")
    if at.psql(db, "SELECT 1 FROM core.platform_connections WHERE tenant_id = :'tid' AND platform = 'tiktok'", {"tid": tid}, tx=False):
        at.die("tenant already has a tiktok connection")
    body = json.dumps({"app_id": app_id, "secret": secret, "auth_code": code}).encode()
    req = urllib.request.Request("https://business-api.tiktok.com/open_api/v1.3/oauth2/access_token/", data=body, headers={"Content-Type": "application/json"})
    r = json.load(urllib.request.urlopen(req, timeout=30))
    if r.get("code") != 0:
        at.die(f"TikTok error {r.get('code')}: {r.get('message')}")
    d = r["data"]
    granted = [str(x) for x in d.get("advertiser_ids", [])]
    if adv not in granted:
        at.die(f"advertiser not granted to this authorization (granted accounts: {len(granted)})")
    print("scope:", d.get("scope"))
    ref = f"ref-{slug}-tt-{secrets.token_hex(4)}"
    at.vault([{"tenant_id": tid, "kind": "tiktok_token", "secret_ref": ref, "value": d["access_token"]}])
    print("vault: token stored (not shown)")
    try:
        at.psql(db, SQL, {"tid": tid, "user": f"tt_{adv}", "ref": ref, "adv": adv, "name": f"TikTok {adv}"}, tx=False)
    except RuntimeError as e:
        try:
            at.vault([{"tenant_id": tid, "secret_ref": ref}], "revoke")
        except RuntimeError as e2:
            print("warning: revoke failed:", e2)
        at.die(f"DB insert failed, token revoked: {e}")
    print(f"done: tiktok advertiser {adv} linked to tenant {slug}")


if __name__ == "__main__":
    main()
