#!/usr/bin/env bash
# يشغّل اختبارات P4 كاملة داخل الشبكة المعزولة: أوامر البوت (E) + التقرير المجدول (J) + الجاهزية والترقية (K).
# يتطلب: ./ops/p4-up.sh مرة واحدة. يعيد الحالة أولاً (./ops/p4-reset.sh) ما لم يُمرَّر --no-reset.
set -uo pipefail
cd "$(dirname "$0")/.."
[ "${1:-}" = "--no-reset" ] || ./ops/p4-reset.sh >/dev/null 2>&1 || { echo "FAIL: p4-reset"; exit 1; }
PW=$(grep ^POSTGRES_PASSWORD .env | cut -d= -f2)
RUN="docker run --rm --network central_internal_only -e PGPASSWORD=$PW"
EXEC="docker exec -e N8N_RUNNERS_BROKER_PORT=5690 -e N8N_PORT=5690 central-n8n n8n execute"
PYIN() { $RUN -v "$PWD/ops/$1:/w/x.py:ro" -w /w --entrypoint python central-broker:dev x.py "${@:2}"; }
PYIN p4_e2e.py; rc1=$?
echo "── hourly job (n8n execute wfJobReport00001) ──"
PYIN p4_job_check.py reset
$EXEC --id=wfJobReport00001 >/tmp/p4_job_exec.log 2>&1
grep -q '"status": "success"' /tmp/p4_job_exec.log || { echo "FAIL J00 job execution did not finish with success"; tail -5 /tmp/p4_job_exec.log; rc2=1; }
PYIN p4_job_check.py; rc3=$?
echo "── readiness runner (n8n execute wfReadiness00001) ──"
PYIN p4_readiness_check.py before; rc4=$?
$EXEC --id=wfReadiness00001 >/tmp/p4_ready1.log 2>&1
grep -q '"status": "success"' /tmp/p4_ready1.log || { echo "FAIL K-run readiness execution did not finish with success"; tail -5 /tmp/p4_ready1.log; rc5=1; }
PYIN p4_readiness_check.py after; rc6=$?
PYIN p4_job_check.py reset
$EXEC --id=wfReadiness00001 >/tmp/p4_ready2.log 2>&1
grep -q '"status": "success"' /tmp/p4_ready2.log || { echo "FAIL K-run2 readiness execution did not finish with success"; rc7=1; }
PYIN p4_readiness_check.py again; rc8=$?
echo "── subscriptions (B: active -> grace -> expired -> renewed) ──"
PYIN p4_sub_check.py chat; rcs1=$?
PYIN p4_job_check.py reset
$EXEC --id=wfJobReport00001 >/tmp/p4_job_exec2.log 2>&1
grep -q '"status": "success"' /tmp/p4_job_exec2.log || { echo "FAIL S-run job execution did not finish with success"; rcs0=1; }
PYIN p4_sub_check.py job; rcs2=$?
PYIN p4_sub_check.py renew; rcs3=$?
echo "── error workflow (self-test fails on purpose) ──"
PYIN p4_error_check.py; rc9=$?
echo "── secrets scan (n8n data, container logs, DB dump, repo) ──"
./ops/p4-purge-n8n-executions.sh >/dev/null; ./ops/p4-scan-secrets.sh | tail -2; rcx=${PIPESTATUS[0]}
exit $(( rcx | rcs1 | rcs2 | rcs3 | ${rcs0:-0} | rc9 | rc1 | ${rc2:-0} | rc3 | rc4 | ${rc5:-0} | rc6 | ${rc7:-0} | rc8 ))
