-- بصمة بيانات كل جدول (عدد الصفوف + md5 للمحتوى مرتباً). نفس الناتج قبل الفقد وبعد الاستعادة = بيانات متطابقة.
SELECT format('SELECT %L, count(*), coalesce(md5(string_agg(t::text, E''\n'' ORDER BY t::text)), ''-'') FROM %s t', n, n)
FROM (SELECT format('%I.%I', schemaname, tablename) AS n FROM pg_tables WHERE schemaname IN ('core','vault') ORDER BY 1) x \gexec
