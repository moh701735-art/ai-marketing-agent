#!/usr/bin/env python3
"""seal: يطبع SQL يضع سرّين وهميين مشفّرين في vault_dev (KEK تجريبي يُولَّد في .secrets/). check: يفك تشفير ما استُعيد ويقارنه."""
import base64, hashlib, json, os, pathlib, secrets, sys
ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "broker"))
import envelope
SEC = ROOT / ".secrets"; SEC.mkdir(exist_ok=True, mode=0o700)
KEKF, EXPF = SEC / "drill_kek", SEC / "drill_expected.json"
ITEMS = [("ref-a-meta", "a0000000-0000-0000-0000-000000000001", "meta_user_token", 1),
         ("ref-b-meta", "b0000000-0000-0000-0000-000000000001", "meta_user_token", 1)]
def kek():
    if not KEKF.exists():
        KEKF.write_text(base64.b64encode(os.urandom(32)).decode()); KEKF.chmod(0o600)
    return envelope.load_kek(KEKF.read_text())
if sys.argv[1] == "seal":
    k, exp = kek(), {}
    for ref, tenant, kind, ver in ITEMS:
        plain = ("FAKE-" + secrets.token_hex(16)).encode()
        s = envelope.seal(plain, k, tenant, kind, ver, ref)
        exp[ref] = hashlib.sha256(plain).hexdigest()
        print(f"INSERT INTO vault.secret_refs (secret_ref, tenant_id, kind) VALUES ('{ref}','{tenant}','{kind}') ON CONFLICT DO NOTHING;")
        print(f"INSERT INTO vault.secrets (secret_ref, tenant_id, kind, version, ciphertext, dek_wrapped) VALUES "
              f"('{ref}','{tenant}','{kind}',{ver},decode('{s.ciphertext.hex()}','hex'),decode('{s.dek_wrapped.hex()}','hex'));")
    EXPF.write_text(json.dumps(exp))
else:  # check: stdin = secret_ref|tenant|kind|version|ciphertext_hex|dek_hex
    k, exp, ok = kek(), json.loads(EXPF.read_text()), True
    for line in sys.stdin:
        ref, tenant, kind, ver, ct, dek = line.strip().split("|")
        plain = envelope.open_(envelope.Sealed(bytes.fromhex(ct), bytes.fromhex(dek)), k, tenant, kind, int(ver), ref)
        good = hashlib.sha256(plain).hexdigest() == exp[ref]
        ok &= good
        print(f"vault decrypt {ref}: {'OK' if good else 'MISMATCH'}")
    sys.exit(0 if ok else 1)
