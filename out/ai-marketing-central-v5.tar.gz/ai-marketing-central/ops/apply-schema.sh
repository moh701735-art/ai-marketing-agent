#!/usr/bin/env bash
# ينشئ قاعدتين فارغتين جديدتين (central_dev, vault_dev) ويطبّق المخطط. يرفض إن كانتا موجودتين.
set -euo pipefail
cd "$(dirname "$0")/.."
P="docker exec -i central-pg psql -U postgres -q -v ON_ERROR_STOP=1"
for d in central_dev vault_dev; do
  C=$($P -Atc "select count(*) from pg_database where datname='$d'") && [ "$C" = "0" ] || { echo "$d موجودة مسبقاً - توقف"; exit 1; }
done
$P -d postgres -f /work/db/00_roles.sql >/dev/null
$P -d postgres -c "CREATE DATABASE central_dev" -c "CREATE DATABASE vault_dev" >/dev/null
$P -d central_dev -c "REVOKE ALL ON DATABASE central_dev FROM PUBLIC; GRANT CONNECT ON DATABASE central_dev TO app_runtime, app_jobs, app_ops, app_owner, app_resolver, app_ops_fn, app_broker; GRANT TEMPORARY ON DATABASE central_dev TO app_owner;" >/dev/null
for f in 10_schema 20_rls 30_functions 35_broker_auth 40_partitions 60_rules; do $P -d central_dev -f /work/db/$f.sql >/dev/null; done
$P -d vault_dev -f /work/db/50_vault.sql >/dev/null; $P -d vault_dev -f /work/db/51_vault_broker.sql >/dev/null
$P -d vault_dev -c "REVOKE ALL ON DATABASE vault_dev FROM PUBLIC; GRANT CONNECT ON DATABASE vault_dev TO broker_rw;" >/dev/null
echo "المخطط مطبّق على central_dev و vault_dev (فارغتان من أي بيانات)"
