#!/usr/bin/env bash
# تمرين النسخ الاحتياطي/الاستعادة الكامل. يكتب سجلاً بالنتائج الفعلية في docs/results/.
# يحذف فقط حجم بيانات هذا المشروع المحلي (central_pgdata) كمحاكاة للفقد.
set -uo pipefail
cd "$(dirname "$0")/.."
TS=$(date -u +%Y%m%dT%H%M%SZ); LOG="docs/results/restore-drill-$TS.log"; exec > >(tee "$LOG") 2>&1
PS="docker exec -i central-pg psql -U postgres -q"; FAIL=0
step() { echo; echo "== $*"; }
chk() { if [ "$2" = "0" ]; then echo "PASS  $1"; else echo "FAIL  $1"; FAIL=1; fi; }
V=$(./scripts/ensure_venv.sh)
echo "restore drill $TS  host=$(hostname)  docker=$(docker version -f '{{.Server.Version}}')"

step "1) حالة قبل الفقد: بصمات + مخطط + نسخة احتياطية مشفّرة"
B="ops/backups/drill-$TS"
for db in central_dev vault_dev; do docker exec central-pg psql -U postgres -d $db -Atq -F'|' -f /work/ops/seed/checksums.sql > /tmp/before.$db; done
docker exec central-pg pg_dump -U postgres -s central_dev > /tmp/schema.before
./ops/backup.sh "$B"
ls -l "$B" | awk 'NR>1{print "  "$5" bytes  "$9}'
head -c 8 "$B/central_dev.dump.gpg" | od -An -tx1 | tr -d ' \n' | sed 's/^/  أول بايتات الملف المشفّر: /'
grep -aq "tenant-a" "$B/central_dev.dump.gpg" && chk "الملف المشفّر لا يحوي نصاً صريحاً" 1 || chk "الملف المشفّر لا يحوي نصاً صريحاً (tenant-a غير ظاهر)" 0
echo "  جداول بصمتها: $(wc -l < /tmp/before.central_dev) (central) + $(wc -l < /tmp/before.vault_dev) (vault)"

step "2) محاكاة الفقد: حذف حجم قاعدة البيانات المحلية بالكامل"
T0=$(date +%s)
./ops/db-down.sh --wipe >/dev/null 2>&1; ./ops/db-up.sh | tail -1
C=$($PS -d postgres -Atc "select count(*) from pg_database where datname in ('central_dev','vault_dev')")
chk "العنقود الجديد فارغ (لا قاعدتا التطبيق)" "$C"

step "3) الاستعادة من النسخة المشفّرة"
./ops/restore.sh "$B"; chk "restore.sh" "$?"
T1=$(date +%s); echo "  RTO الفعلي (حذف -> استعادة كاملة): $((T1-T0)) ثانية"

step "4) مطابقة البيانات (عدد الصفوف + md5 لكل جدول)"
for db in central_dev vault_dev; do
  docker exec central-pg psql -U postgres -d $db -Atq -F'|' -f /work/ops/seed/checksums.sql > /tmp/after.$db
  diff -q /tmp/before.$db /tmp/after.$db >/dev/null; chk "$db: $(wc -l < /tmp/after.$db) جدولاً متطابقاً" "$?"
done
step "5) مطابقة المخطط والصلاحيات (pg_dump -s قبل/بعد)"
docker exec central-pg pg_dump -U postgres -s central_dev > /tmp/schema.after
diff -q /tmp/schema.before /tmp/schema.after >/dev/null; chk "المخطط + ACL + سياسات RLS متطابقة ($(wc -l < /tmp/schema.after) سطراً)" "$?"
R=$($PS -d central_dev -Atc "select count(*) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='core' and c.relkind in ('r','p') and c.relrowsecurity and c.relforcerowsecurity")
echo "  جداول core بـ RLS مُجبَر بعد الاستعادة: $R"; [ "$R" -gt 20 ]; chk "RLS مفعّل ومُجبَر بعد الاستعادة" "$?"

step "6) فك تشفير سرّ الـ vault المستعاد بالـ KEK المحفوظ منفصلاً"
$PS -d vault_dev -Atc "select secret_ref||'|'||tenant_id||'|'||kind||'|'||version||'|'||encode(ciphertext,'hex')||'|'||encode(dek_wrapped,'hex') from vault.secrets order by 1" | "$V/bin/python" ops/seed/vault_seed.py check
chk "فك تشفير الأسرار المستعادة" "${PIPESTATUS[1]}"

step "7) سلوك العزل على البيانات المستعادة (كدور التطبيق، لا superuser)"
h=$($PS -d central_dev -Atc "select encode(ext.digest('secret-a','sha256'),'hex')")
CA=$(docker exec -e PGOPTIONS='-c role=app_runtime' central-pg psql -U postgres -qAt -d central_dev -c "select ctx from api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode('$h','hex'), 1003)")
N=$(docker exec -e PGOPTIONS='-c role=app_runtime' central-pg psql -U postgres -qAt -d central_dev -c "select count(*)||'|'||string_agg(external_id,',') from api.list_campaigns('$CA')")
echo "  عميل A يرى: $N"; [ "$N" = "1|fake-camp-A1" ]; chk "A يرى حملته فقط بعد الاستعادة (لا حملة B)" "$?"
D=$(docker exec -e PGOPTIONS='-c role=app_runtime' central-pg psql -U postgres -qAt -d central_dev -c "select count(*) from core.campaigns" 2>&1 | head -1)
echo "  وصول مباشر للجدول كدور التطبيق: $D"; echo "$D" | grep -qi "permission denied"; chk "الدور التطبيقي ممنوع من الجدول مباشرة" "$?"

step "8) اختبارات القاعدة الـ205 على العنقود المستعاد"
R=$(./ops/run-db-tests.sh 2>&1 | grep -E "^RESULT|FAIL:"); RC=$?; echo "$R"; echo "$R" | grep -qE "^RESULT: [0-9]+ passed, 0 failed"; chk "كل اختبارات القاعدة على العنقود المستعاد ($(echo "$R" | head -1))" $? "$R"

step "الخلاصة"
[ $FAIL = 0 ] && echo "DRILL: PASS" || echo "DRILL: FAIL"
exit $FAIL
