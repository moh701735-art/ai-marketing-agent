#!/usr/bin/env bash
# يستعيد نسخة احتياطية على عنقود postgres فارغ (جديد). يرفض إن كانت القاعدتان موجودتين.
# الاستعمال: ops/restore.sh <مجلد_النسخة>
set -euo pipefail
cd "$(dirname "$0")/.."
D="$1"; ( cd "$D" && sha256sum -c SHA256SUMS >/dev/null ) || { echo "فشل التحقق من سلامة الملفات"; exit 1; }
DEC() { gpg --batch --quiet --pinentry-mode loopback --passphrase-file .secrets/backup.pass -d "$1"; }
PG="docker exec -i central-pg"
C=$($PG psql -U postgres -Atc "select count(*) from pg_database where datname in ('central_dev','vault_dev')")
[ "$C" = "0" ] || { echo "الهدف ليس فارغاً - توقف"; exit 1; }
DEC "$D/globals.sql.gpg" | $PG psql -U postgres -q -d postgres >/dev/null
for db in central_dev vault_dev; do DEC "$D/$db.dump.gpg" | $PG pg_restore -U postgres --create -d postgres --exit-on-error; done
echo "restore: تمت الاستعادة من $D"
