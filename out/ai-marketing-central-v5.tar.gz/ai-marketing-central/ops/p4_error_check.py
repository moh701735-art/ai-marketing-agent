#!/usr/bin/env python3
"""يشغّل Workflow الاختبار الذاتي الذي يفشل عمداً ويتحقق أن Error Workflow سجّل الخطأ منقّىً من التوكنات وبتصنيف. داخل الشبكة المعزولة."""
import os, sys, time, urllib.request
import psycopg
db = psycopg.connect(f"postgresql://postgres:{os.environ['PGPASSWORD']}@postgres:5432/p4_central", autocommit=True)
before = db.execute("SELECT coalesce(max(error_id),0) FROM core.error_log").fetchone()[0]
urllib.request.urlopen(urllib.request.Request("http://n8n:5678/webhook/selftest-error", data=b"{}", headers={"content-type": "application/json"}, method="POST"), timeout=20).read()
rows = []
for _ in range(30):
    rows = db.execute("SELECT class::text, workflow, node, tenant_id, message FROM core.error_log WHERE error_id > %s AND workflow LIKE 'test: error workflow%%'", (before,)).fetchall()
    if rows: break
    time.sleep(0.5)
ok = []
def chk(i, d, c, det=""): ok.append(bool(c)); print(("PASS " if c else "FAIL ") + i + " " + d + ("" if c else " -> " + str(det)[:300]), flush=True)
chk("X01", "failing workflow was logged centrally by the Error Workflow (system error, tenant NULL)", len(rows) == 1 and rows[0][3] is None, rows)
chk("X02", "logged with node name and classified as BUG (TypeError)", rows and rows[0][2] == "Boom" and rows[0][0] == "BUG", rows)
chk("X03", "token-like text redacted in the stored message", rows and "[REDACTED]" in rows[0][4] and "AAFxxxx" not in rows[0][4], rows)
print(f"ERRORS: {sum(ok)}/{len(ok)} passed"); sys.exit(0 if all(ok) else 1)
