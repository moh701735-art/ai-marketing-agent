#!/usr/bin/env python3
"""فحص أن الاختبارات ليست «ناجحة بالفراغ»: يكسر الكود عمداً (mutation) ويتأكد أن الاختبارات تفشل، ثم يعيد الملف الأصلي.
الاستعمال: python3 ops/mutation-check.py  (يتطلب ops/db-up.sh). يكتب السجل في docs/results/."""
import pathlib, shutil, subprocess, sys, time

ROOT = pathlib.Path(__file__).resolve().parent.parent
MUT = [
    ("M1 replay protection off", "broker/app/main.py", 'if not reason and not await state["store"].use_nonce(kid, request.headers["x-nonce"]):', "if False:"),
    ("M2 forced PAUSED/DISABLE not enforced", "broker/app/catalog.py", "clean.update(op.forced)", "pass"),
    ("M3 writes retried after ambiguous timeout", "broker/app/service.py", "                if op.write:\n                    return None, b\"\", attempts, \"unknown_after_send\"", "                if False:\n                    return None, b\"\", attempts, \"unknown_after_send\""),
    ("M4 AAD no longer binds tenant", "broker/envelope.py", 'return f"{tenant_id}|{kind}|{int(version)}|{secret_ref}".encode()', 'return f"x|{kind}|{int(version)}|{secret_ref}".encode()'),
    ("M5 upstream success body not scrubbed", "broker/app/service.py", '"data": scrub(classify.parse_body(raw))', '"data": classify.parse_body(raw)'),
    ("M6 circuit breaker disabled", "broker/app/service.py", "if not self.breaker.allow(key):", "if False:"),
    ("M7 local rate limit disabled", "broker/app/service.py", "if not self.bucket.allow(key):", "if False:"),
    ("M8 central ignores connection status", "db/35_broker_auth.sql", "IF v_row.st <> 'active' THEN RAISE EXCEPTION 'connection_not_active' USING ERRCODE = '42501'; END IF;", ""),
    ("M9 ad account ownership not checked", "db/35_broker_auth.sql", "WHERE a.platform = p_platform::core.platform AND a.external_id = p_ad_account AND a.enabled AND a.unlinked_at IS NULL;", "WHERE a.platform = p_platform::core.platform AND a.unlinked_at IS NULL LIMIT 1;"),
    ("M10 idempotency claim ignores existing rows", "broker/app/store.py", "ON CONFLICT DO NOTHING\", (tenant_id, key, h, platform, op))\n                if cur.rowcount == 1:", "ON CONFLICT DO NOTHING\", (tenant_id, key, h, platform, op))\n                if True:"),
    ("M11 subscription expiry not enforced", "db/30_functions.sql", "IF v_sub IN ('expired','none') THEN RAISE EXCEPTION 'subscription_expired' USING ERRCODE = '42501'; END IF;", ""),
    ("M12 grace period allows writes", "db/30_functions.sql", "IF v_sub = 'grace' AND v_need >= 2 THEN", "IF False THEN"),
    ("M13 readiness probe open to non-system ctx", "db/35_broker_auth.sql", "v := private.enter_ctx(p_ctx, 'system', false);\n    IF (SELECT t.status", "v := private.enter_ctx(p_ctx, 'viewer', false);\n    IF (SELECT t.status"),
    ("M15 setWebhook url prefix not enforced", "broker/app/service.py", "url.startswith(prefix) and ", ""),
    ("M16 setWebhook accepts non-bot secrets", "broker/app/service.py", 'if kind != "telegram_bot_token":', "if False:"),
    ("M14 readiness mode may write", "broker/app/service.py", "if readiness and op.write:", "if False:"),
]
log = ROOT / "docs/results" / time.strftime("mutation-check-%Y%m%dT%H%M%SZ.log", time.gmtime())
out, bad = [], 0
for name, rel, old, new in MUT:
    f = ROOT / rel
    orig = f.read_text(encoding="utf-8")
    if old not in orig:
        out.append(f"SKIP  {name}: pattern not found"); bad += 1; continue
    f.write_text(orig.replace(old, new, 1), encoding="utf-8")
    try:
        r = subprocess.run(["./ops/run-broker-tests.sh"], cwd=ROOT, capture_output=True, text=True, timeout=300)
        txt = r.stdout + r.stderr
        failed = r.returncode != 0
        which = sorted({l.split(":")[0].replace("FAIL", "").replace("ERROR", "").strip() + l.split(":")[1][:60] for l in txt.splitlines() if l.startswith(("FAIL:", "ERROR:"))})[:3]
        out.append(f"{'KILLED' if failed else 'SURVIVED'}  {name}  -> {'; '.join(which) if failed else 'tests still pass (WEAK TESTS)'}")
        bad += 0 if failed else 1
    finally:
        f.write_text(orig, encoding="utf-8")
out.append(f"\nRESULT: {len(MUT) - bad}/{len(MUT)} mutations killed by the tests")
log.write_text("\n".join(out) + "\n", encoding="utf-8")
print("\n".join(out)); print("log:", log)
sys.exit(1 if bad else 0)
