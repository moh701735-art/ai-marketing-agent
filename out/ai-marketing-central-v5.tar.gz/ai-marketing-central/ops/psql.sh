#!/usr/bin/env bash
# psql داخل الحاوية (superuser محلي عبر socket). مثال: ops/psql.sh -d central_dev -c 'select 1'
exec docker exec -i central-pg psql -U postgres "$@"
