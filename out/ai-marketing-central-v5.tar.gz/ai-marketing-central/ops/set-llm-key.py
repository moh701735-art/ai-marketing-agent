#!/usr/bin/env python3
"""يحفظ مفتاح Gemini بملف أسرار الـ Broker (deploy/.secrets/broker_secrets.json) بدون ما يظهر بالمحادثة أو بسجل الأوامر.
الاستعمال من /opt/central:  python3 ops/set-llm-key.py   ثم الصق المفتاح عند السؤال (يُمسح من الشاشة بعد القراءة).
بعده: bash deploy/update.sh  (يعيد تشغيل الـ Broker ليقرأ المفتاح)."""
import json, os, re, sys

P = "deploy/.secrets/broker_secrets.json"
if not os.path.exists(P):
    sys.exit("شغّل الأمر من /opt/central")
k = input("الصق مفتاح Gemini (يبدأ بـ AIza) ثم Enter: ").strip()
sys.stdout.write("\033[1A\033[2K\r"); sys.stdout.flush()           # يمسح سطر المفتاح من الشاشة
if not re.fullmatch(r"AIza[0-9A-Za-z_\-]{30,60}", k):
    sys.exit("المفتاح غير صالح (لازم يبدأ بـ AIza وبلا مسافات). ما تغيّر شي.")
st = os.stat(P)
d = json.load(open(P))
d["llm_api_key"] = k
tmp = P + ".tmp"
with open(tmp, "w") as f:
    json.dump(d, f)
os.chmod(tmp, st.st_mode & 0o777)
os.replace(tmp, P)
print("تم حفظ المفتاح (%d حرف). الخطوة الجاية: bash deploy/update.sh" % len(k))
