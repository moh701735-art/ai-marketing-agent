#!/usr/bin/env bash
# يشغّل اختبارات خدمة الـ Broker (وحدة + تكامل + اختراق داخلي) على قواعد test جديدة، داخل حاوية على الشبكة المعزولة.
# لا منصات حقيقية: الـ upstream محاكى داخل الاختبارات. السجل الكامل في docs/results/.
set -euo pipefail
cd "$(dirname "$0")/.."
./ops/init-env.sh >/dev/null
PGPW=$(grep ^POSTGRES_PASSWORD .env | cut -d= -f2)
P="docker exec -i central-pg psql -U postgres -q -v ON_ERROR_STOP=1"
SVC_PW=$(openssl rand -hex 16)
V=$(./scripts/ensure_venv.sh)

$P -d postgres -c "DROP DATABASE IF EXISTS broker_central_test" -c "DROP DATABASE IF EXISTS broker_vault_test" -c "CREATE DATABASE broker_central_test" -c "CREATE DATABASE broker_vault_test" >/dev/null
$P -d postgres -f /work/db/00_roles.sql >/dev/null
$P -d broker_central_test -c "REVOKE ALL ON DATABASE broker_central_test FROM PUBLIC; GRANT CONNECT ON DATABASE broker_central_test TO app_runtime, app_jobs, app_ops, app_owner, app_resolver, app_ops_fn, app_broker; GRANT TEMPORARY ON DATABASE broker_central_test TO app_owner;" >/dev/null
for f in 10_schema 20_rls 30_functions 35_broker_auth 40_partitions; do $P -d broker_central_test -f /work/db/$f.sql >/dev/null; done
$P -d broker_central_test -f /work/db/tests/00_harness.sql >/dev/null
$P -d broker_central_test -f /work/db/tests/10_setup.sql >/dev/null
$P -d broker_vault_test -f /work/db/50_vault.sql >/dev/null
$P -d broker_vault_test -f /work/db/51_vault_broker.sql >/dev/null
# حسابات الخدمة (LOGIN) كأعضاء في الأدوار NOLOGIN. كلمات سر عشوائية لهذا التشغيل فقط.
for spec in "broker_central_svc:app_broker" "broker_vault_svc:broker_rw" "test_runtime_svc:app_runtime" "test_jobs_svc:app_jobs"; do
  u=${spec%%:*}; r=${spec##*:}
  $P -d postgres -c "DO \$\$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='$u') THEN CREATE ROLE $u LOGIN IN ROLE $r; END IF; END \$\$" -c "ALTER ROLE $u PASSWORD '$SVC_PW' LOGIN" >/dev/null
done
$P -d broker_vault_test -c "GRANT CONNECT ON DATABASE broker_vault_test TO broker_rw" >/dev/null 2>&1 || true

LOG="docs/results/broker-service-tests-$(date -u +%Y%m%dT%H%M%SZ).log"
H=central-pg
set +e
docker run --rm --network central_internal_only \
  -v "$PWD:/repo:ro" -v "$V/lib/python3.11/site-packages:/site:ro" \
  -e PYTHONPATH=/site:/repo/broker -e PYTHONDONTWRITEBYTECODE=1 \
  -e T_CENTRAL="postgresql://broker_central_svc:$SVC_PW@$H:5432/broker_central_test" \
  -e T_VAULT="postgresql://broker_vault_svc:$SVC_PW@$H:5432/broker_vault_test" \
  -e T_RUNTIME="postgresql://test_runtime_svc:$SVC_PW@$H:5432/broker_central_test" \
  -e T_JOBS="postgresql://test_jobs_svc:$SVC_PW@$H:5432/broker_central_test" \
  -e T_SUPER_CENTRAL="postgresql://postgres:$PGPW@$H:5432/broker_central_test" \
  -e T_SUPER_VAULT="postgresql://postgres:$PGPW@$H:5432/broker_vault_test" \
  python:3.11-slim python -m unittest discover -s /repo/broker/tests -v 2>&1 | tee "$LOG"
RC=${PIPESTATUS[0]}
echo "log: $LOG (exit=$RC)"
exit $RC
