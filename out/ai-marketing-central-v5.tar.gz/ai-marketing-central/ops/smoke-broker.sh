#!/usr/bin/env bash
# اختبار دخان للخدمة الفعلية: صورة Docker حقيقية + uvicorn + قاعدتا central_dev/vault_dev + منصة وهمية. كله على الشبكة المعزولة.
set -uo pipefail
cd "$(dirname "$0")/.."
LOG="docs/results/broker-smoke-$(date -u +%Y%m%dT%H%M%SZ).log"; exec > >(tee "$LOG") 2>&1
F=0; chk() { if [ "$2" = "0" ]; then echo "PASS  $1"; else echo "FAIL  $1  [$3]"; F=1; fi; }
./ops/init-env.sh >/dev/null; umask 077; mkdir -p .secrets
PGPW=$(grep ^POSTGRES_PASSWORD .env | cut -d= -f2); P="docker exec -i central-pg psql -U postgres -q -v ON_ERROR_STOP=1"
SVC_PW=$(openssl rand -hex 16)
[ -f .secrets/broker_secrets.json ] || printf '{"kek":"%s","hmac_keys":{"n8n-runtime":{"key":"%s","scope":"runtime"},"ops-admin":{"key":"%s","scope":"admin"}}}' \
  "$(openssl rand -base64 32)" "$(openssl rand -base64 32)" "$(openssl rand -base64 32)" > .secrets/broker_secrets.json
chgrp 10001 .secrets/broker_secrets.json && chmod 440 .secrets/broker_secrets.json   # يقرؤه مستخدم الخدمة (uid 10001) فقط
for spec in "broker_central_svc:app_broker" "broker_vault_svc:broker_rw"; do u=${spec%%:*}; r=${spec##*:}
  $P -d postgres -c "DO \$\$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='$u') THEN CREATE ROLE $u LOGIN IN ROLE $r; END IF; END \$\$" -c "ALTER ROLE $u PASSWORD '$SVC_PW'" >/dev/null; done
echo "== بناء الصورة"
CA=""; [ -f /root/.ccr/ca-bundle.crt ] && CA="--secret id=ca,src=/root/.ccr/ca-bundle.crt"
DOCKER_BUILDKIT=1 docker build $CA -t central-broker:dev broker/ >/tmp/broker_build.log 2>&1; chk "docker build central-broker:dev" $? "$(tail -3 /tmp/broker_build.log)"
[ $F = 0 ] || { echo "SMOKE: FAIL (build)"; exit 1; }
docker rm -f central-mock central-broker >/dev/null 2>&1
docker run -d --name central-mock --network central_internal_only -v "$PWD/mocks:/m:ro" python:3.11-slim python /m/echo_upstream.py >/dev/null
RUN() { docker run -d --name central-broker --network central_internal_only -v "$PWD/.secrets/broker_secrets.json:/run/secrets/broker.json:ro" \
  -e BROKER_SECRETS_FILE=/run/secrets/broker.json \
  -e BROKER_CENTRAL_DSN="postgresql://broker_central_svc:$SVC_PW@central-pg:5432/central_dev" -e BROKER_VAULT_DSN="postgresql://broker_vault_svc:$SVC_PW@central-pg:5432/vault_dev" \
  -e BROKER_META_BASE_URL="$1" -e BROKER_TIKTOK_BASE_URL="$1" central-broker:dev >/dev/null; }
echo "== حارس المنصات الحقيقية"
RUN "https://graph.facebook.com/v21.0"; sleep 4
[ "$(docker inspect central-broker -f '{{.State.Running}}')" = "false" ]; chk "الخدمة ترفض الإقلاع إذا أُشير لمنصة حقيقية" $? "$(docker logs central-broker 2>&1 | tail -2)"
LG=$(docker logs central-broker 2>&1); echo "$LG" | grep -q "REAL platform host"; chk "رسالة الرفض واضحة (REAL platform host)" $? "$(echo "$LG" | tail -1)"
docker rm -f central-broker >/dev/null
echo "== إقلاع طبيعي على المنصة الوهمية"
RUN "http://central-mock:8080"; sleep 6
[ "$(docker inspect central-broker -f '{{.State.Running}}')" = "true" ]; chk "الخدمة تعمل (uid $(docker exec central-broker id -u))" $? "$(docker logs central-broker 2>&1 | tail -5)"
U=$(docker exec central-broker id -u 2>/dev/null); [ -n "$U" ] && [ "$U" != "0" ]; chk "تعمل بمستخدم غير root" $? ""
echo "== عميل خارجي موقّع يخاطب الخدمة"
V=$(./scripts/ensure_venv.sh)
docker run --rm --network central_internal_only -v "$PWD:/repo:ro" -v "$V/lib/python3.11/site-packages:/site:ro" -v "$PWD/.secrets/broker_secrets.json:/s.json:ro" \
  -e PYTHONPATH=/site:/repo/broker -e PYTHONDONTWRITEBYTECODE=1 -e DBPW="$PGPW" python:3.11-slim python /repo/ops/smoke_client.py
chk "سيناريو العميل (healthz، رفض بلا توقيع، تخزين سر، قراءة، فحص التوكن بالمنصة الوهمية، لا تسريب)" $? ""
echo "== سجلات الخدمة لا تحوي أسراراً"
if docker logs central-broker 2>&1 | grep -qE "SMOKE-TOKEN|$SVC_PW"; then chk "لا أسرار في سجل الحاوية" 1 ""; else chk "لا أسرار في سجل الحاوية ($(docker logs central-broker 2>&1 | wc -l) سطراً)" 0 ""; fi
docker rm -f central-broker central-mock >/dev/null 2>&1
echo; [ $F = 0 ] && echo "SMOKE: PASS" || echo "SMOKE: FAIL"; exit $F
