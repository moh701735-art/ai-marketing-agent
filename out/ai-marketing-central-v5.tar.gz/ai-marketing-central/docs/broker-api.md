# Credential Broker — واجهة الخدمة وسلوكها (P3)

الـ Broker هو **المكان الوحيد** الذي يرى توكنات المنصات. n8n لا يحمل أي سر: يرسل `ctx` (توكن سياق موقّع من القاعدة المركزية) + اسم عملية من قائمة مسموحة.

## المصادقة (كل طلب)
رؤوس: `x-key-id`, `x-timestamp` (ثوانٍ UTC، نافذة ±60ث), `x-nonce` (16–64 حرفاً، لا يُستعمل مرتين — مخزَّن في vault فيعمل عبر عدة عمليات), `x-signature` = HMAC-SHA256(key, `"{ts}.{nonce}." + body`).
مفتاحان بنطاقين: `runtime` (يستدعي `/v1/call` فقط) و`admin` (يدير الأسرار). مفتاح runtime لا يصل لـ admin (اختبار IT04).

## نقاط النهاية
| المسار | النطاق | الوظيفة |
|---|---|---|
| `GET /healthz` | بلا | `{ok:true}` فقط |
| `POST /v1/call` | runtime | `{ctx, platform, op, ad_account?, params?, idempotency_key?, mode?}` — `mode:"readiness"` (اختياري، القيمة الوحيدة المقبولة) ينفّذ فحص جاهزية: يتطلب **system ctx** فقط، لعمليات غير كتابية فقط (يُرفض write بـ 400)، ويسمح بعميل قيد الإعداد (CONNECTING/TESTING/NEEDS_REVIEW/READY) |
| `POST /v1/admin/secrets` | admin | `{tenant_id, kind, secret_ref, value}` → ينشئ نسخة جديدة (تدوير) ويُلغي القديمة؛ **لا يعيد القيمة أبداً** |
| `POST /v1/admin/secrets/revoke` | admin | `{tenant_id, secret_ref}` |
لا `/docs` ولا `/openapi.json`.

## مسار `/v1/call`
1. توقيع + nonce ← 2. العملية في الكتالوج (`app/catalog.py`) والمعاملات مطابقة تماماً (أي معامل غير معرّف يُرفض؛ الحقول المفروضة مثل `status=PAUSED` لا تُستبدل) ← 3. `api.broker_authorize(ctx, …)` في القاعدة المركزية: توقيع/انتهاء ctx، العميل READY، الدور (قراءة=viewer، كتابة=manager)، ميزة المنصة، **ملكية الحساب الإعلاني**، حالة الاتصال ← 4. حالة السر المحلية (`auth_expired` ⇒ فشل سريع) ← 5. حدّ معدل لكل (عميل،منصة) ← 6. قاطع دائرة ← 7. للكتابة: حجز `idempotency_key` ← 8. فك تشفير السر (AAD مرتبط بالعميل) وحقنه **في الرأس فقط** ← 9. الاستدعاء + إعادة المحاولة ← 10. تصنيف الخطأ، وتنقية الرد من الأسرار ← 11. سجل بلا أسرار.

## عمليات إضافية (P4)
`telegram.send_message` (التوكن بالمسار ولا يُسجَّل؛ المستلم chat_id يجب أن يكون مستخدماً نشطاً لنفس العميل) · `telegram.get_me` · `telegram.get_webhook_info` · `meta.permissions` · `meta.read_pages` · `meta.validate_campaign` (POST مع `execution_options=["validate_only"]` مفروضة + `status=PAUSED`، لا تُنشئ شيئاً). **الاشتراك:** المنتهي/المفقود يُرفض (403 `subscription_expired`) لكل عمليات المنصات، وفترة السماح للقراءة فقط؛ الرد برسالة تيليجرام مسموح دائماً (لرسالة التجديد).

## شكل الرد
نجاح: `{ok:true, data, meta:{attempts, replayed}}`.
فشل: `{ok:false, error:{class, retryable, platform_code?, message}}`.
HTTP: 200 لنتائج المنصة (نجاح أو فشل مُصنَّف)، 400 معاملات، 401 مصادقة/ctx، 403 صلاحية/ملكية/جاهزية، 409 تعارض/قيد التنفيذ، 413 حجم، 424 سر مفقود، 429 حدّ محلي، 500 داخلي.

## فئات الأخطاء
`auth_expired` (لا إعادة؛ يُعلَّم السر والاتصال مركزياً expired) · `permission_denied` · `policy_rejected` · `bad_request` · `not_found` · `rate_limited` (retryable) · `transient` (retryable) · `circuit_open` · `outcome_unknown` (كتابة غامضة: **لا إعادة إرسال أبداً**؛ يُتحقق يدوياً على المنصة) · `in_progress` · `idempotency_conflict` · `secret_missing` · `integrity_error` · `unauthorized` · `forbidden` · `invalid_params` · `unknown_op` · `rate_limited_local`.
جداول الرموز (Meta 190/102/17/368… وTikTok 40104/40105/40100…) **من معرفتي بالتوثيق ولم تُتحقق مقابل حسابات حقيقية** — تُراجَع في P8.

## سياسة إعادة المحاولة
- قراءة: حتى 3 محاولات على `transient`/`rate_limited`/أخطاء الشبكة، تأخير أسّي مع jitter كامل، ويُحترم `Retry-After` (بسقف).
- كتابة: **لا إعادة** إلا إن فشل الاتصال *قبل* الإرسال (ConnectError). مهلة قراءة/انقطاع/5xx بعد الإرسال ⇒ `outcome_unknown`. 4xx/429 ⇒ `failed` ويمكن إعادة المحاولة بنفس المفتاح.
- لا تُتبع إعادة التوجيه (يمنع تسريب رأس التوكن لمضيف آخر).

## حماية المنصات الحقيقية
`Settings.validate()` يرفض الإقلاع إذا أشار أي base URL إلى `graph.facebook.com` أو `business-api.tiktok.com` أو `api.telegram.org`… ما لم يُضبط `BROKER_ALLOW_REAL_PLATFORMS=1` (غير مستعمل في P3).

## التشغيل
`BROKER_SECRETS_FILE` (kek + مفاتيح HMAC)، `BROKER_CENTRAL_DSN` (حساب عضو في `app_broker`)، `BROKER_VAULT_DSN` (عضو في `broker_rw`)، `BROKER_META_BASE_URL`, `BROKER_TIKTOK_BASE_URL`. تدوير KEK: `python -m app.cli rewrap --old … --new …`.
