# تقرير P7 — تجهيز staging (نتائج فعلية فقط)

**النطاق:** ملفات النشر بـ `deploy/` مُجرَّبة **محلياً** على Docker (نفس الملفات التي ستعمل على السيرفر) بمنصات وهمية و`DOMAIN=localhost`. **لم يُشترَ سيرفر ولم يُصرف شيء**؛ لا سيرفر حقيقي ولا شهادة حقيقية ولا منصة حقيقية.

## ما بُني (`deploy/`)
`docker-compose.prod.yml` (Postgres/Broker/n8n/Caddy + mock اختياري) · `Caddyfile` · `bootstrap.sh` · `server-setup.sh` · `backup.sh` · `restore-drill.sh` · `cron/{purge,maintenance,lib}.sh` + `crontab` · `run-readiness.sh` · `canary.sql` · `scan-images.sh` · `RUNBOOK.md`. وتهيئة `ops/add-tenant.py` لأي بيئة (متغيرات PG_CONTAINER/BROKER_NETWORK/BROKER_IMAGE/ENV_FILE/TENANT_DB).

## النتائج المجرَّبة فعلاً (محلياً)
| الفحص | النتيجة |
|---|---|
| `bootstrap.sh --mock` من الصفر، ثم إعادة التشغيل (idempotent) | ✅ 7 workflows، بيانات العميل باقية |
| Caddy: `POST /webhook/tg-ingress` يصل n8n؛ `GET /`, `/healthz`, `/rest/*`, `/webhook-test/*`, `/assets/*`, و`GET` على مسار الـ webhook | ✅ 200 / كلها 404 |
| n8n وPostgres بلا خروج للإنترنت | ✅ محجوبان |
| محرر n8n | ✅ معطّل (404 حتى داخل الحاوية) |
| لا بيانات تجريبية بالقاعدة الجديدة | ✅ (فقط كاناري العزل) |
| منافذ منشورة | ✅ 80/443 لـ Caddy فقط |
| `add-tenant` على staging → جاهزية → READY → webhook عبر TLS | ✅ السر الصحيح يردّ، الخاطئ صمت |
| `backup.sh` + `restore-drill.sh` | ✅ نسخة مشفّرة، استعادة لقاعدتين مؤقتتين، العدّادات تطابق، حذفهما |
| `cron/maintenance.sh` (أقسام) و`cron/purge.sh` | ✅ |
| P4 E2E بعد تعديل ops | ✅ 51/51 + فحص أسرار نظيف |

## عيب حقيقي اكتُشف وأُصلح
**R10 (فحص العزل) يحتاج حساباً إعلانياً لعميل آخر** ⇒ على سيرفر جديد بعميل واحد يبقى `unknown` ولا يترقّى أول عميل أبداً (لم يظهر بـ P4/P5 لوجود عملاء تجريبيين). الحل: «كاناري العزل» (`deploy/canary.sql`): عميل حقيقي بالقاعدة بلا بوت/مالك وحساباه أرقام تركيبية؛ الفحص يمرّ بنفس فحص الملكية (R10=pass مُثبَت بالدليل `ad_account_not_owned_or_disabled`).
وعيبان صغيران: صلاحية مجلد `n8n/generated` (EACCES للحاوية حسب umask) فصُحّحت بـ`chmod` بالسكربتين.

## ما لم يُنجَز / مفتوح (صراحةً)
- سيرفر حقيقي + دومين + Let's Encrypt + rclone/B2: **لم تُجرَّب** (تحتاج موارد منك).
- فحص ثغرات الصور: `deploy/scan-images.sh` جاهز، **لم يُشغَّل** (الصندوق يحجب ghcr.io وDocker Hub 429).
- ~~`setWebhook`~~ **أُنجز (بعد التقرير الأول):** عمليات إدارية بالـ Broker `/v1/admin/telegram/{set-webhook,webhook-info,delete-webhook}` (مفتاح admin فقط؛ غير قابلة للاستدعاء من n8n؛ الرابط مقيَّد بـ`BROKER_WEBHOOK_URL_PREFIX`+معرّف البوت؛ `allowed_updates=[message]`؛ التوكن وsecret_token لا يظهران بالرد/السجل). 10 اختبارات جديدة (Broker 121/121) + mutations 16/16، و`add-tenant --set-webhook` و`deploy/set-webhook.sh`. جُرّب على منصة وهمية فقط؛ **Telegram الحقيقي لم يُجرَّب** (P8). المنصة الوهمية صارت تحفظ حالة الـ webhook، فصار R03 يشترط webhook مضبوطاً فعلاً (وP4 seed يضبطه).
- حد معدل على الـ webhook؛ تنبيه داخلي لفشل cron (مراقبة خارجية فقط).
- P5 الكامل على staging: سكربتاته مربوطة ببيئة P4؛ جرّبت بديلاً (add-tenant + جاهزية + TLS + استعادة). إعادة P5 تحتاج تهيئة السكربتات.
- مسار فشل `maintenance.sh` لم يُختبر بحقن خلل.

## بوابة P7 («نفس النتائج على Staging»)
**غير متحققة بعد**: متحققة محلياً فقط. تُغلَق بعد تشغيل `RUNBOOK.md` على سيرفر حقيقي.
