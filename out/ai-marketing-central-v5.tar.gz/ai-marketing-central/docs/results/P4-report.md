# تقرير P4 (مكتمل) — Workflows مركزية على n8n محلي + منصات وهمية (نتائج فعلية فقط)

**النطاق المنفَّذ:** Docker محلي فقط على شبكة معزولة (`central_internal_only`، بلا خروج للإنترنت). n8n جديد (2.44.6) + Credential Broker + Postgres مركزي + خادم محاكاة لـ Telegram/Meta/TikTok. **لا استدعاء لأي منصة حقيقية، لا بوت حقيقي، لا أسرار حقيقية، لا اتصال بالنظام القديم.** توكنات الاختبار وهمية (`FAKE-*`, `111:AAF…`) تُولَّد وتُحقن محلياً.

## ما بُني
| العنصر | الملف | الحالة |
|---|---|---|
| استدعاء Broker موقَّع (HMAC) | `n8n/workflows/00_util_broker_call.json` (مولَّد من `n8n/build.py`) | ✅ |
| الاستقبال والأوامر لكل البوتات | `10_ingress_commands.json` (`/help /accounts /campaigns /report /create`) | ✅ |
| تقرير مجدول كل ساعة | `20_job_report.json` | ✅ |
| **منفِّذ الجاهزية R01–R15 + ترقية READY + sweep** | `30_readiness.json` (`wf_readiness.py`) | ✅ جديد |
| **Error Workflow عام + اختبار ذاتي** | `90_error_log.json`, `91_selftest_error.json` | ✅ جديد |
| **نظام الاشتراكات** | جدول `core.subscriptions`، `private.sub_state()`، فرض داخل `enter_ctx`، `api_admin.set_subscription` (app_ops فقط + audit)، `sub_state` في `resolve_context`، فلترة `job_contexts`، حد إنشاء يومي | ✅ جديد |
| خادم المحاكاة | `mocks/platforms.py` | ✅ |
| Broker: عمليات تيليجرام وجاهزية | `telegram.send_message/get_me/get_webhook_info`، `meta.permissions/read_pages/validate_campaign`، `mode:"readiness"` | ✅ |

## قواعد الاشتراك المنفَّذة
- **active**: كل شيء. **cancelled**: يبقى فعّالاً حتى نهاية الفترة. **past_due** داخل `grace_days`: قراءة فقط (أي دالة تطلب manager فأعلى تُرفض `subscription_grace_readonly`). **منتهٍ أو بلا صف**: كل شيء مرفوض `subscription_expired` (fail-closed) ما عدا استلام التحديث والرد برسالة «اشتراكك منتهٍ».
- `max_creates_per_day` في `limits` يُفرض قبل أي نداء منصة. التقارير المجدولة تتجاوز العميل المنتهي. تغيير الاشتراك فقط عبر `api_admin.set_subscription` (n8n والعميل لا يملكان صلاحيته).

## كيف تُحدَّد الهوية والصلاحية (كما سبق)
n8n لا يمرّر tenant_id أبداً: يرسل (bot id + secret header + telegram user id) إلى `api.resolve_context` فيعيد توكناً موقَّعاً قصير العمر؛ كل دالة تفتحه بـ `enter_ctx` فتحكم RLS. مستخدم غير مسجّل أو secret خاطئ ⇒ صمت. الإنشاء: فحص مسبق (دور، ملكية، ميزانية، اشتراك، حد يومي) قبل أي نداء خارجي، ثم idempotency، والمنصة تُنشئ PAUSED/DISABLE إجبارياً.

## النتائج الفعلية (من `docs/results/p4/`)
| الاختبار | النتيجة | السجل |
|---|---|---|
| E2E أوامر البوت (E01–E19) | **18/18** | `p4/e2e.log` |
| تقرير مجدول (J01–J04) | **4/4** | `p4/e2e.log` |
| الجاهزية (K00–K12): E ينتقل TESTING→READY عبر بوابة القاعدة، D بلا أسرار ينزل NEEDS_REVIEW، لا إنشاء حقيقي، عزل التوكنات، الدورة الثانية idempotent | **15/15** (2+11+2) | `p4/e2e.log` |
| الاشتراكات عبر n8n (S01–S11) | **11/11** | `p4/e2e.log` |
| Error Workflow (X01–X03) | **3/3** | `p4/e2e.log` |
| فحص الأسرار: n8n SQLite + سجلات 4 حاويات + dump القاعدة + المستودع (مع اختبار إيجابي مضبوط: وضع سر عمداً ⇒ FOUND ثم نظيف) | **clean** | `p4/e2e.log` |
| قاعدة البيانات | **295 ناجح / 0 فاشل** (كانت 246 قبل P4) | `p4/db-tests.log` |
| Broker | **111 ناجح** (كانت 103) | `p4/broker-tests.log` |
| Mutation check | **14/14 killed** (أُضيفت 4 للاشتراك/الجاهزية) | `p4/mutation-check.log` |

## أخطاء وُجدت وأُصلحت أثناء P4 (حقيقية)
- Deadlock في المحاكاة (`Lock` غير reentrant) ⇒ `RLock`.
- عقدة HTTP في n8n 2.44.6: خيارات `neverError`+`responseFormat`/`fullResponse` ترجّع stream خاماً؛ الحل `neverError` فقط. (كان رد تيليجرام يُرسل رغم أن نتيجة Broker تُقرأ خطأً.)
- n8n لا يحتفظ بنص خطأ SQL في `continueRegularOutput` ⇒ `begin_campaign_checked` ترجع `reason` منظّماً.
- معرّفات المنصة الوهمية كانت تتكرر بعد reset ⇒ تصاعدية. عقدة `Create: reply` كانت تنهار في مسار الفشل ⇒ try/catch.
- `CLI n8n execute` لا يُطلق Error Workflow ⇒ الاختبار الذاتي عبر webhook.
- `run_readiness_sweep` احتاج `USAGE` على `api_admin`؛ `set_subscription` احتاج تحديد الـ tenant قبل فحص الوجود (RLS).

## ما لم يُنفَّذ / قيود صريحة (يجب قراءتها)
- **تنبيهات الأخطاء**: الأخطاء تُسجَّل مركزياً منقّاة لكن لا يُرسَل تنبيه لأي جهة (لا قناة/مستلم تشغيل محدد بعد — قرار منك). لذلك R13 يثبت التسجيل والتصنيف فقط.
- **R03**: يتحقق من استجابة `getWebhookInfo` المحاكاة فقط؛ تسجيل الـ webhook الفعلي عند تيليجرام (`setWebhook`) غير مبني ويحتاج بوتاً حقيقياً.
- **R11**: Meta بـ `validate_only` (محاكى). TikTok لا يملك dry-run ⇒ عميل بلا Meta يحصل `warn` ولا يصير READY قبل P8 (حسابات Sandbox).
- **R14**: يغطي error_log + سكربت فحص خارج n8n (`ops/p4-scan-secrets.sh`)، وليس فحصاً داخل Workflow.
- **R10** يحتاج حساباً إعلانياً لعميل آخر موجوداً؛ مع عميل واحد فقط ينتج `unknown` (لا يصير READY).
- **الاشتراكات**: لا فوترة/دفع/تجديد تلقائي ولا واجهة أو أمر إداري؛ التعديل عبر دالة قاعدة بيانات بيد التشغيل. لا إشعار قبل الانتهاء.
- المهام تعالج حتى 25 tenant بالدفعة (لا ترقيم صفحات). صيانة الأقسام (`ensure_partitions`) ما زالت يدوية، غير مجدولة.
- لا بوت تيليجرام حقيقي بعد؛ كل شيء عبر webhook وهمي ومحاكاة. جداول تصنيف أخطاء المنصات الحقيقية غير متحقق منها.

## إعادة التشغيل محلياً
```
./ops/p4-up.sh && ./ops/p4-seed.sh && ./ops/p4-import.sh   # مرة واحدة
./ops/p4-e2e.sh                                            # يعيد الحالة ثم يشغّل كل الاختبارات (~3 دقائق)
```
