#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
printf '#!/usr/bin/env bash\nexec python3 scripts/scan_repo.py --staged\n' > .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit scripts/*.sh scripts/*.py
echo "pre-commit hook مثبّت"
