#!/usr/bin/env bash
# يجهّز .venv المحلي بحسب broker/requirements.txt (يُعاد التثبيت فقط عند تغيّر الملف). يطبع مسار venv.
set -euo pipefail
cd "$(dirname "$0")/.."
V="${BROKER_VENV:-$PWD/.venv}"
H=$(sha256sum broker/requirements.txt | cut -c1-16)
if [ ! -x "$V/bin/python" ] || [ "$(cat "$V/.reqs_hash" 2>/dev/null)" != "$H" ]; then
  [ -x "$V/bin/python" ] || python3 -m venv "$V"
  "$V/bin/pip" install -q -r broker/requirements.txt >&2
  echo "$H" > "$V/.reqs_hash"
fi
echo "$V"
