#!/usr/bin/env python3
"""فاحص ما قبل الالتزام: (1) لا أسرار، (2) لا أي معرّف من النظام القديم.
المعرّفات القديمة محفوظة كبصمات sha256 فقط (scripts/old_system_denylist.sha256)، فلا تظهر الكلمات نفسها في المستودع.
الاستعمال: scan_repo.py [--staged | ملفات...]  (بدونها: كل الملفات المتتبَّعة). يخرج 1 عند أي مخالفة.
سطر يحمل العلامة `scan:allow` يُستثنى (لقيم وهمية في الاختبارات فقط)."""
import hashlib, pathlib, re, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
DENY = {l.strip() for l in (ROOT / "scripts/old_system_denylist.sha256").read_text().splitlines() if l and not l.startswith("#")}
SECRET = [
    ("telegram-token", re.compile(r"\b\d{8,10}:[A-Za-z0-9_-]{30,}\b")),
    ("meta-token", re.compile(r"\bEA[A-Za-z0-9]{20,}")),
    ("hex40-token", re.compile(r"\b[0-9a-f]{40}\b")),
    ("private-key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("bearer", re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]{20,}")),
    ("aws-key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("assigned-secret", re.compile(r"(?i)\b(?:password|passwd|secret|token|api[_-]?key)\w*\s*[:=]\s*['\"]?(?!change_me|CHANGE_ME|\$\{|<|xxx|your_|example|placeholder)[A-Za-z0-9+/_=-]{24,}")),
]
TOKEN = re.compile(r"[A-Za-z0-9_]+")
SKIP_SUFFIX = {".png", ".jpg", ".gz", ".sha256"}


def files(argv):
    if argv and argv[0] == "--staged":
        out = subprocess.check_output(["git", "diff", "--cached", "--name-only", "--diff-filter=ACM"], cwd=ROOT, text=True)
    elif argv:
        return [pathlib.Path(a).resolve() for a in argv]
    else:
        out = subprocess.check_output(["git", "ls-files"], cwd=ROOT, text=True)
    return [ROOT / f for f in out.splitlines() if f]


def main():
    bad = 0
    for f in files(sys.argv[1:]):
        if not f.is_file() or f.suffix in SKIP_SUFFIX:
            continue
        if f.name in (".env",) or ".secrets" in f.parts:
            print(f"BLOCK {f}: ملف أسرار لا يجوز تتبّعه"); bad += 1; continue
        try:
            lines = f.read_text(encoding="utf-8").splitlines()
        except UnicodeDecodeError:
            print(f"BLOCK {f}: ملف ثنائي غير متوقع"); bad += 1; continue
        for n, line in enumerate(lines, 1):
            if "scan:allow" in line:
                continue
            for name, rx in SECRET:
                if rx.search(line):
                    print(f"BLOCK {f.relative_to(ROOT)}:{n} نمط سر ({name})"); bad += 1
            for tok in TOKEN.findall(line):
                if hashlib.sha256(tok.lower().encode()).hexdigest() in DENY:
                    print(f"BLOCK {f.relative_to(ROOT)}:{n} معرّف من النظام القديم"); bad += 1
    print("scan: نظيف" if not bad else f"scan: {bad} مخالفة")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
