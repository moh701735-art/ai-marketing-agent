#!/usr/bin/env python3
"""منصات وهمية (Telegram + Meta + TikTok) بخادم واحد لاختبارات P4/P5. لا اتصال بأي منصة حقيقية.
مسارات المنصات:  /telegram/bot<TOKEN>/sendMessage   /meta/<ad_account>/campaigns ...   /tiktok/open_api/v1.3/...
مسارات التحكم:   GET /__control/calls | POST /__control/reset | POST /__control/fail {"platform","n","status","body"}
التحقق من التوكن: Telegram `<id>:<hash>`; Meta Bearer FAKE-*; TikTok Access-Token FAKE-* (أي شيء آخر = 401 بشكل المنصة)."""
import json, re, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

WEBHOOKS = {}      # bot token -> {url, secret, allowed_updates}
LOCK = threading.RLock()
CALLS, FAILS, CAMPAIGNS = [], {}, {}
SEQ = [int(time.time()) * 10]


def reset():
    with LOCK:
        CALLS.clear(); FAILS.clear(); CAMPAIGNS.clear()   # SEQ يبقى تصاعدياً (معرّفات المنصة الحقيقية فريدة)


def next_id():
    with LOCK:
        SEQ[0] += 1
        return str(SEQ[0])


def camps(acct):
    with LOCK:
        return CAMPAIGNS.setdefault(acct, [{"id": f"{acct}-c1", "name": f"Mock campaign for {acct}", "status": "ACTIVE", "effective_status": "ACTIVE", "daily_budget": "10000"}])


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send_json(self, status, obj, headers=None):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(status); self.send_header("content-type", "application/json; charset=utf-8"); self.send_header("content-length", str(len(b)))
        for k, v in (headers or {}).items():
            self.send_header(k, str(v))
        self.end_headers(); self.wfile.write(b)

    def body(self):
        n = int(self.headers.get("content-length") or 0)
        raw = self.rfile.read(n) if n else b""
        try:
            return json.loads(raw) if raw else {}
        except Exception:
            return {"_raw": raw.decode(errors="replace")}

    def handle_any(self, method):
        u = urlparse(self.path); path, q = u.path, {k: v[0] for k, v in parse_qs(u.query).items()}
        data = self.body() if method == "POST" else {}
        if path.startswith("/__control/"):
            return self.control(method, path, data)
        plat = path.split("/")[1] if path.count("/") >= 1 else ""
        entry = {"t": time.time(), "platform": plat, "method": method, "path": path, "query": q, "body": data,
                 "auth": self.headers.get("authorization", ""), "access_token": self.headers.get("access-token", "")}
        with LOCK:
            CALLS.append(entry)
            f = FAILS.get(plat)
            hit = None
            if f and f["n"] > 0:
                if f.get("skip", 0) > 0:
                    f["skip"] -= 1                      # اسمح بعدد من النداءات أولاً ثم ابدأ الفشل
                else:
                    f["n"] -= 1; hit = dict(f)
        if hit:
            if hit.get("delay"):
                time.sleep(hit["delay"])                # خارج القفل: محاكاة مهلة/بطء
            return self.send_json(hit["status"], hit["body"], hit.get("headers"))
        if plat == "telegram":
            return self.telegram(path, data)
        if plat == "meta":
            return self.meta(method, path, q, data)
        if plat == "tiktok":
            return self.tiktok(method, path, q, data)
        self.send_json(404, {"error": "unknown platform path"})

    def control(self, method, path, data):
        if path == "/__control/calls":
            with LOCK:
                return self.send_json(200, {"calls": list(CALLS)})
        if path == "/__control/reset":
            reset(); return self.send_json(200, {"ok": True})
        if path == "/__control/fail":
            with LOCK:
                FAILS[data["platform"]] = {"n": int(data.get("n", 1)), "status": int(data.get("status", 500)), "body": data.get("body", {"error": "mock failure"}),
                                           "delay": float(data.get("delay", 0)), "headers": data.get("headers", {}), "skip": int(data.get("skip", 0))}
            return self.send_json(200, {"ok": True})
        self.send_json(404, {})

    # ───── Telegram ─────
    def telegram(self, path, data):
        m = re.match(r"^/telegram/bot(\d+:[A-Za-z0-9_-]{20,})/(\w+)$", path)
        if not m:
            return self.send_json(401, {"ok": False, "error_code": 401, "description": "Unauthorized"})
        if m.group(2) == "sendMessage":
            if not data.get("chat_id") or not str(data.get("text", "")).strip():
                return self.send_json(400, {"ok": False, "error_code": 400, "description": "Bad Request: message text is empty"})
            return self.send_json(200, {"ok": True, "result": {"message_id": int(next_id()), "chat": {"id": data["chat_id"]}, "text": data["text"]}})
        if m.group(2) == "setWebhook":
            url = str(data.get("url", ""))
            if not url.startswith("https://"):
                return self.send_json(400, {"ok": False, "error_code": 400, "description": "Bad Request: bad webhook: HTTPS URL must be provided for webhook"})
            with LOCK:
                WEBHOOKS[m.group(1)] = {"url": url, "secret": data.get("secret_token", ""), "allowed_updates": data.get("allowed_updates", [])}
            return self.send_json(200, {"ok": True, "result": True, "description": "Webhook was set"})
        if m.group(2) == "deleteWebhook":
            with LOCK:
                WEBHOOKS.pop(m.group(1), None)
            return self.send_json(200, {"ok": True, "result": True, "description": "Webhook was deleted"})
        if m.group(2) == "getWebhookInfo":
            w = WEBHOOKS.get(m.group(1))      # لا نُرجع secret_token أبداً (كما تيليجرام الحقيقي)
            return self.send_json(200, {"ok": True, "result": {"url": w["url"] if w else "", "has_custom_certificate": False, "pending_update_count": 0,
                                                              **({"allowed_updates": w["allowed_updates"]} if w else {})}})
        if m.group(2) == "getMe":
            return self.send_json(200, {"ok": True, "result": {"id": int(m.group(1).split(':')[0]), "is_bot": True, "username": "mock_bot"}})
        self.send_json(404, {"ok": False, "error_code": 404, "description": "Not Found"})

    # ───── Meta ─────
    def meta(self, method, path, q, data):
        if not self.headers.get("authorization", "").startswith("Bearer FAKE-"):
            return self.send_json(400, {"error": {"message": "Invalid OAuth access token.", "type": "OAuthException", "code": 190}})
        parts = path.split("/")[2:]
        if parts == ["me"]:
            return self.send_json(200, {"id": "mock-user", "name": "Mock User"})
        if parts == ["me", "permissions"]:
            return self.send_json(200, {"data": [{"permission": p, "status": "granted"} for p in ("ads_management", "ads_read", "business_management", "pages_show_list")]})
        if parts == ["me", "accounts"]:
            return self.send_json(200, {"data": [{"id": "mock-page-1", "name": "Mock Page", "instagram_business_account": {"id": "mock-ig-1"}}]})
        acct = parts[0]
        if len(parts) == 1:
            return self.send_json(200, {"id": acct, "name": f"Account {acct}", "account_status": 1, "currency": "USD", "balance": "0"})
        if parts[1] == "campaigns" and method == "GET":
            return self.send_json(200, {"data": camps(acct)})
        if parts[1] == "campaigns" and method == "POST" and "validate_only" in (data.get("execution_options") or []):
            return self.send_json(200, {"success": True})          # validate_only: لا إنشاء
        if parts[1] == "campaigns" and method == "POST":
            cid = next_id()
            with LOCK:
                camps(acct).append({"id": cid, "name": data.get("name"), "status": data.get("status"), "effective_status": data.get("status"), "objective": data.get("objective")})
            return self.send_json(200, {"id": cid})
        if parts[1] == "insights":
            return self.send_json(200, {"data": [{"spend": "12.34", "impressions": "1500", "clicks": "42", "actions": [{"action_type": "onsite_conversion.messaging_conversation_started_7d", "value": "5"}]}]})
        self.send_json(404, {"error": {"message": "Unknown path", "code": 100}})

    # ───── TikTok ─────
    def tiktok(self, method, path, q, data):
        if not self.headers.get("access-token", "").startswith("FAKE-"):
            return self.send_json(200, {"code": 40105, "message": "Access token is invalid or expired", "data": {}})
        p = path.replace("/tiktok/open_api/v1.3", "")
        adv = q.get("advertiser_id") or data.get("advertiser_id") or ""
        if p == "/advertiser/info/":
            ids = json.loads(q.get("advertiser_ids", "[]"))
            return self.send_json(200, {"code": 0, "message": "OK", "data": {"list": [{"advertiser_id": i, "name": f"Mock {i}", "status": "STATUS_ENABLE", "balance": 0, "currency": "USD"} for i in ids]}})
        if p == "/campaign/get/":
            return self.send_json(200, {"code": 0, "message": "OK", "data": {"list": camps("tt" + adv), "page_info": {"total_number": len(camps("tt" + adv))}}})
        if p == "/campaign/create/" and method == "POST":
            cid = next_id()
            with LOCK:
                camps("tt" + adv).append({"campaign_id": cid, "campaign_name": data.get("campaign_name"), "operation_status": data.get("operation_status")})
            return self.send_json(200, {"code": 0, "message": "OK", "data": {"campaign_id": cid}})
        if p == "/report/integrated/get/":
            return self.send_json(200, {"code": 0, "message": "OK", "data": {"list": [{"dimensions": {"campaign_id": f"tt{adv}-c1"}, "metrics": {"spend": "3.21", "impressions": "900", "clicks": "11", "currency": "USD"}}]}})
        self.send_json(200, {"code": 40002, "message": "unknown path", "data": {}})

    def do_GET(self):
        self.handle_any("GET")

    def do_POST(self):
        self.handle_any("POST")


if __name__ == "__main__":
    ThreadingHTTPServer(("0.0.0.0", 8080), H).serve_forever()
