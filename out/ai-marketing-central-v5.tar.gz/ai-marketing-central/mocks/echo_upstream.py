#!/usr/bin/env python3
"""منصة وهمية بسيطة لاختبار الدخان (smoke) فقط: تسجّل ما استلمته في /last وتردّ ببيانات ثابتة. ليست mock الكاملة (P4)."""
import json
from http.server import BaseHTTPRequestHandler, HTTPServer

LAST = {}


class H(BaseHTTPRequestHandler):
    def _go(self):
        n = int(self.headers.get("content-length") or 0)
        body = self.rfile.read(n) if n else b""
        if self.path == "/last":
            out = json.dumps(LAST).encode()
        else:
            LAST.update(method=self.command, path=self.path, headers={k.lower(): v for k, v in self.headers.items()}, body=body.decode(errors="replace"))
            out = json.dumps({"data": [{"id": "mock-1"}], "code": 0}).encode()
        self.send_response(200); self.send_header("content-type", "application/json"); self.send_header("content-length", str(len(out))); self.end_headers(); self.wfile.write(out)
    do_GET = do_POST = _go

    def log_message(self, *a):
        pass


HTTPServer(("0.0.0.0", 8080), H).serve_forever()
