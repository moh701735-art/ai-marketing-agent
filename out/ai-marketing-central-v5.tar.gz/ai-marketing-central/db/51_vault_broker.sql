-- 51_vault_broker.sql : جداول الـ Broker التشغيلية في قاعدة vault (لا تُنفَّذ بقاعدة التطبيق).
\set ON_ERROR_STOP on
SET ROLE broker_rw;

-- حالة السر محلياً (للفشل السريع بدون استدعاء المنصة): ok | auth_expired | permission_denied
CREATE TABLE vault.secret_state (
  secret_ref text PRIMARY KEY REFERENCES vault.secret_refs (secret_ref),
  state text NOT NULL CHECK (state IN ('ok','auth_expired','permission_denied')),
  since timestamptz NOT NULL DEFAULT now(),
  detail text
);
-- منع إعادة الإرسال عبر عدة عمليات (الـ nonce يُسجَّل هنا)
CREATE TABLE vault.used_nonces (
  key_id text NOT NULL, nonce text NOT NULL, at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (key_id, nonce)
);
CREATE INDEX ON vault.used_nonces (at);
-- طلبات الكتابة (إنشاء حملة...): نفس المفتاح لا يُرسل للمنصة مرتين
CREATE TABLE vault.write_requests (
  tenant_id uuid NOT NULL, idempotency_key text NOT NULL CHECK (length(idempotency_key) >= 16),
  request_hash bytea NOT NULL, platform text NOT NULL, op text NOT NULL,
  state text NOT NULL CHECK (state IN ('executing','succeeded','failed','unknown')),
  response jsonb, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, idempotency_key)
);
-- سجل المكالمات: قسم افتراضي + إنشاء مسبق للأشهر القادمة
CREATE TABLE vault.api_call_log_default PARTITION OF vault.api_call_log DEFAULT;
CREATE FUNCTION vault.ensure_log_partitions(p_months_ahead int DEFAULT 2) RETURNS int
LANGUAGE plpgsql AS $$
DECLARE m date; n int := 0; nm text;
BEGIN
  FOR i IN 0..p_months_ahead LOOP
    m := (date_trunc('month', now()) + make_interval(months => i))::date;
    nm := 'api_call_log_' || to_char(m, 'YYYYMM');
    IF to_regclass('vault.' || nm) IS NULL THEN
      EXECUTE format('CREATE TABLE vault.%I PARTITION OF vault.api_call_log FOR VALUES FROM (%L) TO (%L)', nm, m, (m + interval '1 month')::date);
      n := n + 1;
    END IF;
  END LOOP;
  RETURN n;
END $$;
SELECT vault.ensure_log_partitions(2);
RESET ROLE;
