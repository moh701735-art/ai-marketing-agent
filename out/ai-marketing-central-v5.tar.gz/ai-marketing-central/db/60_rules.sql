-- 60_rules.sql : قواعد مراقبة التكلفة للحملات (تنبيه عند مستويات، وإيقاف تلقائي عند تجاوز سقف) + تفعيل مضبوط.
-- ترقية آمنة لقاعدة قائمة (idempotent): تُطبَّق بعد 10..40. لا تمس بيانات موجودة. الإيقاف الآلي يخفّض الصرف فقط؛ التفعيل لا يتم إلا بأمر صريح من مستخدم.
\set ON_ERROR_STOP on
SET ROLE app_owner;
SET search_path = core, private, ext, public;

ALTER TABLE core.campaigns
  ADD COLUMN IF NOT EXISTS rule_state text NOT NULL DEFAULT 'off' CHECK (rule_state IN ('off', 'watching', 'stopped')),
  ADD COLUMN IF NOT EXISTS rule_alerts numeric[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS rule_stop numeric CHECK (rule_stop IS NULL OR rule_stop > 0),
  ADD COLUMN IF NOT EXISTS rule_last_level numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS activated_at timestamptz;
CREATE INDEX IF NOT EXISTS campaigns_watch_idx ON core.campaigns (tenant_id) WHERE rule_state = 'watching';

-- حالة مراجعة TikTok للإعلانات (تنبيه الرفض): '' غير معروف/سليم | 'rejected' نُبّه المالك. التنبيه مرة واحدة لكل رفض.
ALTER TABLE core.campaigns
  ADD COLUMN IF NOT EXISTS review_status text NOT NULL DEFAULT '' CHECK (review_status IN ('', 'rejected')),
  ADD COLUMN IF NOT EXISTS review_alerted_at timestamptz,
  ADD COLUMN IF NOT EXISTS appeal_count int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS appeal_fails int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS appeal_last_at timestamptz;

-- بدء المراقبة عند التفعيل (يُستدعى بعد نجاح تفعيل الحملة بالمنصة). manager فما فوق.
CREATE OR REPLACE FUNCTION api.start_watch(p_ctx text, p_platform text, p_external_id text, p_alerts numeric[], p_stop numeric)
RETURNS TABLE (ad_account text, name text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'manager');
  IF p_stop IS NOT NULL AND p_stop <= 0 THEN RAISE EXCEPTION 'bad_rule' USING ERRCODE = '22023'; END IF;
  IF coalesce(array_length(p_alerts, 1), 0) > 10 OR EXISTS (SELECT 1 FROM unnest(coalesce(p_alerts, '{}')) a WHERE a IS NULL OR a <= 0) THEN
    RAISE EXCEPTION 'bad_rule' USING ERRCODE = '22023';
  END IF;
  RETURN QUERY
    UPDATE core.campaigns c SET rule_state = 'watching', rule_alerts = coalesce(p_alerts, '{}'), rule_stop = p_stop, rule_last_level = 0,
           activated_at = now(), status = 'ACTIVE'
     WHERE c.platform = p_platform::core.platform AND c.external_id = p_external_id
     RETURNING c.ad_account_external_id, c.name;
  IF NOT FOUND THEN RAISE EXCEPTION 'campaign_not_found' USING ERRCODE = '22023'; END IF;
END $$;

-- الحملات تحت المراقبة لـ tenant (يُستدعى بسياق system من job المراقبة).
CREATE OR REPLACE FUNCTION api.watch_list(p_ctx text)
RETURNS TABLE (platform text, ad_account text, external_id text, name text, activated_at timestamptz, rule_alerts numeric[], rule_stop numeric, rule_last_level numeric)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'viewer');
  RETURN QUERY SELECT c.platform::text, c.ad_account_external_id, c.external_id, c.name, c.activated_at, c.rule_alerts, c.rule_stop, c.rule_last_level
    FROM core.campaigns c WHERE c.rule_state = 'watching' ORDER BY c.created_at;
END $$;

-- تحديث حالة القاعدة: watching (مع آخر مستوى تنبيه) | stopped (إيقاف تلقائي) | off (إيقاف يدوي).
CREATE OR REPLACE FUNCTION api.rule_update(p_ctx text, p_platform text, p_external_id text, p_level numeric, p_state text)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
DECLARE n int;
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'manager');
  IF p_state NOT IN ('watching', 'stopped', 'off') THEN RAISE EXCEPTION 'bad_rule' USING ERRCODE = '22023'; END IF;
  UPDATE core.campaigns c SET rule_state = p_state, rule_last_level = greatest(c.rule_last_level, coalesce(p_level, 0)),
         status = CASE WHEN p_state IN ('stopped', 'off') THEN 'PAUSED' ELSE c.status END
   WHERE c.platform = p_platform::core.platform AND c.external_id = p_external_id;
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n = 1;
END $$;

-- حملات تيك توك التي أنشأها البوت مؤخراً (آخر 14 يوماً) لفحص مراجعة الإعلانات. يُستدعى بسياق system من job المراجعة.
DROP FUNCTION IF EXISTS api.review_list(text);
CREATE FUNCTION api.review_list(p_ctx text)
RETURNS TABLE (platform text, ad_account text, external_id text, name text, review_status text, appeal_count int, appeal_fails int, appeal_last_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'viewer');
  RETURN QUERY SELECT c.platform::text, c.ad_account_external_id, c.external_id, c.name, c.review_status, c.appeal_count, c.appeal_fails, c.appeal_last_at
    FROM core.campaigns c WHERE c.platform = 'tiktok' AND c.created_at > now() - interval '14 days' ORDER BY c.created_at DESC LIMIT 200;
END $$;

CREATE OR REPLACE FUNCTION api.review_update(p_ctx text, p_platform text, p_external_id text, p_status text)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
DECLARE n int;
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'manager');
  IF p_status NOT IN ('', 'rejected') THEN RAISE EXCEPTION 'bad_rule' USING ERRCODE = '22023'; END IF;
  UPDATE core.campaigns c SET review_status = p_status, review_alerted_at = CASE WHEN p_status = 'rejected' THEN now() ELSE c.review_alerted_at END,
         appeal_count = CASE WHEN p_status = '' THEN 0 ELSE c.appeal_count END, appeal_fails = CASE WHEN p_status = '' THEN 0 ELSE c.appeal_fails END
   WHERE c.platform = p_platform::core.platform AND c.external_id = p_external_id;
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n = 1;
END $$;

-- تسجيل محاولة طعن: ok=true يزيد العدّاد، false يزيد الإخفاقات؛ يضع الحملة rejected ويحدّث وقت آخر محاولة.
CREATE OR REPLACE FUNCTION api.appeal_update(p_ctx text, p_platform text, p_external_id text, p_ok boolean)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
DECLARE n int;
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'manager');
  UPDATE core.campaigns c SET review_status = 'rejected', review_alerted_at = COALESCE(c.review_alerted_at, now()), appeal_last_at = now(),
         appeal_count = c.appeal_count + CASE WHEN p_ok THEN 1 ELSE 0 END, appeal_fails = c.appeal_fails + CASE WHEN p_ok THEN 0 ELSE 1 END
   WHERE c.platform = p_platform::core.platform AND c.external_id = p_external_id;
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n = 1;
END $$;

ALTER FUNCTION api.start_watch(text, text, text, numeric[], numeric) OWNER TO app_owner;
ALTER FUNCTION api.watch_list(text) OWNER TO app_owner;
ALTER FUNCTION api.rule_update(text, text, text, numeric, text) OWNER TO app_owner;
ALTER FUNCTION api.review_list(text) OWNER TO app_owner;
ALTER FUNCTION api.review_update(text, text, text, text) OWNER TO app_owner;
ALTER FUNCTION api.appeal_update(text, text, text, boolean) OWNER TO app_owner;
REVOKE ALL ON FUNCTION api.start_watch(text, text, text, numeric[], numeric), api.watch_list(text), api.rule_update(text, text, text, numeric, text), api.review_list(text), api.review_update(text, text, text, text), api.appeal_update(text, text, text, boolean) FROM PUBLIC;
-- أقل صلاحية: التفاعلي (التفعيل/الإيقاف اليدوي) يبدأ ويحدّث؛ job المراقبة يقرأ القائمة ويحدّث الحالة.
GRANT EXECUTE ON FUNCTION api.start_watch(text, text, text, numeric[], numeric), api.rule_update(text, text, text, numeric, text) TO app_runtime;
GRANT EXECUTE ON FUNCTION api.watch_list(text), api.rule_update(text, text, text, numeric, text), api.review_list(text), api.review_update(text, text, text, text), api.appeal_update(text, text, text, boolean) TO app_jobs;
-- طلبات الاستمارات المُرسلة للمالك (منع التكرار). يُسجَّل المفتاح عند الإرسال فقط؛ الصفوف تُحذف بعد 90 يوماً بالتنظيف الدوري.
CREATE TABLE IF NOT EXISTS core.leads_seen (
  tenant_id uuid NOT NULL REFERENCES core.tenants ON DELETE CASCADE,
  lead_key  text NOT NULL CHECK (length(lead_key) BETWEEN 1 AND 200),
  seen_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, lead_key)
);
ALTER TABLE core.leads_seen ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.leads_seen FORCE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'core' AND tablename = 'leads_seen' AND policyname = 'tenant_isolation') THEN
    CREATE POLICY tenant_isolation ON core.leads_seen USING (tenant_id = private.cur_tenant()) WITH CHECK (tenant_id = private.cur_tenant());
  END IF;
END $$;

-- يعلّم المفاتيح كمُرسلة ويرجع الجديدة فقط (التي لم تُرسل من قبل). حتى 300 مفتاح بالمرة.
CREATE OR REPLACE FUNCTION api.leads_mark(p_ctx text, p_keys text[])
RETURNS text[]
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
DECLARE r text[];
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'manager');
  IF p_keys IS NULL OR cardinality(p_keys) = 0 THEN RETURN '{}'; END IF;
  IF cardinality(p_keys) > 300 THEN RAISE EXCEPTION 'too_many_keys' USING ERRCODE = '22023'; END IF;
  WITH ins AS (
    INSERT INTO core.leads_seen (tenant_id, lead_key)
    SELECT private.cur_tenant(), k FROM (SELECT DISTINCT left(x, 200) AS k FROM unnest(p_keys) x WHERE length(x) > 0) u
    ON CONFLICT DO NOTHING RETURNING lead_key)
  SELECT COALESCE(array_agg(lead_key), '{}') INTO r FROM ins;
  RETURN r;
END $$;
ALTER FUNCTION api.leads_mark(text, text[]) OWNER TO app_owner;
REVOKE ALL ON FUNCTION api.leads_mark(text, text[]) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION api.leads_mark(text, text[]) TO app_jobs;
-- تراجع عن تعليم مفاتيح (إذا فشل إرسالها كلها): يُعاد إرسالها بالدورة القادمة بدل أن تضيع.
CREATE OR REPLACE FUNCTION api.leads_unmark(p_ctx text, p_keys text[])
RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
DECLARE n int;
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'manager');
  IF p_keys IS NULL OR cardinality(p_keys) = 0 OR cardinality(p_keys) > 300 THEN RETURN 0; END IF;
  DELETE FROM core.leads_seen WHERE lead_key = ANY (p_keys);
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END $$;
ALTER FUNCTION api.leads_unmark(text, text[]) OWNER TO app_owner;
REVOKE ALL ON FUNCTION api.leads_unmark(text, text[]) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION api.leads_unmark(text, text[]) TO app_jobs;
RESET ROLE;
