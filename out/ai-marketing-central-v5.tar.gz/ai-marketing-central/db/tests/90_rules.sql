-- 90_rules.sql : قواعد مراقبة التكلفة (start_watch / watch_list / rule_update): الصلاحيات والعزل بين العملاء.
SELECT encode(ext.digest('secret-a','sha256'),'hex') AS ha, encode(ext.digest('secret-b','sha256'),'hex') AS hb \gset
SET ROLE app_runtime;
SELECT ctx AS a_viewer FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1002) \gset
SELECT ctx AS a_mgr    FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1003) \gset
SELECT ctx AS b_owner  FROM api.resolve_context('botBBBBBBBBBBBBBBBBBBBBBBBB', decode(:'hb','hex'), 2001) \gset
SELECT t.ok('RUL-00 manager A records a tiktok campaign', api.record_campaign(:'a_mgr','tiktok','tt_A1','9990001','حملة اختبار','WEB_CONVERSIONS',20) IS NOT NULL);
SELECT t.raises('RUL-01 viewer cannot start a watch', format('SELECT * FROM api.start_watch(%L,%L,%L,%L,%L)', :'a_viewer','tiktok','9990001','{0.15,0.2}'::numeric[],0.3), '42501', 'forbidden');
SELECT t.raises('RUL-02 B cannot watch A campaign', format('SELECT * FROM api.start_watch(%L,%L,%L,%L,%L)', :'b_owner','tiktok','9990001','{0.15}'::numeric[],0.3), '22023', 'campaign_not_found');
SELECT t.raises('RUL-03 negative stop refused', format('SELECT * FROM api.start_watch(%L,%L,%L,%L,%L)', :'a_mgr','tiktok','9990001','{0.15}'::numeric[],-1), '22023', 'bad_rule');
SELECT t.raises('RUL-04 non-positive alert refused', format('SELECT * FROM api.start_watch(%L,%L,%L,%L,%L)', :'a_mgr','tiktok','9990001','{0.15,0}'::numeric[],0.3), '22023', 'bad_rule');
SELECT t.ok('RUL-05 manager A starts a watch: returns account + name',
  (SELECT ad_account||'|'||name FROM api.start_watch(:'a_mgr','tiktok','9990001','{0.15,0.2,0.3}'::numeric[],0.3)) = 'tt_A1|حملة اختبار');
RESET ROLE;
SET ROLE app_jobs;
SELECT ctx AS a_sys FROM api.job_contexts('schedule',10) WHERE tenant_id='a0000000-0000-0000-0000-000000000001' \gset
SELECT ctx AS b_sys FROM api.job_contexts('schedule',10) WHERE tenant_id='b0000000-0000-0000-0000-000000000001' \gset
SELECT t.ok('RUL-06 system job of A sees the watched campaign with its thresholds',
  (SELECT external_id||'|'||rule_stop::text||'|'||array_length(rule_alerts,1)::text||'|'||rule_last_level::text FROM api.watch_list(:'a_sys')) = '9990001|0.3|3|0');
SELECT t.ok('RUL-07 system job of B sees nothing (isolation)', (SELECT count(*) FROM api.watch_list(:'b_sys')) = 0);
SELECT t.ok('RUL-08 alert level is recorded', api.rule_update(:'a_sys','tiktok','9990001',0.15,'watching'));
SELECT t.ok('RUL-09 level never goes down', (SELECT rule_last_level FROM api.watch_list(:'a_sys')) = 0.15 AND api.rule_update(:'a_sys','tiktok','9990001',0.05,'watching')
  AND (SELECT rule_last_level FROM api.watch_list(:'a_sys')) = 0.15);
SELECT t.ok('RUL-10 B system cannot update A campaign', NOT api.rule_update(:'b_sys','tiktok','9990001',0.3,'stopped'));
SELECT t.raises('RUL-11 bad state refused', format('SELECT api.rule_update(%L,%L,%L,%s,%L)', :'a_sys','tiktok','9990001',0.3,'hacked'), '22023', 'bad_rule');
SELECT t.ok('RUL-12 auto-stop marks stopped + PAUSED and leaves the watch list',
  api.rule_update(:'a_sys','tiktok','9990001',0.31,'stopped') AND (SELECT count(*) FROM api.watch_list(:'a_sys')) = 0);
RESET ROLE;
SELECT t.ok('RUL-13 campaign row is PAUSED/stopped after auto-stop', (SELECT status||'|'||rule_state FROM core.campaigns WHERE external_id='9990001') = 'PAUSED|stopped');

-- ───── مراجعة الإعلانات (تنبيه الرفض) ─────
SET ROLE app_runtime;
SELECT ctx AS a_mgr2 FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1003) \gset
SELECT t.ok('REV-00 manager A records a second tiktok campaign', api.record_campaign(:'a_mgr2','tiktok','tt_A1','9990002','حملة مراجعة','LEAD_GENERATION',20) IS NOT NULL);
RESET ROLE;
SET ROLE app_jobs;
SELECT ctx AS a_sys2 FROM api.job_contexts('schedule',10) WHERE tenant_id='a0000000-0000-0000-0000-000000000001' \gset
SELECT ctx AS b_sys2 FROM api.job_contexts('schedule',10) WHERE tenant_id='b0000000-0000-0000-0000-000000000001' \gset
SELECT t.ok('REV-01 review_list returns A recent tiktok campaigns with empty status', (SELECT count(*) FROM api.review_list(:'a_sys2') WHERE external_id IN ('9990001','9990002') AND review_status = '') = 2);
SELECT t.ok('REV-02 B sees none of A campaigns', (SELECT count(*) FROM api.review_list(:'b_sys2') WHERE external_id LIKE '99900%') = 0);
SELECT t.ok('REV-03 mark rejected', api.review_update(:'a_sys2','tiktok','9990002','rejected') AND (SELECT review_status FROM api.review_list(:'a_sys2') WHERE external_id = '9990002') = 'rejected');
SELECT t.ok('REV-04 B cannot touch A campaign', NOT api.review_update(:'b_sys2','tiktok','9990002',''));
SELECT t.raises('REV-05 bad status refused', format('SELECT api.review_update(%L,%L,%L,%L)', :'a_sys2','tiktok','9990002','hacked'), '22023', 'bad_rule');
SELECT t.ok('REV-06 clear back to empty', api.review_update(:'a_sys2','tiktok','9990002','') AND (SELECT review_status FROM api.review_list(:'a_sys2') WHERE external_id = '9990002') = '');
SELECT t.ok('REV-08 appeal_update counts ok and fails, marks rejected', api.appeal_update(:'a_sys2','tiktok','9990002',true) AND api.appeal_update(:'a_sys2','tiktok','9990002',false)
  AND (SELECT appeal_count = 1 AND appeal_fails = 1 AND review_status = 'rejected' AND appeal_last_at IS NOT NULL FROM api.review_list(:'a_sys2') WHERE external_id = '9990002'));
SELECT t.ok('REV-09 B cannot touch A appeal counters', NOT api.appeal_update(:'b_sys2','tiktok','9990002',true));
SELECT t.ok('REV-10 recovery resets appeal counters', api.review_update(:'a_sys2','tiktok','9990002','') AND (SELECT appeal_count = 0 AND appeal_fails = 0 FROM api.review_list(:'a_sys2') WHERE external_id = '9990002'));
SELECT t.ok('LED-01 leads_mark returns only new keys', api.leads_mark(:'a_sys2', ARRAY['tt:1:a','tt:1:b','tt:1:a']) @> ARRAY['tt:1:a','tt:1:b'] AND cardinality(api.leads_mark(:'a_sys2', ARRAY['tt:1:a','tt:1:b'])) = 0);
SELECT t.ok('LED-02 B is isolated and can re-send same key', cardinality(api.leads_mark(:'b_sys2', ARRAY['tt:1:a'])) = 1);
SELECT t.raises('LED-03 too many keys refused', format('SELECT api.leads_mark(%L, (SELECT array_agg(g::text) FROM generate_series(1,301) g))', :'a_sys2'), '22023', 'too_many_keys');
SELECT t.ok('LED-05 leads_unmark makes key new again and is isolated', api.leads_unmark(:'b_sys2', ARRAY['tt:1:a']) = 1 AND api.leads_unmark(:'b_sys2', ARRAY['tt:1:b']) = 0
  AND cardinality(api.leads_mark(:'a_sys2', ARRAY['tt:1:a'])) = 0 AND api.leads_unmark(:'a_sys2', ARRAY['tt:1:a']) = 1 AND cardinality(api.leads_mark(:'a_sys2', ARRAY['tt:1:a'])) = 1);
RESET ROLE;
SET ROLE app_runtime;
SELECT t.raises('LED-04 interactive role cannot call leads_mark', format('SELECT api.leads_mark(%L, ARRAY[%L])', :'a_mgr2','x'), '42501');
SELECT t.raises('REV-07 interactive role cannot call review_update', format('SELECT api.review_update(%L,%L,%L,%L)', :'a_mgr2','tiktok','9990002','rejected'), '42501');
RESET ROLE;
