-- 80_broker_auth.sql : دوال الـ Broker في القاعدة المركزية (BRK). تُنفَّذ بحسابات التطبيق الحقيقية لا بـ superuser.
SELECT encode(ext.digest('secret-a','sha256'),'hex') AS ha, encode(ext.digest('secret-b','sha256'),'hex') AS hb,
       encode(ext.digest('secret-d','sha256'),'hex') AS hd \gset
SELECT private.sign_ctx(jsonb_build_object('t','a0000000-0000-0000-0000-000000000001','u',1001,'r','owner',
   'b',(SELECT bot_id FROM core.bots WHERE telegram_bot_id=111),'e',1,'k','user')) AS a_expired \gset
SELECT private.sign_ctx(jsonb_build_object('t','c0000000-0000-0000-0000-000000000001','u',3001,'r','owner',
   'b',(SELECT bot_id FROM core.bots WHERE telegram_bot_id=333),'e',extract(epoch from now())::bigint+600,'k','user')) AS c_ctx \gset
SET ROLE app_runtime;
SELECT ctx AS a_owner  FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1001) \gset
SELECT ctx AS a_viewer FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1002) \gset
SELECT ctx AS a_mgr    FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1003) \gset
SELECT ctx AS b_owner  FROM api.resolve_context('botBBBBBBBBBBBBBBBBBBBBBBBB', decode(:'hb','hex'), 2001) \gset
SELECT ctx AS d_owner  FROM api.resolve_context('botDDDDDDDDDDDDDDDDDDDDDDDD', decode(:'hd','hex'), 4001) \gset
RESET ROLE;
SET ROLE app_jobs;
SELECT ctx AS a_sys FROM api.job_contexts('schedule',10) WHERE tenant_id='a0000000-0000-0000-0000-000000000001' \gset
SELECT ctx AS b_sys FROM api.job_contexts('schedule',10) WHERE tenant_id='b0000000-0000-0000-0000-000000000001' \gset
RESET ROLE;

SET ROLE app_broker;
SELECT t.ok('BRK-01 viewer of A, read, own ad account -> A secret_ref',
  (SELECT secret_ref||'|'||tenant_id::text FROM api.broker_authorize(:'a_viewer','meta','act_A1','read')) = 'ref-a-meta|a0000000-0000-0000-0000-000000000001');
SELECT t.raises('BRK-02 viewer cannot authorize a WRITE', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_viewer','meta','act_A1','write'), '42501', 'forbidden');
SELECT t.ok('BRK-03 manager of A can authorize a write',
  (SELECT secret_ref FROM api.broker_authorize(:'a_mgr','meta','act_A1','write')) = 'ref-a-meta');
SELECT t.raises('BRK-04 A ctx on B ad account -> refused', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_owner','meta','act_B1','read'), '42501', 'ad_account_not_owned_or_disabled');
SELECT t.raises('BRK-05 B ctx on A ad account -> refused', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'b_owner','meta','act_A1','read'), '42501', 'ad_account_not_owned_or_disabled');
SELECT t.raises('BRK-06 B ctx on A tiktok account -> refused', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'b_owner','tiktok','tt_A1','read'), '42501', 'ad_account_not_owned_or_disabled');
SELECT t.raises('BRK-07 account of the right id but wrong platform -> refused', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_owner','tiktok','act_A1','read'), '42501', 'ad_account_not_owned_or_disabled');
SELECT t.raises('BRK-08 tenant without the tiktok feature (D) -> platform_not_enabled', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'d_owner','tiktok','tt_A1','read'), '42501', 'platform_not_enabled');
SELECT t.ok('BRK-09 connection-level (no ad account): A tiktok -> A tiktok ref; B meta -> B meta ref',
  (SELECT secret_ref FROM api.broker_authorize(:'a_owner','tiktok',NULL,'read')) = 'ref-a-tt'
  AND (SELECT secret_ref FROM api.broker_authorize(:'b_owner','meta',NULL,'read')) = 'ref-b-meta');
SELECT t.raises('BRK-10 garbage ctx', $q$SELECT * FROM api.broker_authorize('abc.def','meta','act_A1','read')$q$, '28000', 'invalid_ctx');
SELECT t.raises('BRK-11 NULL ctx', $q$SELECT * FROM api.broker_authorize(NULL,'meta','act_A1','read')$q$, '28000', 'invalid_ctx');
SELECT t.raises('BRK-12 expired ctx', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_expired','meta','act_A1','read'), '28000', 'expired_ctx');
RESET ROLE;
SELECT status::text AS c_prev FROM core.tenants WHERE tenant_id='c0000000-0000-0000-0000-000000000001' \gset
UPDATE core.tenants SET status='NEEDS_REVIEW' WHERE tenant_id='c0000000-0000-0000-0000-000000000001';
SET ROLE app_broker;
SELECT t.raises('BRK-13 tenant not READY (NEEDS_REVIEW) -> refused', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'c_ctx','meta','act_A1','read'), '42501', 'tenant_not_ready');
RESET ROLE;
UPDATE core.tenants SET status=:'c_prev' WHERE tenant_id='c0000000-0000-0000-0000-000000000001';
SET ROLE app_broker;
SELECT t.raises('BRK-14 unknown platform', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_owner','whatsapp','act_A1','read'), '22023', 'bad_platform');
SELECT t.raises('BRK-15 unknown access mode', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_owner','meta','act_A1','admin'), '22023', 'bad_access');
SELECT t.raises('BRK-16 SQL-injection-looking ad account is just data -> not owned', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_owner','meta',$$x' OR '1'='1$$,'read'), '42501', 'ad_account_not_owned_or_disabled');

-- تدهور حالة الاتصال (انتهاء توكن) يعزل العميل المتأثر فقط
SELECT t.raises('BRK-17 report cannot set status active', format('SELECT api.broker_report_connection(%L,%L,%L,%L)', :'a_owner','meta','ref-a-meta','active'), '22023', 'bad_status');
SELECT t.ok('BRK-18 A meta connection reported expired', api.broker_report_connection(:'a_owner','meta','ref-a-meta','expired'));
SELECT t.raises('BRK-19 A meta is now refused (connection_not_active)', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_owner','meta','act_A1','read'), '42501', 'connection_not_active');
SELECT t.ok('BRK-20 B and A-tiktok unaffected by A-meta expiry',
  (SELECT secret_ref FROM api.broker_authorize(:'b_owner','meta','act_B1','read')) = 'ref-b-meta'
  AND (SELECT secret_ref FROM api.broker_authorize(:'a_owner','tiktok','tt_A1','read')) = 'ref-a-tt');
SELECT t.ok('BRK-21 B ctx cannot degrade A connection (RLS: row invisible -> false)', NOT api.broker_report_connection(:'b_owner','tiktok','ref-a-tt','expired'));
SELECT t.ok('BRK-22 A tiktok connection still usable after B attempt',
  (SELECT secret_ref FROM api.broker_authorize(:'a_owner','tiktok','tt_A1','read')) = 'ref-a-tt');
RESET ROLE;

-- إعادة التفعيل: system ctx فقط ولعميله فقط
SET ROLE app_jobs;
SELECT t.raises('BRK-23 user ctx cannot re-activate a connection', format('SELECT api.set_connection_status(%L,%L,%L)', :'a_owner','ref-a-meta','active'), '42501', 'forbidden');
SELECT t.ok('BRK-24 B system ctx cannot touch A connection (false)', NOT api.set_connection_status(:'b_sys','ref-a-meta','active'));
SELECT t.ok('BRK-25 A system ctx re-activates A connection', api.set_connection_status(:'a_sys','ref-a-meta','active'));
RESET ROLE;
SET ROLE app_broker;
SELECT t.ok('BRK-26 after re-activation A meta works again', (SELECT secret_ref FROM api.broker_authorize(:'a_owner','meta','act_A1','read')) = 'ref-a-meta');
RESET ROLE;

-- صلاحيات الأدوار
SELECT t.ok('BRK-27 app_broker executes EXACTLY the 2 broker functions',
  (SELECT string_agg(p.oid::regprocedure::text, ',' ORDER BY p.oid::regprocedure::text) FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname IN ('api','api_admin','private') AND has_function_privilege('app_broker', p.oid, 'EXECUTE'))
  = 'api.broker_authorize(text,text,text,text),api.broker_report_connection(text,text,text,text)');
SELECT t.ok('BRK-28 app_broker has no privilege on any core/private relation',
  NOT EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
              WHERE n.nspname IN ('core','private') AND c.relkind IN ('r','p','v')
                AND has_table_privilege('app_broker', c.oid, 'SELECT,INSERT,UPDATE,DELETE'))
  AND NOT EXISTS (SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
              WHERE n.nspname IN ('core','private') AND CASE WHEN c.relkind = 'S' THEN has_sequence_privilege('app_broker', c.oid, 'USAGE') ELSE false END));
SELECT t.ok('BRK-29 app_runtime / app_jobs cannot execute broker_authorize or broker_report_connection',
  NOT has_function_privilege('app_runtime','api.broker_authorize(text,text,text,text)','EXECUTE')
  AND NOT has_function_privilege('app_jobs','api.broker_authorize(text,text,text,text)','EXECUTE')
  AND NOT has_function_privilege('app_runtime','api.broker_report_connection(text,text,text,text)','EXECUTE')
  AND NOT has_function_privilege('app_jobs','api.broker_report_connection(text,text,text,text)','EXECUTE'));
SELECT t.ok('BRK-30 only app_jobs can execute set_connection_status',
  has_function_privilege('app_jobs','api.set_connection_status(text,text,text)','EXECUTE')
  AND NOT has_function_privilege('app_runtime','api.set_connection_status(text,text,text)','EXECUTE')
  AND NOT has_function_privilege('app_broker','api.set_connection_status(text,text,text)','EXECUTE'));
SELECT t.ok('BRK-31 app_broker is NOLOGIN, not superuser/bypassrls, owns nothing',
  (SELECT NOT rolcanlogin AND NOT rolsuper AND NOT rolbypassrls FROM pg_roles WHERE rolname='app_broker')
  AND NOT EXISTS (SELECT 1 FROM pg_proc p WHERE p.proowner = (SELECT oid FROM pg_roles WHERE rolname='app_broker'))
  AND NOT EXISTS (SELECT 1 FROM pg_class c WHERE c.relowner = (SELECT oid FROM pg_roles WHERE rolname='app_broker')));
SELECT t.ok('BRK-32 connection states restored to active for A/B (tests leave no residue)',
  NOT EXISTS (SELECT 1 FROM core.platform_connections WHERE status <> 'active'));

-- ═══ P4: Telegram عبر الـ Broker + قائمة الحسابات ═══
SET ROLE app_broker;
SELECT t.ok('BRK-33 telegram: viewer of A gets the bot token ref of A (not B)',
  (SELECT secret_ref FROM api.broker_authorize(:'a_viewer','telegram',NULL,'read')) = 'ref-bot-a'
  AND (SELECT secret_ref FROM api.broker_authorize(:'b_owner','telegram',NULL,'read')) = 'ref-bot-b');
SELECT t.ok('BRK-34 telegram: tenant matches the ctx tenant',
  (SELECT tenant_id::text FROM api.broker_authorize(:'a_owner','telegram',NULL,'read')) = 'a0000000-0000-0000-0000-000000000001');
SELECT t.raises('BRK-35 telegram: garbage ctx refused', $q$SELECT * FROM api.broker_authorize('abc.def','telegram',NULL,'read')$q$, '28000', 'invalid_ctx');
RESET ROLE;
SELECT status::text AS c_prev2 FROM core.tenants WHERE tenant_id='c0000000-0000-0000-0000-000000000001' \gset
UPDATE core.tenants SET status='NEEDS_REVIEW' WHERE tenant_id='c0000000-0000-0000-0000-000000000001';
SET ROLE app_broker;
SELECT t.raises('BRK-36 telegram: tenant not READY (NEEDS_REVIEW) refused', format('SELECT * FROM api.broker_authorize(%L,%L,NULL,%L)', :'c_ctx','telegram','read'), '42501', 'tenant_not_ready');
RESET ROLE;
UPDATE core.tenants SET status=:'c_prev2' WHERE tenant_id='c0000000-0000-0000-0000-000000000001';
SET ROLE app_broker;
RESET ROLE;
SET ROLE app_runtime;
SELECT t.ok('BRK-37 list_ad_accounts: A sees only its own accounts',
  (SELECT string_agg(external_id, ',' ORDER BY external_id) FROM api.list_ad_accounts(:'a_viewer')) = 'act_A1,tt_A1');
SELECT t.ok('BRK-38 list_ad_accounts: B sees only its own accounts',
  (SELECT string_agg(external_id, ',' ORDER BY external_id) FROM api.list_ad_accounts(:'b_owner')) = 'act_B1,tt_B1');
SELECT t.raises('BRK-39 list_ad_accounts: garbage ctx refused', $q$SELECT * FROM api.list_ad_accounts('abc.def')$q$, '28000', 'invalid_ctx');
SELECT t.ok('BRK-40 list_ad_accounts returns no secret-like columns',
  (SELECT array_agg(attname::text ORDER BY attnum) FROM pg_attribute WHERE attrelid = 'api.list_ad_accounts(text)'::regprocedure::oid AND false) IS NULL
  AND NOT EXISTS (SELECT 1 FROM unnest(ARRAY['platform','external_id','name','currency','status','enabled']) c WHERE c ~* '(token|secret|password|ref)'));
RESET ROLE;
SELECT t.ok('BRK-41 app_broker cannot list accounts; app_jobs and app_runtime can',
  NOT has_function_privilege('app_broker','api.list_ad_accounts(text)','EXECUTE')
  AND has_function_privilege('app_jobs','api.list_ad_accounts(text)','EXECUTE')
  AND has_function_privilege('app_runtime','api.list_ad_accounts(text)','EXECUTE'));

SET ROLE app_broker;
SELECT t.ok('BRK-42 telegram: registered chat of A is allowed',
  (SELECT secret_ref FROM api.broker_authorize(:'a_viewer','telegram','1001','read')) = 'ref-bot-a');
SELECT t.raises('BRK-43 telegram: a chat of tenant B is refused for A', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_viewer','telegram','2001','read'), '42501', 'chat_not_registered');
SELECT t.raises('BRK-44 telegram: unknown chat refused', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_viewer','telegram','99999','read'), '42501', 'chat_not_registered');
SELECT t.raises('BRK-45 telegram: non-numeric chat refused (injection-looking)', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_viewer','telegram',$$1001' OR '1'='1$$,'read'), '22023', 'bad_chat');
RESET ROLE;

SET ROLE app_runtime;
SELECT t.ok('BRK-46 preflight: manager of A within budget -> true', api.preflight_campaign(:'a_mgr','meta','act_A1',20));
SELECT t.raises('BRK-47 preflight: viewer refused', format('SELECT api.preflight_campaign(%L,%L,%L,%s)', :'a_viewer','meta','act_A1',20), '42501', 'forbidden');
SELECT t.raises('BRK-48 preflight: budget over personal limit (50) refused BEFORE any platform call', format('SELECT api.preflight_campaign(%L,%L,%L,%s)', :'a_mgr','meta','act_A1',200), '42501', 'budget_over_user_limit');
SELECT t.raises('BRK-49 preflight: account of B refused for A', format('SELECT api.preflight_campaign(%L,%L,%L,%s)', :'a_mgr','meta','act_B1',20), '42501', 'ad_account_not_owned_or_disabled');
SELECT t.raises('BRK-50 preflight: unknown platform', format('SELECT api.preflight_campaign(%L,%L,%L,%s)', :'a_mgr','whatsapp','act_A1',20), '22023', 'bad_platform');
RESET ROLE;

SET ROLE app_runtime;
SELECT t.ok('BRK-51 begin_campaign_checked: manager ok -> state new, no reason', (SELECT state = 'new' AND reason IS NULL FROM api.begin_campaign_checked(:'a_mgr','brk51-key-0000000001', sha256('x'::bytea),'meta','act_A1',20)));
SELECT t.ok('BRK-52 begin_campaign_checked: viewer -> reason forbidden, nothing written', (SELECT state IS NULL AND reason = 'forbidden' FROM api.begin_campaign_checked(:'a_viewer','brk52-key-0000000002', sha256('x'::bytea),'meta','act_A1',20)));
SELECT t.ok('BRK-53 begin_campaign_checked: over budget -> reason budget_over_user_limit', (SELECT reason = 'budget_over_user_limit' FROM api.begin_campaign_checked(:'a_mgr','brk53-key-0000000003', sha256('x'::bytea),'meta','act_A1',200)));
SELECT t.ok('BRK-54 begin_campaign_checked: B account -> reason ad_account_not_owned_or_disabled', (SELECT reason = 'ad_account_not_owned_or_disabled' FROM api.begin_campaign_checked(:'a_mgr','brk54-key-0000000004', sha256('x'::bytea),'meta','act_B1',10)));
RESET ROLE;
SELECT t.ok('BRK-55 rejected requests left no campaign_requests row (only the ok one)', (SELECT count(*) = 1 FROM core.campaign_requests WHERE idempotency_key LIKE 'brk5_-key-%'));

SET ROLE app_jobs;
SELECT t.ok('BRK-56 list_owner_chats(A system) = only A owner 1001', (SELECT array_agg(chat_id) = ARRAY[1001::bigint] FROM api.list_owner_chats(:'a_sys')));
SELECT t.ok('BRK-57 list_owner_chats(B system) = only B owner 2001', (SELECT array_agg(chat_id) = ARRAY[2001::bigint] FROM api.list_owner_chats(:'b_sys')));
RESET ROLE;
SET ROLE app_runtime;
SELECT t.raises('BRK-58 app_runtime cannot call list_owner_chats (jobs only)', format('SELECT * FROM api.list_owner_chats(%L)', :'a_mgr'), '42501', 'permission denied');
RESET ROLE;

-- ── Readiness: probe access + facts + local checks + sweep wrapper ──
SELECT private.sign_ctx(jsonb_build_object('t','c0000000-0000-0000-0000-000000000001','r','system','e',extract(epoch from now())::bigint+600,'k','system')) AS c_sys \gset
UPDATE core.tenants SET status='CONFIGURATION_REQUIRED' WHERE tenant_id='c0000000-0000-0000-0000-000000000001';
SET ROLE app_broker;
SELECT t.ok('BRK-59 probe: system ctx of READY tenant reads own telegram bot ref', (SELECT secret_ref FROM api.broker_authorize(:'a_sys','telegram',NULL,'probe')) = 'ref-bot-a');
SELECT t.raises('BRK-60 probe: user ctx (manager) refused', format('SELECT * FROM api.broker_authorize(%L,%L,NULL,%L)', :'a_mgr','telegram','probe'), '42501', 'forbidden');
SELECT t.raises('BRK-61 probe: CONFIGURATION_REQUIRED tenant not probeable', format('SELECT * FROM api.broker_authorize(%L,%L,NULL,%L)', :'c_sys','telegram','probe'), '42501', 'tenant_not_probeable');
SELECT t.raises('BRK-62 probe: A system ctx cannot reach B ad account', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_sys','meta','act_B1','probe'), '42501', 'ad_account_not_owned_or_disabled');
RESET ROLE;
UPDATE core.tenants SET status='TESTING' WHERE tenant_id='c0000000-0000-0000-0000-000000000001';
SET ROLE app_broker;
SELECT t.ok('BRK-63 probe: TESTING tenant can be probed (bot ref only, no READY needed)', (SELECT secret_ref FROM api.broker_authorize(:'c_sys','telegram',NULL,'probe')) = 'ref-bot-c');
SELECT t.raises('BRK-64 but a normal read on the same TESTING tenant is still refused', format('SELECT * FROM api.broker_authorize(%L,%L,NULL,%L)', :'c_ctx','telegram','read'), '42501', 'tenant_not_ready');
RESET ROLE;
SET ROLE app_jobs;
SELECT t.ok('BRK-65 readiness_facts(C TESTING): owner 3001, no accounts, status TESTING', (SELECT f->>'status' = 'TESTING' AND f->'owners' = '[3001]'::jsonb AND f->'accounts' = '[]'::jsonb FROM (SELECT api.readiness_facts(:'c_sys') AS f) x));
SELECT t.ok('BRK-66 readiness_facts(A) lists only A accounts', (SELECT jsonb_array_length(f->'accounts') = 2 AND f::text NOT LIKE '%_B1%' FROM (SELECT api.readiness_facts(:'a_sys') AS f) x));
SELECT t.ok('BRK-67 readiness_local(A): R01,R13,R14,R15 all pass', (SELECT array_agg(check_code ORDER BY check_code) = ARRAY['R01','R13','R14','R15'] AND bool_and(status = 'pass') FROM api.readiness_local(:'a_sys')));
SELECT t.ok('BRK-68 readiness_local(C): R01 passes (owner+bot) and is evidence-bearing', (SELECT status = 'pass' AND (evidence->>'owners')::int = 1 FROM api.readiness_local(:'c_sys') WHERE check_code = 'R01'));
SELECT t.ok('BRK-69 run_readiness_sweep callable by jobs', (SELECT api.run_readiness_sweep() >= 0));
RESET ROLE;
UPDATE core.tenants SET status='CONFIGURATION_REQUIRED' WHERE tenant_id='c0000000-0000-0000-0000-000000000001';
SET ROLE app_runtime;
SELECT t.raises('BRK-70 runtime cannot call readiness_facts / run_readiness_sweep', format('SELECT api.readiness_facts(%L)', :'a_mgr'), '42501', 'permission denied');
RESET ROLE;

-- ── Subscriptions ──
SELECT 'a0000000-0000-0000-0000-000000000001'::uuid AS ta, 'b0000000-0000-0000-0000-000000000001'::uuid AS tb \gset
SET ROLE app_runtime;
SELECT t.ok('SUB-01 active subscription: resolve_context reports sub_state active', (SELECT sub_state = 'active' FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1001)));
RESET ROLE;
SET ROLE app_ops;
SELECT api_admin.set_subscription(:'ta', 'standard', 'past_due', now() - interval '1 day', 3, '{}');
RESET ROLE;
SET ROLE app_runtime;
SELECT ctx AS a_owner_grace FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1001) \gset
SELECT t.ok('SUB-02 past_due within grace -> sub_state grace', (SELECT sub_state = 'grace' FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1001)));
SELECT t.ok('SUB-03 grace: reads still work', (SELECT count(*) >= 2 FROM api.list_ad_accounts(:'a_owner_grace')));
SELECT t.raises('SUB-04 grace: writes refused (preflight)', format('SELECT api.preflight_campaign(%L,%L,%L,%s)', :'a_owner_grace','meta','act_A1',10), '42501', 'subscription_grace_readonly');
SELECT t.ok('SUB-05 grace: begin_campaign_checked returns reason, writes nothing', (SELECT reason = 'subscription_grace_readonly' AND state IS NULL FROM api.begin_campaign_checked(:'a_owner_grace','sub05-key-00000000001', sha256('x'::bytea),'meta','act_A1',10)));
RESET ROLE;
SET ROLE app_ops;
SELECT api_admin.set_subscription(:'ta', 'standard', 'past_due', now() - interval '10 days', 3, '{}');
RESET ROLE;
SET ROLE app_runtime;
SELECT ctx AS a_owner_exp FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1001) \gset
SELECT t.ok('SUB-06 expired -> sub_state expired (ctx still issued so the bot can answer)', (SELECT sub_state = 'expired' FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1001)));
SELECT t.raises('SUB-07 expired: even reads refused', format('SELECT * FROM api.list_ad_accounts(%L)', :'a_owner_exp'), '42501', 'subscription_expired');
SELECT t.ok('SUB-08 expired: begin_update still works (to reply with renewal notice)', (SELECT api.begin_update(:'a_owner_exp', 990001) = 'new'));
RESET ROLE;
SET ROLE app_broker;
SELECT t.ok('SUB-09 expired: telegram reply still authorized (renewal notice)', (SELECT secret_ref FROM api.broker_authorize(:'a_owner_exp','telegram','1001','read')) = 'ref-bot-a');
SELECT t.raises('SUB-10 expired: platform read refused by broker_authorize', format('SELECT * FROM api.broker_authorize(%L,%L,%L,%L)', :'a_owner_exp','meta','act_A1','read'), '42501', 'subscription_expired');
RESET ROLE;
SET ROLE app_jobs;
SELECT t.ok('SUB-11 job_contexts excludes expired A, keeps B', (SELECT array_agg(tenant_id) FROM api.job_contexts('schedule', 10)) @> ARRAY[:'tb'::uuid] AND NOT ((SELECT array_agg(tenant_id) FROM api.job_contexts('schedule', 10)) @> ARRAY[:'ta'::uuid]));
RESET ROLE;
SET ROLE app_ops;
SELECT api_admin.set_subscription(:'ta', 'standard', 'cancelled', now() + interval '2 days', 3, '{}');
RESET ROLE;
SET ROLE app_runtime;
SELECT t.ok('SUB-12 cancelled but period not over -> still active', (SELECT sub_state = 'active' FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1001)));
RESET ROLE;
SELECT count(*) + 1 AS lim FROM core.campaign_requests WHERE tenant_id = :'ta' AND created_at >= date_trunc('day', now()) \gset
SET ROLE app_ops;
SELECT api_admin.set_subscription(:'ta', 'standard', 'active', now() + interval '30 days', 3, jsonb_build_object('max_creates_per_day', :lim::int));
RESET ROLE;
SET ROLE app_runtime;
SELECT ctx AS a_mgr2 FROM api.resolve_context('botAAAAAAAAAAAAAAAAAAAAAAAA', decode(:'ha','hex'), 1003) \gset
SELECT t.ok('SUB-13 daily limit: first create request allowed', (SELECT state = 'new' FROM api.begin_campaign_checked(:'a_mgr2','sub13-key-00000000001', sha256('1'::bytea),'meta','act_A1',10)));
SELECT t.ok('SUB-14 daily limit: second one refused with reason, nothing recorded', (SELECT reason = 'daily_create_limit' FROM api.begin_campaign_checked(:'a_mgr2','sub14-key-00000000002', sha256('2'::bytea),'meta','act_A1',10)));
RESET ROLE;
SELECT t.ok('SUB-15 B unaffected by A subscription changes', (SELECT status FROM core.subscriptions WHERE tenant_id = :'tb') = 'active');
SET ROLE app_runtime;
SELECT t.raises('SUB-16 runtime cannot manage subscriptions', format('SELECT api_admin.set_subscription(%L,%L,%L,now(),3,%L)', :'ta','x1','active','{}'), '42501', 'permission denied');
RESET ROLE;
SET ROLE app_ops;
SELECT t.raises('SUB-17 bad limits rejected', format('SELECT api_admin.set_subscription(%L,%L,%L,now(),3,%L)', :'ta','standard','active','{"max_creates_per_day":"many"}'), '22023', 'bad_limits');
RESET ROLE;
SELECT t.ok('SUB-18 subscription changes are audited', (SELECT count(*) >= 4 FROM core.audit_log WHERE action = 'set_subscription'));

-- ── Connection alerts ──
SET ROLE app_jobs;
SELECT t.ok('ALR-01 no pending alerts for healthy A', (SELECT count(*) = 0 FROM api.pending_connection_alerts(:'a_sys')));
RESET ROLE;
SET ROLE app_broker;
SELECT t.ok('ALR-02 broker reports Meta token expired for A', api.broker_report_connection(:'a_viewer','meta','ref-a-meta','expired'));
RESET ROLE;
SET ROLE app_jobs;
SELECT t.ok('ALR-03 A has exactly one pending alert (meta/expired)', (SELECT count(*) = 1 AND bool_and(platform = 'meta' AND status = 'expired') FROM api.pending_connection_alerts(:'a_sys')));
SELECT t.ok('ALR-04 B has none (A expiry does not leak to B)', (SELECT count(*) = 0 FROM api.pending_connection_alerts(:'b_sys')));
SELECT t.ok('ALR-05 marking alerted returns 1 and clears the pending list', api.mark_connection_alerted(:'a_sys','meta') = 1 AND (SELECT count(*) = 0 FROM api.pending_connection_alerts(:'a_sys')));
SELECT t.ok('ALR-06 second mark is a no-op (alert sent only once)', api.mark_connection_alerted(:'a_sys','meta') = 0);
SELECT t.ok('ALR-07 reactivation clears alerted flag', api.set_connection_status(:'a_sys','ref-a-meta','active'));
RESET ROLE;
SELECT t.ok('ALR-08 alerted_at really NULL after reactivation', (SELECT alerted_at IS NULL FROM core.platform_connections WHERE secret_ref = 'ref-a-meta'));
SET ROLE app_runtime;
SELECT t.raises('ALR-09 runtime cannot read alerts', format('SELECT * FROM api.pending_connection_alerts(%L)', :'a_mgr'), '42501', 'permission denied');
RESET ROLE;

SET ROLE app_runtime;
SELECT api.begin_update(:'a_mgr', 880001) AS st0 \gset
SELECT t.ok('UPD-01 first delivery new', :'st0' = 'new');
RESET ROLE;
UPDATE core.processed_updates SET claimed_at = now() - interval '60 seconds' WHERE update_id = 880001;
SET ROLE app_runtime;
SELECT t.ok('UPD-02 stale claim (dead processor) -> retry', api.begin_update(:'a_mgr', 880001) = 'retry');
SELECT t.ok('UPD-03 right after retry the claim is fresh again -> inflight', api.begin_update(:'a_mgr', 880001) = 'inflight');
SELECT api.finish_update(:'a_mgr', 880001, true);
SELECT t.ok('UPD-04 finished -> done forever', api.begin_update(:'a_mgr', 880001) = 'done');
SELECT api.finish_update(:'a_mgr', 880001, false);
SELECT t.ok('UPD-05 finish(false) never reopens a done update', api.begin_update(:'a_mgr', 880001) = 'done');
RESET ROLE;
