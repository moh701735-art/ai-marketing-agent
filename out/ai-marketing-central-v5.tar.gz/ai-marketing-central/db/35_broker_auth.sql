-- 35_broker_auth.sql : دوال الـ Credential Broker في القاعدة المركزية.
-- الـ Broker لا يثق بأي tenant_id يأتي من n8n: يسأل القاعدة (بتمرير ctx الموقّع) عن مؤشر السر الصالح لهذا العميل وهذا الحساب الإعلاني.
-- القاعدة تتحقق من: توقيع/انتهاء ctx، حالة العميل (READY)، الدور، ميزة المنصة، ملكية الحساب الإعلاني، وحالة الاتصال.
\set ON_ERROR_STOP on
SET ROLE app_owner;

CREATE FUNCTION api.broker_authorize(p_ctx text, p_platform text, p_ad_account text, p_access text)
RETURNS TABLE (tenant_id uuid, role text, secret_ref text, connection_id uuid)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
DECLARE v jsonb; v_min text; v_row record;
BEGIN
  IF p_platform NOT IN ('meta','tiktok','telegram') THEN RAISE EXCEPTION 'bad_platform' USING ERRCODE = '22023'; END IF;
  IF p_access NOT IN ('read','write','probe') THEN RAISE EXCEPTION 'bad_access' USING ERRCODE = '22023'; END IF;
  IF p_access = 'probe' THEN
    -- فحوصات الجاهزية: system ctx فقط، لعمليات قراءة/اختبار (الـ Broker لا يمرر write بهذا النمط). العميل قيد الإعداد مسموح، المعلَّق لا.
    v := private.enter_ctx(p_ctx, 'system', false);
    IF (SELECT t.status FROM core.tenants t WHERE t.tenant_id = private.cur_tenant()) NOT IN ('CONNECTING','TESTING','NEEDS_REVIEW','READY') THEN
      RAISE EXCEPTION 'tenant_not_probeable' USING ERRCODE = '42501';
    END IF;
  ELSE
    v_min := CASE p_access WHEN 'read' THEN 'viewer' ELSE 'manager' END;
    v := private.enter_ctx(p_ctx, v_min, true, p_platform <> 'telegram');      -- الرد برسالة (مثل «اشتراكك منتهٍ») مسموح حتى لو الاشتراك منتهٍ
  END IF;
  IF p_platform = 'telegram' THEN
    -- إرسال رد عبر بوت هذا العميل نفسه: السر هو توكن البوت (core.bots)، لا حساب إعلاني. RLS تحصر الصف بالعميل.
    SELECT b.bot_id AS cid, b.secret_ref AS sref, 'active'::text AS st INTO v_row
      FROM core.bots b WHERE b.status = 'active' ORDER BY b.created_at DESC LIMIT 1;
    IF NOT FOUND THEN RAISE EXCEPTION 'no_active_bot' USING ERRCODE = '42501'; END IF;
    IF p_ad_account IS NOT NULL THEN      -- المُرسَل إليه: مستخدم مسجّل ونشط لهذا العميل فقط (لا رسائل لأي chat عشوائي)
      IF p_ad_account !~ '^[0-9]{1,15}$' THEN RAISE EXCEPTION 'bad_chat' USING ERRCODE = '22023'; END IF;
      IF NOT EXISTS (SELECT 1 FROM core.tenant_users u WHERE u.telegram_user_id = p_ad_account::bigint AND u.active) THEN
        RAISE EXCEPTION 'chat_not_registered' USING ERRCODE = '42501';
      END IF;
    END IF;
    tenant_id := private.cur_tenant(); role := v ->> 'r'; secret_ref := v_row.sref; connection_id := v_row.cid;
    RETURN NEXT;
    RETURN;
  END IF;
  IF NOT coalesce((SELECT (t.features ->> p_platform)::boolean FROM core.tenants t WHERE t.tenant_id = private.cur_tenant()), false) THEN
    RAISE EXCEPTION 'platform_not_enabled' USING ERRCODE = '42501';
  END IF;
  IF p_ad_account IS NOT NULL THEN
    SELECT c.connection_id AS cid, c.secret_ref AS sref, c.status AS st INTO v_row
      FROM core.ad_accounts a
      JOIN core.platform_connections c ON c.tenant_id = a.tenant_id AND c.platform = a.platform AND c.connection_id = a.connection_id
     WHERE a.platform = p_platform::core.platform AND a.external_id = p_ad_account AND a.enabled AND a.unlinked_at IS NULL;
    IF NOT FOUND THEN RAISE EXCEPTION 'ad_account_not_owned_or_disabled' USING ERRCODE = '42501'; END IF;
  ELSE   -- عمليات مستوى الاتصال (قبل الربط): نأخذ أحدث اتصال فعّال لهذه المنصة
    SELECT c.connection_id AS cid, c.secret_ref AS sref, c.status AS st INTO v_row
      FROM core.platform_connections c
     WHERE c.platform = p_platform::core.platform AND c.status = 'active'
     ORDER BY c.created_at DESC LIMIT 1;
    IF NOT FOUND THEN RAISE EXCEPTION 'no_active_connection' USING ERRCODE = '42501'; END IF;
  END IF;
  IF v_row.st <> 'active' THEN RAISE EXCEPTION 'connection_not_active' USING ERRCODE = '42501'; END IF;
  tenant_id := private.cur_tenant(); role := v ->> 'r'; secret_ref := v_row.sref; connection_id := v_row.cid;
  RETURN NEXT;
END $$;

-- الـ Broker يُبلّغ عن تدهور حالة الاتصال فقط (expired/revoked/error). لا يستطيع إعادة التفعيل.
CREATE FUNCTION api.broker_report_connection(p_ctx text, p_platform text, p_secret_ref text, p_status text) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
DECLARE n int;
BEGIN
  IF p_status NOT IN ('expired','revoked','error') THEN RAISE EXCEPTION 'bad_status' USING ERRCODE = '22023'; END IF;
  PERFORM private.enter_ctx(p_ctx, 'viewer');
  UPDATE core.platform_connections SET status = p_status
   WHERE platform = p_platform::core.platform AND secret_ref = p_secret_ref AND status = 'active';
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n = 1;
END $$;

-- إعادة التفعيل بعد إعادة المصادقة الناجحة: system ctx فقط (job/onboarding)
CREATE FUNCTION api.set_connection_status(p_ctx text, p_secret_ref text, p_status text) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
DECLARE n int;
BEGIN
  IF p_status NOT IN ('active','expired','revoked','error') THEN RAISE EXCEPTION 'bad_status' USING ERRCODE = '22023'; END IF;
  PERFORM private.enter_ctx(p_ctx, 'system', false);
  UPDATE core.platform_connections SET status = p_status, last_verified_at = CASE WHEN p_status = 'active' THEN now() ELSE last_verified_at END,
     alerted_at = CASE WHEN p_status = 'active' THEN NULL ELSE alerted_at END
   WHERE secret_ref = p_secret_ref;
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n = 1;
END $$;

-- قائمة الحسابات الإعلانية المربوطة لهذا العميل (للأوامر التفاعلية). لا أسرار، لا مؤشرات أسرار.
CREATE FUNCTION api.list_ad_accounts(p_ctx text)
RETURNS TABLE (platform text, external_id text, name text, currency text, status text, enabled boolean)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'viewer');
  RETURN QUERY SELECT a.platform::text, a.external_id, a.name, a.currency::text, a.status, a.enabled
    FROM core.ad_accounts a WHERE a.unlinked_at IS NULL ORDER BY a.platform, a.external_id;
END $$;

-- فحص مسبق قبل أي إنشاء خارجي: الدور (manager)، ملكية الحساب، حد ميزانية المستخدم. لا يكتب شيئاً.
CREATE FUNCTION api.preflight_campaign(p_ctx text, p_platform text, p_ad_account text, p_budget numeric) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
DECLARE v jsonb; v_max numeric;
BEGIN
  IF p_platform NOT IN ('meta','tiktok') THEN RAISE EXCEPTION 'bad_platform' USING ERRCODE = '22023'; END IF;
  v := private.enter_ctx(p_ctx, 'manager');
  IF NOT EXISTS (SELECT 1 FROM core.ad_accounts WHERE platform = p_platform::core.platform AND external_id = p_ad_account AND enabled AND unlinked_at IS NULL) THEN
    RAISE EXCEPTION 'ad_account_not_owned_or_disabled' USING ERRCODE = '42501';
  END IF;
  IF v->>'r' <> 'system' THEN
    SELECT max_daily_budget_usd INTO v_max FROM core.tenant_users WHERE telegram_user_id = (v->>'u')::bigint;
    IF v_max IS NOT NULL AND p_budget > v_max THEN RAISE EXCEPTION 'budget_over_user_limit' USING ERRCODE = '42501'; END IF;
  END IF;
  RETURN true;
END $$;

-- فحص مسبق + بدء الطلب بخطوة واحدة؛ يرجع السبب كنص منظّم بدل رفع الخطأ (n8n لا يحتفظ بنص خطأ SQL).
CREATE FUNCTION api.begin_campaign_checked(p_ctx text, p_key text, p_hash bytea, p_platform text, p_ad_account text, p_budget numeric)
RETURNS TABLE (state text, result_ref text, reason text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
DECLARE v_msg text; v_lim numeric; v_today int;
BEGIN
  BEGIN
    PERFORM api.preflight_campaign(p_ctx, p_platform, p_ad_account, p_budget);
    SELECT (s.limits->>'max_creates_per_day')::numeric INTO v_lim FROM core.subscriptions s WHERE s.tenant_id = private.cur_tenant();
    IF v_lim IS NOT NULL THEN
      SELECT count(*) INTO v_today FROM core.campaign_requests r WHERE r.tenant_id = private.cur_tenant() AND r.created_at >= date_trunc('day', now());
      IF v_today >= v_lim THEN RAISE EXCEPTION 'daily_create_limit' USING ERRCODE = '42501'; END IF;
    END IF;
    RETURN QUERY SELECT b.state, b.result_ref, NULL::text FROM api.begin_campaign_request(p_ctx, p_key, p_hash) b;
  EXCEPTION WHEN OTHERS THEN
    v_msg := SQLERRM;
    IF v_msg NOT IN ('forbidden','budget_over_user_limit','ad_account_not_owned_or_disabled','tenant_not_ready','bad_platform','subscription_expired','subscription_grace_readonly','daily_create_limit') THEN v_msg := 'internal_error'; END IF;
    RETURN QUERY SELECT NULL::text, NULL::text, v_msg;
  END;
END $$;

-- مستلمو التقارير المجدولة: مالكو الـ tenant الفعّالون (يُستدعى بسياق system من المهام).
CREATE FUNCTION api.list_owner_chats(p_ctx text) RETURNS TABLE (chat_id bigint)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'viewer');
  RETURN QUERY SELECT u.telegram_user_id FROM core.tenant_users u WHERE u.role = 'owner' AND u.active ORDER BY u.telegram_user_id;
END $$;

-- حقائق الجاهزية لعميل واحد (system ctx، يعمل حتى لو غير READY). لا أسرار.
CREATE FUNCTION api.readiness_facts(p_ctx text) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'system', false);
  RETURN (SELECT jsonb_build_object(
    'status', t.status::text, 'features', t.features,
    'owners', coalesce((SELECT jsonb_agg(u.telegram_user_id ORDER BY u.telegram_user_id) FROM core.tenant_users u WHERE u.role = 'owner' AND u.active), '[]'::jsonb),
    'accounts', coalesce((SELECT jsonb_agg(jsonb_build_object('platform', a.platform::text, 'external_id', a.external_id) ORDER BY a.platform, a.external_id)
                          FROM core.ad_accounts a WHERE a.enabled AND a.unlinked_at IS NULL), '[]'::jsonb),
    'checks', coalesce((SELECT jsonb_object_agg(c.check_code, jsonb_build_object('status', c.status::text, 'expires_at', c.expires_at, 'max_age_secs', extract(epoch FROM d.max_age)::bigint))
                        FROM core.readiness_checks c JOIN core.readiness_check_defs d USING (check_code)), '{}'::jsonb))
    FROM core.tenants t WHERE t.tenant_id = private.cur_tenant());
END $$;

-- فحوصات الجاهزية التي تُقيَّم بالقاعدة وحدها: R01 سجل العميل، R13 تسجيل الأخطاء، R14 لا أسرار بسجل الأخطاء، R15 نسخة إعداد.
-- R14 هنا يغطي core.error_log فقط (بيانات n8n نفسها تُفحص خارج القاعدة: ops/p4-scan-n8n.sh) — الدليل يذكر النطاق صراحة.
CREATE FUNCTION api.readiness_local(p_ctx text) RETURNS TABLE (check_code text, status text, evidence jsonb)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private, ext AS $$
DECLARE t core.tenants; v_owners int; v_bots int; v_cfg int; v_id bigint; v_seen int; v_bad int;
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'system', false);
  SELECT * INTO t FROM core.tenants WHERE tenant_id = private.cur_tenant();
  SELECT count(*) INTO v_owners FROM core.tenant_users u WHERE u.role = 'owner' AND u.active;
  SELECT count(*) INTO v_bots FROM core.bots b WHERE b.status = 'active';
  -- R01
  check_code := 'R01'; status := CASE WHEN t.features <> '{}'::jsonb AND t.timezone IS NOT NULL AND v_owners >= 1 AND v_bots >= 1 THEN 'pass' ELSE 'fail' END;
  evidence := jsonb_build_object('owners', v_owners, 'active_bots', v_bots, 'features', t.features, 'timezone', t.timezone); RETURN NEXT;
  -- R13: سجّل خطأ اختبارياً ثم تحقق أنه ظهر بتصنيف وبصمة (ثم يُعلَّم resolved)
  INSERT INTO core.error_log (tenant_id, class, platform, workflow, node, code, message, fingerprint)
  VALUES (t.tenant_id, 'UNKNOWN', NULL, 'readiness', 'R13', 'READINESS_PROBE', 'synthetic readiness probe', encode(digest('readiness|R13', 'sha256'), 'hex'))
  RETURNING error_id INTO v_id;
  SELECT count(*) INTO v_seen FROM core.error_log e WHERE e.error_id = v_id AND e.class IS NOT NULL AND e.fingerprint IS NOT NULL;
  UPDATE core.error_log SET resolved_at = now() WHERE error_id = v_id;
  check_code := 'R13'; status := CASE WHEN v_seen = 1 THEN 'pass' ELSE 'fail' END;
  evidence := jsonb_build_object('logged_and_readable', v_seen = 1, 'scope', 'central error_log write/read/classify only; alert delivery not implemented'); RETURN NEXT;
  -- R14
  SELECT count(*) INTO v_bad FROM core.error_log e WHERE e.message ~ '\d{8,10}:[A-Za-z0-9_-]{30,}' OR e.message ~ 'EAA[A-Za-z0-9]{20,}' OR e.message ~ 'FAKE-[A-Za-z0-9-]{10,}';
  check_code := 'R14'; status := CASE WHEN v_bad = 0 THEN 'pass' ELSE 'fail' END;
  evidence := jsonb_build_object('token_like_rows_in_error_log', v_bad, 'scope', 'central error_log only (n8n execution data scanned by ops script)'); RETURN NEXT;
  -- R15
  SELECT count(*) INTO v_cfg FROM core.config_versions c WHERE c.tenant_id = t.tenant_id;
  check_code := 'R15'; status := CASE WHEN t.active_config_version IS NOT NULL THEN 'pass' ELSE 'fail' END;
  evidence := jsonb_build_object('active_version', t.active_config_version, 'versions', v_cfg, 'rollback_possible', v_cfg >= 2); RETURN NEXT;
END $$;

-- تنبيهات توقف الاتصالات: اتصالات غير فعّالة لم يُنبَّه المالك عنها بعد (system ctx). لا أسرار ولا مؤشرات أسرار.
CREATE FUNCTION api.pending_connection_alerts(p_ctx text) RETURNS TABLE (platform text, status text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
BEGIN
  PERFORM private.enter_ctx(p_ctx, 'system', false);
  RETURN QUERY SELECT DISTINCT c.platform::text, c.status FROM core.platform_connections c WHERE c.status <> 'active' AND c.alerted_at IS NULL ORDER BY 1;
END $$;

CREATE FUNCTION api.mark_connection_alerted(p_ctx text, p_platform text) RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, core, private AS $$
DECLARE n int;
BEGIN
  IF p_platform NOT IN ('meta','tiktok') THEN RAISE EXCEPTION 'bad_platform' USING ERRCODE = '22023'; END IF;
  PERFORM private.enter_ctx(p_ctx, 'system', false);
  UPDATE core.platform_connections SET alerted_at = now() WHERE platform = p_platform::core.platform AND status <> 'active' AND alerted_at IS NULL;
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END $$;

REVOKE ALL ON FUNCTION api.broker_authorize(text, text, text, text), api.broker_report_connection(text, text, text, text),
  api.set_connection_status(text, text, text), api.list_ad_accounts(text), api.preflight_campaign(text, text, text, numeric), api.begin_campaign_checked(text, text, bytea, text, text, numeric), api.list_owner_chats(text), api.readiness_facts(text), api.readiness_local(text), api.pending_connection_alerts(text), api.mark_connection_alerted(text, text) FROM PUBLIC;
GRANT USAGE ON SCHEMA api TO app_broker;
GRANT EXECUTE ON FUNCTION api.broker_authorize(text, text, text, text), api.broker_report_connection(text, text, text, text) TO app_broker;
GRANT EXECUTE ON FUNCTION api.set_connection_status(text, text, text), api.list_ad_accounts(text), api.preflight_campaign(text, text, text, numeric), api.list_owner_chats(text), api.readiness_facts(text), api.readiness_local(text), api.pending_connection_alerts(text), api.mark_connection_alerted(text, text) TO app_jobs;
GRANT EXECUTE ON FUNCTION api.list_ad_accounts(text), api.preflight_campaign(text, text, text, numeric), api.begin_campaign_checked(text, text, bytea, text, text, numeric) TO app_runtime;
RESET ROLE;

-- تشغيل sweep الجاهزية من المهام المجدولة (عابر للـ tenants؛ مالكه app_resolver). يخفض READY→NEEDS_REVIEW عند فشل/انتهاء فحص إلزامي.
CREATE FUNCTION api.run_readiness_sweep() RETURNS int
LANGUAGE sql SECURITY DEFINER SET search_path = pg_catalog AS $$ SELECT api_admin.sweep_readiness() $$;
ALTER FUNCTION api.run_readiness_sweep() OWNER TO app_resolver;
GRANT USAGE ON SCHEMA api_admin TO app_resolver;
REVOKE ALL ON FUNCTION api.run_readiness_sweep() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION api.run_readiness_sweep() TO app_jobs;
