#!/usr/bin/env python3
"""يولّد ملفات Workflows لـ n8n (JSON) من وصف برمجي. لا يتصل بأي n8n. الناتج: n8n/workflows/*.json
التشغيل: python3 n8n/build.py   ثم ops/p4-import.sh لاستيرادها في n8n المحلي الجديد."""
import json, pathlib, uuid

OUT = pathlib.Path(__file__).resolve().parent / "workflows"
NS = uuid.UUID("6f1c2d3e-0000-4000-8000-00000000c0de")

CRED_PG_RUNTIME = {"id": "credPgRuntime0001", "name": "central DB (runtime)"}
CRED_PG_JOBS = {"id": "credPgJobs000001", "name": "central DB (jobs)"}
CRED_CRYPTO = {"id": "credCryptoBroker1", "name": "Broker HMAC (n8n runtime)"}
WF_BROKER = "wfBrokerCall00001"
WF_ERROR = "wfErrorLog000001"
NO_SAVE = {"saveDataSuccessExecution": "none", "saveDataErrorExecution": "none", "saveManualExecutions": False, "saveExecutionProgress": False}
ERR_SETTINGS = {"executionOrder": "v1", "errorWorkflow": WF_ERROR, **NO_SAVE}     # لا تُحفظ بيانات التنفيذ (فيها نصوص المستخدمين)


class WF:
    def __init__(self, wid, name):
        self.id, self.name, self.nodes, self.conn = wid, name, [], {}
        self.x, self.y = 0, 0

    def add(self, name, type_, version, params, creds=None, pos=None, **extra):
        n = {"id": str(uuid.uuid5(NS, self.id + name)), "name": name, "type": type_, "typeVersion": version, "parameters": params,
             "position": pos or [self.x, self.y]}
        if creds:
            n["credentials"] = creds
        n.update(extra)
        self.nodes.append(n)
        self.x += 260
        return name

    def link(self, a, b, out=0):
        self.conn.setdefault(a, {"main": []})
        m = self.conn[a]["main"]
        while len(m) <= out:
            m.append([])
        m[out].append({"node": b, "type": "main", "index": 0})

    def chain(self, *names):
        for a, b in zip(names, names[1:]):
            self.link(a, b)

    def save(self, fname, settings=None):
        d = {"id": self.id, "name": self.name, "nodes": self.nodes, "connections": self.conn, "active": False,
             "settings": settings or {"executionOrder": "v1", **NO_SAVE}, "pinData": {}}
        (OUT / fname).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def code(w, name, js, pos=None):
    return w.add(name, "n8n-nodes-base.code", 2, {"mode": "runOnceForAllItems", "language": "javaScript", "jsCode": js}, pos=pos)


def pg(w, name, query, repl, creds, always=False):
    p = {"resource": "database", "operation": "executeQuery", "query": query, "options": {"queryReplacement": repl}}
    extra = {"alwaysOutputData": True} if always else {}
    return w.add(name, "n8n-nodes-base.postgres", 2.7, p, creds={"postgres": creds}, **extra)


def call_broker(w, name, mode="once"):
    """يستدعي sub-workflow الـ Broker. الدخل: ctx, platform, op, ad_account, params, idem في $json."""
    return w.add(name, "n8n-nodes-base.executeWorkflow", 1.3,
                 {"source": "database", "workflowId": {"__rl": True, "mode": "id", "value": WF_BROKER}, "mode": mode,
                  "options": {"waitForSubWorkflow": True}, "workflowInputs": {"mappingMode": "defineBelow", "value": None}})


# ═════════════ 00: util — استدعاء الـ Broker موقّعاً ═════════════
def util_broker():
    w = WF(WF_BROKER, "util: broker call (HMAC-signed)")
    t = w.add("Trigger", "n8n-nodes-base.executeWorkflowTrigger", 1.1, {"inputSource": "passthrough"})
    b = code(w, "Build signed request", r"""
const i = $input.first().json;
const body = JSON.stringify({ ctx: i.ctx, platform: i.platform, op: i.op, ad_account: i.ad_account == null ? null : String(i.ad_account),
  params: i.params || {}, idempotency_key: i.idem || undefined, mode: i.mode || undefined });
const ts = Math.floor(Date.now() / 1000);
const nonce = Date.now().toString(16) + Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2);
return [{ json: { body, ts, nonce, toSign: ts + '.' + nonce + '.' + body } }];
""")
    c = w.add("HMAC-SHA256", "n8n-nodes-base.crypto", 2, {"action": "hmac", "type": "SHA256", "value": "={{ $json.toSign }}",
              "dataPropertyName": "signature", "encoding": "hex"}, creds={"crypto": CRED_CRYPTO})
    h = w.add("POST /v1/call", "n8n-nodes-base.httpRequest", 4.5, {
        "method": "POST", "url": "http://broker:8080/v1/call", "sendHeaders": True, "specifyHeaders": "keypair",
        "headerParameters": {"parameters": [
            {"name": "x-key-id", "value": "n8n-runtime"}, {"name": "x-timestamp", "value": "={{ $json.ts }}"},
            {"name": "x-nonce", "value": "={{ $json.nonce }}"}, {"name": "x-signature", "value": "={{ $json.signature }}"}]},
        "sendBody": True, "contentType": "raw", "rawContentType": "application/json", "body": "={{ $json.body }}",
        "options": {"response": {"response": {"neverError": True}}, "timeout": 170000}})
    n = code(w, "Normalize result", r"""
const r = $input.first().json;
const b = (r && typeof r === 'object') ? r : {};
return [{ json: { http: undefined, ok: b.ok === true, data: b.data === undefined ? null : b.data, error: b.error || (b.ok === true ? null : { class: 'bad_response', message: 'unexpected broker response' }), meta: b.meta || null } }];
""")
    w.chain(t, b, c, h, n)
    w.save("00_util_broker_call.json")


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    util_broker()
    import importlib.util, sys
    for f in sorted(pathlib.Path(__file__).resolve().parent.glob("wf_*.py")):
        spec = importlib.util.spec_from_file_location(f.stem, f); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); m.build(sys.modules[__name__])
    print("generated:", ", ".join(sorted(p.name for p in OUT.glob("*.json"))))
