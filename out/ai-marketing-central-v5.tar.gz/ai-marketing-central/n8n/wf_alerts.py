"""Workflow 40: تنبيه مالكي العملاء عند توقف اتصال منصة (توكن منتهٍ/مُلغى/خطأ). يُرسل مرة واحدة لكل حالة (alerted_at) ويُصفَّر عند إعادة التفعيل.
لا يعالج العميل المنتهي اشتراكه (job_contexts تستثنيه). فشل الإرسال لا يُعلِّم التنبيه: يُعاد في الدورة التالية."""


def build(b):
    WF, code, pg, call_broker = b.WF, b.code, b.pg, b.call_broker
    CRJ = b.CRED_PG_JOBS
    w = WF("wfConnAlerts0001", "job: connection-down alerts to owners")
    sch = w.add("Every 15 min", "n8n-nodes-base.scheduleTrigger", 1.3, {"rule": {"interval": [{"field": "minutes", "minutesInterval": 15}]}})
    man = w.add("Manual (tests)", "n8n-nodes-base.manualTrigger", 1, {})
    ten = pg(w, "Ready tenants", "SELECT tenant_id::text AS tenant_id, ctx FROM api.job_contexts('schedule', 25)", None, CRJ)
    w.nodes[-1]["parameters"]["options"] = {}
    al = pg(w, "Pending alerts", "SELECT $1::text AS ctx, platform, status FROM api.pending_connection_alerts($1)", "={{ [$json.ctx] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    own = pg(w, "Owner chats", "SELECT $1::text AS ctx, $2::text AS platform, $3::text AS status, chat_id::text AS chat_id FROM api.list_owner_chats($1)",
             "={{ [$json.ctx, $json.platform, $json.status] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    msg = code(w, "Build messages", r"""
const names = { meta: 'Meta', tiktok: 'TikTok' }, why = { expired: 'انتهت صلاحية التوكن', revoked: 'أُلغي التفويض', error: 'خطأ بالاتصال' };
return $input.all().map(i => i.json).filter(r => r && r.chat_id).map(r => ({ json: { ctx: r.ctx, platform: 'telegram', op: 'telegram.send_message', ad_account: r.chat_id,
  params: { text: '🔔 تنبيه: ربط ' + (names[r.platform] || r.platform) + ' متوقف (' + (why[r.status] || r.status) + ').\nالإنشاء والتقارير على هذه المنصة متوقفة لحين إعادة التفويض.' }, mark: r.platform } }));
""")
    send = call_broker(w, "Send via Broker", mode="each")
    mark_plan = code(w, "Mark only delivered", r"""
const plans = $('Build messages').all().map(i => i.json);
const res = $input.all().map(i => i.json);
const seen = {}; const out = [];
res.forEach((r, i) => { const p = plans[i]; if (p && r.ok === true) { const k = p.ctx + '|' + p.mark; if (!seen[k]) { seen[k] = 1; out.push({ json: { ctx: p.ctx, platform: p.mark } }); } } });
return out.length ? out : [{ json: { ctx: '', platform: '' } }];
""")
    mark = pg(w, "Mark alerted", "SELECT CASE WHEN $1 <> '' THEN api.mark_connection_alerted($1, $2) END AS marked", "={{ [$json.ctx, $json.platform] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    w.link(sch, ten); w.link(man, ten); w.chain(ten, al, own, msg, send, mark_plan, mark)
    w.save("40_connection_alerts.json", settings=b.ERR_SETTINGS)
