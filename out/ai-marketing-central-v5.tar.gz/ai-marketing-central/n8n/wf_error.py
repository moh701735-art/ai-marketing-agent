"""Workflow 90: Error Workflow عام. أي فشل بأي Workflow مركزي يُسجَّل بـ api.log_error (tenant NULL = خطأ نظام) بعد إخفاء أنماط التوكنات.
لا يرسل تنبيهاً لأي جهة: لا يوجد مستلم/قناة تشغيل محددة بعد (قرار مؤجل)؛ الأخطاء محفوظة ويمكن قراءتها من error_log.
وفيه Workflow اختبار ذاتي يفشل عمداً للتحقق من الخط كاملاً."""


def build(b):
    WF, code, pg = b.WF, b.code, b.pg
    CRJ = b.CRED_PG_JOBS
    w = WF(b.WF_ERROR, "error: central error log")
    et = w.add("Error Trigger", "n8n-nodes-base.errorTrigger", 1, {})
    san = code(w, "Sanitize + classify", r"""
const e = $input.first().json || {};
const ex = e.execution || {}, wf = e.workflow || {};
const raw = String((ex.error && ex.error.message) || 'unknown error');
const msg = raw.replace(/\d{8,10}:[A-Za-z0-9_-]{30,}/g, '[REDACTED]').replace(/EAA[A-Za-z0-9]{20,}/g, '[REDACTED]').replace(/FAKE-[A-Za-z0-9-]{10,}/g, '[REDACTED]').replace(/(authorization|access-token|x-signature)\s*[:=]\s*\S+/ig, '$1=[REDACTED]').slice(0, 500);
const all = raw + ' ' + String(ex.error && ex.error.name) + ' ' + String(ex.error && ex.error.description);
let cls = 'UNKNOWN';
if (/ECONNREFUSED|ETIMEDOUT|ENOTFOUND|timeout|socket hang up|ECONNRESET/i.test(all)) cls = 'TRANSIENT';
else if (/forbidden|permission|not allowed/i.test(all)) cls = 'PERMISSION';
else if (/invalid_ctx|expired_ctx|unauthorized|auth/i.test(all)) cls = 'AUTH_EXPIRED';
else if (/TypeError|ReferenceError|SyntaxError|is not defined|Cannot read/i.test(all)) cls = 'BUG';
return [{ json: { cls, workflow: String(wf.name || wf.id || '').slice(0, 120), node: String((ex.lastNodeExecuted) || (ex.error && ex.error.node && ex.error.node.name) || '').slice(0, 120), execution: String(ex.id || ''), code: String((ex.error && ex.error.name) || 'Error').slice(0, 60), msg } }];
""")
    log = pg(w, "Log error (system)", "SELECT api.log_error(NULL::text, $1, NULL::text, $2, $3, $4, $5, $6)", "={{ [$json.cls, $json.workflow, $json.node, $json.execution, $json.code, $json.msg] }}", CRJ)
    w.chain(et, san, log)
    w.save("90_error_log.json")

    t = WF("wfSelfTestErr0001", "test: error workflow self-test (fails on purpose)")
    m = t.add("Manual", "n8n-nodes-base.manualTrigger", 1, {})
    boom = code(t, "Boom", "throw new TypeError('selftest boom token 123456789:AAF' + 'x'.repeat(34) + ' end');")
    hook = t.add("Webhook (tests)", "n8n-nodes-base.webhook", 2.2, {"httpMethod": "POST", "path": "selftest-error", "responseMode": "onReceived", "options": {}},
                 webhookId="5c1d8e2a-7b3f-4a6d-9e0f-1a2b3c4d5e6f")
    t.link(m, boom); t.link(hook, boom)
    t.save("91_selftest_error.json", settings=b.ERR_SETTINGS)
