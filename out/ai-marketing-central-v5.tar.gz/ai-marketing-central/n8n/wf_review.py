"""Workflow 60: حارس مراجعة الإعلانات. كل 10 دقايق يفحص حملات تيك توك التي أنشأها البوت (آخر 14 يوماً): إذا صار إعلان مرفوضاً ينبّه المالك مرة واحدة
برسالة فيها الحالة وسبب الرفض، ويقدّم طعناً تلقائياً (adgroup/appeal) بنص إنكليزي مختلف كل مرة (Gemini، وبدائل جاهزة إن تعطّل): لحد 5 محاولات بفاصل ~5 ساعات،
ويرسل تقريراً بكل محاولة. إذا زال الرفض يخبر المالك ويصفّر العدّاد. المحاولات تتوقف عند 5 نجاحات أو 3 إخفاقات.
الهوية والعزل من القاعدة (system ctx لكل tenant)."""


def build(b):
    WF, code, pg, call_broker = b.WF, b.code, b.pg, b.call_broker
    CRJ = b.CRED_PG_JOBS
    w = WF("wfReviewGuard0001", "job: ad review guard (rejection report + automatic appeals)")
    sch = w.add("Every 10 minutes", "n8n-nodes-base.scheduleTrigger", 1.3, {"rule": {"interval": [{"field": "minutes", "minutesInterval": 10}]}})
    man = w.add("Manual (tests)", "n8n-nodes-base.manualTrigger", 1, {})
    ten = pg(w, "Ready tenants", "SELECT tenant_id::text AS tenant_id, ctx FROM api.job_contexts('schedule', 25)", None, CRJ)
    w.nodes[-1]["parameters"]["options"] = {}
    lst = pg(w, "Recent campaigns", "SELECT $1::text AS ctx, platform, ad_account, external_id, name, review_status, appeal_count, appeal_fails, appeal_last_at FROM api.review_list($1)", "={{ [$json.ctx] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    plan = code(w, "Plan ad reads", r"""
const rows = $input.all().map(i => i.json).filter(r => r && r.external_id && r.platform === 'tiktok');
const groups = {};
for (const r of rows) { const k = r.ctx + '|' + r.ad_account; (groups[k] = groups[k] || { ctx: r.ctx, ad_account: r.ad_account, camps: [] }).camps.push(r); }
const out = [];
for (const g of Object.values(groups)) for (let i = 0; i < g.camps.length; i += 20) {
  const part = g.camps.slice(i, i + 20);
  out.push({ json: { ctx: g.ctx, platform: 'tiktok', op: 'tiktok.read_ads', ad_account: g.ad_account, camps: part, params: { campaign_ids: part.map(c => c.external_id), page_size: 100 } } });
}
return out;
""")
    rcall = call_broker(w, "Read ads via Broker", mode="each")
    ev = code(w, "Evaluate reviews", r"""
const plans = $('Plan ad reads').all().map(i => i.json);
const res = $input.all().map(i => i.json);
const BAD = /DENY|REJECT|DISAPPROV/i;
const MAX = 5, FAIL_MAX = 3, GAP = 5 * 3600000, now = Date.now();
const out = [];
res.forEach((r, i) => {
  const p = plans[i]; if (!p || !r.ok) return;                                  // فشل القراءة: لا قرار
  const list = ((r.data && r.data.data && r.data.data.list) || []).filter(x => x && typeof x === 'object');
  for (const c of p.camps) {
    const ads = list.filter(a => String(a.campaign_id || '') === c.external_id);
    const bad = ads.filter(a => BAD.test(String(a.secondary_status || '')));
    const count = Number(c.appeal_count) || 0, fails = Number(c.appeal_fails) || 0;
    const last = c.appeal_last_at ? (Date.parse(String(c.appeal_last_at)) || 0) : 0;
    const gap = (count === 0 && fails > 0) ? 30 * 60000 : GAP;                   // أول طعن فشل: أعد بعد نصف ساعة
    if (bad.length) {
      if (count >= MAX || fails >= FAIL_MAX || (last && now - last < gap)) continue;
      const gids = [...new Set(bad.map(a => String(a.adgroup_id || '')).filter(Boolean))].slice(0, 20);
      if (!gids.length) continue;
      out.push({ json: { kind: 'check', ctx: p.ctx, ad_account: p.ad_account, cid: c.external_id, name: c.name, attempt: count + 1, last_epoch: last, n: bad.length,
        ads: bad.slice(0, 5).map(a => ({ ad_id: String(a.ad_id || ''), adgroup_id: String(a.adgroup_id || ''), ad_name: String(a.ad_name || ''), ad_text: String(a.ad_text || ''), status: String(a.secondary_status || '') })),
        platform: 'tiktok', op: 'tiktok.read_adgroup_review', params: { adgroup_ids: gids, lang: 'en' } } });
    } else if (!bad.length && ads.length && c.review_status === 'rejected') {
      out.push({ json: { kind: 'recovered', ctx: p.ctx, cid: c.external_id, state: '', text: 'ℹ️ الحملة «' + c.name + '» ما عاد فيها إعلانات مرفوضة (انقبل المرفوض أو انحذف). تقدر تتابعها من /campaigns.' } });
    }
  }
});
return out;
""")
    sw = w.add("Kind?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.kind === 'check' ? 0 : 1 }}"})
    icall = call_broker(w, "Review info via Broker", mode="each")
    pick = code(w, "Pick appeals", r"""
const src = $('Evaluate reviews').all().map(i => i.json).filter(x => x.kind === 'check');
const out = [];
$input.all().forEach((it, i) => {
  const r = it.json, s = src[i]; if (!s || !r.ok) return;                       // فشل جلب حالة المراجعة: أعد المحاولة بعد 10 دقايق
  const d = (r.data && r.data.data) || {};
  const gmap = d.ad_group_review_map || {}, amap = d.ad_review_map || {};
  const targets = []; let reasons = '';
  for (const gid of [...new Set(s.ads.map(a => a.adgroup_id))]) {
    const rm = gmap[gid]; if (!rm || /APPEALING/i.test(String(rm.appeal_status || ''))) continue;
    const adsOf = amap[gid] || {};
    let rej = Object.keys(adsOf).filter(id => adsOf[id] && adsOf[id].is_approved === false).map(id => ({ id: String(adsOf[id].ad_id || id), a: adsOf[id] }));
    if (!rej.length && rm.is_approved === false) rej = [{ id: '', a: null }];
    for (const x of rej) {
      if (x.a && /APPEALING/i.test(String(x.a.appeal_status || ''))) continue;
      if (targets.length >= 5) break;
      targets.push(x.id ? { adgroup_id: gid, ad_id: x.id } : { adgroup_id: gid });
      const info = (x.a && x.a.reject_info && x.a.reject_info[0]) || (rm.reject_info && rm.reject_info[0]) || {};
      if (!reasons) reasons = (info.reasons || []).join('; ');
    }
  }
  if (!targets.length) return;                                                    // كلها قيد المراجعة/الطعن أصلاً
  const a0 = s.ads[0];
  out.push({ json: { ctx: s.ctx, ad_account: s.ad_account, cid: s.cid, name: s.name, attempt: s.attempt, last_epoch: s.last_epoch, n: s.n, status: a0.status, ad_name: a0.ad_name, targets, reasons,
    platform: 'llm', op: 'llm.appeal_text', params: { status: a0.status.slice(0, 60), ad_text: a0.ad_text.slice(0, 300), ad_name: a0.ad_name.slice(0, 200), reason: reasons.slice(0, 300), attempt: String(s.attempt) } } });
});
return out;
""")
    acall = call_broker(w, "Appeal text via Broker", mode="each")
    build = code(w, "Build appeals", r"""
const src = $('Pick appeals').all().map(i => i.json);
const FALLBACK = [
  (s) => 'Dear TikTok Ads Review Team, we respectfully request a manual re-review of our ad "' + s.name + '". We believe it follows the advertising policies' + (s.reasons ? ' and we could not identify the issue mentioned ("' + s.reasons + '")' : '') + '. If a specific change is needed, please tell us exactly what and we will adjust it immediately. Thank you.',
  (s) => 'Hello, could a human reviewer please take another look at ad "' + s.name + '"? We prepared it according to the guidelines' + (s.reasons ? ' (rejection note: "' + s.reasons + '")' : '') + ' and are happy to edit any wording you point out. Many thanks for your help.',
  (s) => 'Hi Ads Support, this is a request to re-evaluate the rejected ad "' + s.name + '". We are a genuine advertiser and want to stay fully compliant' + (s.reasons ? '; please clarify how "' + s.reasons + '" applies to our creative' : '') + '. We will fix anything specific right away.',
  (s) => 'Good day. Following up on our earlier review request for ad "' + s.name + '": we still believe it meets the policies' + (s.reasons ? ' despite the note "' + s.reasons + '"' : '') + '. Kindly have it checked manually once more. Thank you for your time.',
  (s) => 'To the Ads Review Team: this is our final request for ad "' + s.name + '". We are open to changing any phrase that concerns you' + (s.reasons ? ' (cited reason: "' + s.reasons + '")' : '') + ' and appreciate a fresh manual review. Best regards.'
];
const out = [];
$input.all().forEach((it, i) => {
  const r = it.json, s = src[i]; if (!s) return;
  const d = (r.ok === true && r.data) ? r.data : {};
  const text = String(d.appeal || FALLBACK[(s.attempt - 1) % FALLBACK.length](s)).slice(0, 1000);
  s.targets.forEach((t, k) => {
    out.push({ json: { ci: i, ctx: s.ctx, platform: 'tiktok', op: 'tiktok.appeal_adgroup', ad_account: s.ad_account,
      params: Object.assign({ adgroup_id: t.adgroup_id, appeal_reason: text }, t.ad_id ? { ad_id: t.ad_id } : {}),
      idem: 'appeal-' + s.cid + '-' + s.attempt + '-' + t.adgroup_id + '-' + (t.ad_id || 'g') + '-' + s.last_epoch, text } });
  });
});
return out;
""")
    pcall = call_broker(w, "Submit appeals via Broker", mode="each")
    amsg = code(w, "Compose appeal report", r"""
const camps = $('Pick appeals').all().map(i => i.json);
const llm = $('Appeal text via Broker').all().map(i => i.json);
const reqs = $('Build appeals').all().map(i => i.json);
const by = {};
$input.all().forEach((it, i) => {
  const r = it.json, q = reqs[i]; if (!q) return;
  const code0 = (r.data && typeof r.data.code === 'number') ? r.data.code : 0;
  const ok = r.ok === true && code0 === 0;
  const e = (by[q.ci] = by[q.ci] || { ok: 0, bad: 0, err: '', text: q.text });
  if (ok) e.ok++; else { e.bad++; e.err = e.err || String((r.error && r.error.message) || (r.data && r.data.message) || 'خطأ غير معروف').slice(0, 160); }
});
return Object.keys(by).map(k => {
  const s = camps[k], e = by[k], l = llm[k], tips = (l && l.ok === true && l.data && l.data.tips) || [];
  const okAny = e.ok > 0;
  let t = (okAny ? '📨 طعن تلقائي على إعلان مرفوض (محاولة ' + s.attempt + '/5)' : '⚠️ فشل الطعن التلقائي (محاولة ' + s.attempt + '/5)') + '\n• الحملة: «' + s.name + '» (' + s.cid + ')\n• الإعلان: ' + (s.ad_name || '؟') + (s.n > 1 ? ' + ' + (s.n - 1) + ' ثانية' : '') + '\n• الحالة: ' + s.status;
  if (s.reasons) t += '\n• سبب الرفض من تيك توك: ' + s.reasons;
  t += '\n• النتيجة: ' + (e.ok ? '✅ انرسل ' + e.ok : '') + (e.ok && e.bad ? ' | ' : '') + (e.bad ? '❌ فشل ' + e.bad + ' (' + e.err + ')' : '');
  t += '\n\n📝 نص الطعن (إنكليزي، مختلف عن المحاولات السابقة):\n' + e.text;
  if (s.attempt === 1 && tips.length) t += '\n\n💡 نصايح لتفادي الرفض:\n' + tips.map(x => '• ' + x).join('\n');
  t += okAny ? (s.attempt >= 5 ? '\n\n⚠️ هذي آخر محاولة تلقائية. إذا بقت مرفوضة عدّل الإعلان أو اطلب حملة جديدة.' : '\n\n🔁 إذا بقت مرفوضة أعيد الطعن بعد ~5 ساعات بنص مختلف، وكل مرة أرسلك تقرير.') : '\n\nراح أحاول مرة ثانية قريباً. إذا استمر الفشل ' + (3) + ' مرات أوقف وأخبرك.';
  return { json: { ctx: s.ctx, cid: s.cid, ok: okAny, text: t.slice(0, 3800) } };
});
""")
    rec = pg(w, "Record appeal", "SELECT $1::text AS ctx, $4::text AS text, api.appeal_update($1, 'tiktok', $2, $3::boolean) AS ok", "={{ [$json.ctx, $json.cid, $json.ok, $json.text] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    rec2 = pg(w, "Record state", "SELECT $1::text AS ctx, $4::text AS text, api.review_update($1, 'tiktok', $2, $3) AS ok", "={{ [$json.ctx, $json.cid, $json.state, $json.text] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    own = pg(w, "Owners", "SELECT $1::text AS ctx, $2::text AS text, chat_id::text AS chat_id FROM api.list_owner_chats($1)", "={{ [$json.ctx, $json.text] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    comp = code(w, "Compose messages", r"""
return $input.all().map(i => i.json).filter(r => r && r.chat_id && r.text)
  .map(r => ({ json: { ctx: r.ctx, platform: 'telegram', op: 'telegram.send_message', ad_account: r.chat_id, params: { text: String(r.text).slice(0, 3800) } } }));
""")
    send = call_broker(w, "Send via Broker", mode="each")
    done = code(w, "Summary", r"""
const r = $input.all().map(i => i.json);
return [{ json: { sent: r.filter(x => x.ok === true).length, failed: r.filter(x => x.ok !== true).length } }];
""")
    w.link(sch, ten); w.link(man, ten); w.chain(ten, lst, plan, rcall, ev, sw)
    w.link(sw, icall, 0); w.chain(icall, pick, acall, build, pcall, amsg, rec); w.link(sw, rec2, 1)
    w.link(rec, own); w.link(rec2, own); w.chain(own, comp, send, done)
    w.save("60_review_guard.json", settings=b.ERR_SETTINGS)
