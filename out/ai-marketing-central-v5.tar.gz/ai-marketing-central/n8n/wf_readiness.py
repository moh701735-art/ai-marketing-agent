"""Workflow 30: منفِّذ فحوصات الجاهزية R01–R15 + ترقية READY + sweep. يعمل بسياق system من القاعدة (لا tenant_id يدوي).
المنصات تُفحص عبر الـ Broker بنمط readiness (قراءة/اختبار فقط، لا كتابة). فحوصات القاعدة (R01,R13,R14,R15) تأتي من api.readiness_local.
فحص يُعاد فقط إذا لم يكن ناجحاً أو اقترب انتهاؤه (نصف عمره)، عدا R02/R03 (رخيصان وتنتهي صلاحيتهما بسرعة)."""


def build(b):
    WF, code, pg, call_broker = b.WF, b.code, b.pg, b.call_broker
    CRJ = b.CRED_PG_JOBS
    w = WF("wfReadiness00001", "job: readiness runner + promote + sweep")
    sch = w.add("Every 6 hours", "n8n-nodes-base.scheduleTrigger", 1.3, {"rule": {"interval": [{"field": "hours", "hoursInterval": 6}]}})
    man = w.add("Manual (tests)", "n8n-nodes-base.manualTrigger", 1, {})
    ten = pg(w, "Probeable tenants", "SELECT tenant_id::text AS tenant_id, ctx FROM api.job_contexts_for_status(ARRAY['TESTING','NEEDS_REVIEW','READY'], 25)", None, CRJ)
    w.nodes[-1]["parameters"]["options"] = {}
    facts = pg(w, "Facts + local checks",
               "SELECT $1::text AS ctx, $2::text AS tenant_id, api.readiness_facts($1) AS facts, "
               "(SELECT coalesce(jsonb_agg(jsonb_build_object('check_code', l.check_code, 'status', l.status, 'evidence', l.evidence)), '[]'::jsonb) FROM api.readiness_local($1) l) AS local_checks",
               "={{ [$json.ctx, $json.tenant_id] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    plan = code(w, "Plan probes", r"""
const tenants = $input.all().map(i => i.json).filter(t => t && t.facts);
const now = Date.now();
const out = [];
for (const t of tenants) {
  const f = t.facts, feat = f.features || {}, accts = f.accounts || [];
  const due = (code, always) => { if (always) return true; const c = (f.checks || {})[code]; return !c || c.status !== 'pass' || (Date.parse(c.expires_at) - now) < (c.max_age_secs * 1000) / 2; };
  const add = (check, platform, op, ad_account, params) => out.push({ json: { ctx: t.ctx, tenant_id: t.tenant_id, check, platform, op, ad_account: ad_account || null, params: params || {}, mode: 'readiness' } });
  const metaAccts = accts.filter(a => a.platform === 'meta'), ttAccts = accts.filter(a => a.platform === 'tiktok');
  add('R02', 'telegram', 'telegram.get_me');
  add('R03', 'telegram', 'telegram.get_webhook_info');
  if (due('R04') && (f.owners || []).length) add('R04', 'telegram', 'telegram.send_message', String(f.owners[0]), { text: '✅ فحص الجاهزية: اتصال البوت يعمل.' });
  if (feat.tiktok && due('R05')) { if (ttAccts.length) add('R05', 'tiktok', 'tiktok.read_advertiser', ttAccts[0].external_id, {}); }
  if (feat.meta && due('R06')) add('R06', 'meta', 'meta.me', null, {});
  if (feat.meta && due('R07')) add('R07', 'meta', 'meta.permissions', null, {});
  if (due('R08')) for (const a of accts) add('R08', a.platform, a.platform === 'meta' ? 'meta.read_account' : 'tiktok.read_advertiser', a.external_id, a.platform === 'meta' ? { fields: 'id,name' } : {});
  if (feat.meta && due('R09')) add('R09', 'meta', 'meta.read_pages', null, {});
  if (due('R10')) {
    const other = tenants.filter(o => o.tenant_id !== t.tenant_id).flatMap(o => (o.facts.accounts || []).filter(a => feat[a.platform]));
    if (other.length) { const a = other[0]; add('R10', a.platform, a.platform === 'meta' ? 'meta.read_account' : 'tiktok.read_advertiser', a.external_id, a.platform === 'meta' ? { fields: 'id' } : {}); }
  }
  if (feat.meta && metaAccts.length && due('R11')) add('R11', 'meta', 'meta.validate_campaign', metaAccts[0].external_id, { name: 'readiness-probe', objective: 'OUTCOME_TRAFFIC' });
  if (due('R12')) {
    const today = new Date().toISOString().slice(0, 10);
    if (metaAccts.length) add('R12', 'meta', 'meta.read_insights', metaAccts[0].external_id, { date_preset: 'today', fields: 'spend,impressions,clicks', level: 'account' });
    if (ttAccts.length) add('R12', 'tiktok', 'tiktok.read_report', ttAccts[0].external_id, { report_type: 'BASIC', data_level: 'AUCTION_ADVERTISER', dimensions: ['advertiser_id'], metrics: ['spend', 'impressions', 'clicks'], start_date: today, end_date: today });
  }
}
return out;
""")
    rcall = call_broker(w, "Probe via Broker", mode="each")
    ev = code(w, "Evaluate", r"""
const tenants = $('Facts + local checks').all().map(i => i.json).filter(t => t && t.facts);
const plans = $('Plan probes').all().map(i => i.json);
const res = $input.all().map(i => i.json);
const by = {};                                    // tenant -> check -> [{plan,res}]
res.forEach((r, i) => { const p = plans[i]; if (!p) return; ((by[p.tenant_id] = by[p.tenant_id] || {})[p.check] = (by[p.tenant_id][p.check] || [])).push({ p, r }); });
const cls = r => (r.error && (r.error.message || r.error.class)) || 'error';
const out = [];
for (const t of tenants) {
  const f = t.facts, feat = f.features || {}, mine = by[t.tenant_id] || {};
  const put = (check_code, status, evidence) => out.push({ json: { ctx: t.ctx, tenant_id: t.tenant_id, check_code, status, evidence } });
  for (const l of t.local_checks || []) put(l.check_code, l.status, l.evidence);
  const all = (code, fn) => { const xs = mine[code]; if (!xs) return; const bad = xs.filter(x => !fn(x.r, x.p)); put(code, bad.length ? 'fail' : 'pass', { probes: xs.length, failed: bad.map(x => cls(x.r)).slice(0, 5) }); };
  all('R02', r => r.ok === true && r.data && r.data.result && r.data.result.is_bot !== false);
  all('R03', r => r.ok === true && r.data && r.data.result && !!r.data.result.url && !r.data.result.last_error_message && (r.data.result.pending_update_count || 0) < 100);
  all('R04', r => r.ok === true);
  all('R05', r => r.ok === true && r.data && r.data.data && (r.data.data.list || []).length > 0);
  all('R06', r => r.ok === true);
  all('R07', r => { const g = ((r.data && r.data.data) || []).filter(x => x.status === 'granted').map(x => x.permission); return r.ok === true && ['ads_management', 'ads_read'].every(s => g.includes(s)); });
  all('R08', r => r.ok === true);
  if (due_missing(f, 'R08') && (f.accounts || []).length === 0) put('R08', 'fail', { reason: 'no ad accounts linked' });
  all('R09', r => { const d = (r.data && r.data.data) || []; return r.ok === true && d.length > 0; });
  all('R10', r => r.ok === false && r.error && r.error.message === 'ad_account_not_owned_or_disabled');
  if (!mine['R10'] && !((f.checks || {}).R10 && f.checks.R10.status === 'pass')) put('R10', 'unknown', { reason: 'no foreign ad account available to test against' });
  all('R11', r => r.ok === true);
  if (!feat.meta && !mine['R11']) put('R11', feat.tiktok ? 'pass' : 'warn', feat.tiktok ? { mode: 'tiktok_forced_disable', reason: 'TikTok has no dry-run; Broker catalog forces operation_status=DISABLE on every TikTok write (only create_campaign exists)' } : { reason: 'no platform dry-run available for this tenant' });
  all('R12', r => r.ok === true);
  const notPass = c => !(f.checks || {})[c] || f.checks[c].status !== 'pass';
  if (feat.tiktok && !mine.R05 && notPass('R05')) put('R05', 'fail', { reason: 'no tiktok ad account linked' });
  if (feat.meta && !mine.R11 && notPass('R11')) put('R11', 'fail', { reason: 'no meta ad account linked' });
  if (!mine.R12 && notPass('R12')) put('R12', 'fail', { reason: 'no ad account to read from' });
}
function due_missing(f, c) { return !(f.checks || {})[c] || f.checks[c].status !== 'pass'; }
return out;
""")
    rec = pg(w, "Record check", "SELECT api.set_readiness($1, $2, $3, $4::jsonb)", "={{ [$json.ctx, $json.check_code, $json.status, JSON.stringify($json.evidence)] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    prom_plan = code(w, "Which to promote", r"""
const tenants = $('Facts + local checks').all().map(i => i.json).filter(t => t && t.facts && t.facts.status !== 'READY');
const items = tenants.map(t => ({ json: { ctx: t.ctx, tenant_id: t.tenant_id } }));
return items.length ? items : [{ json: { ctx: '', tenant_id: '' } }];     // عنصر فارغ كي تبقى السلسلة تعمل إلى الـ sweep
""")
    prom = pg(w, "Promote READY (gate in DB)", "SELECT $2::text AS tenant_id, CASE WHEN $1 <> '' THEN api.try_promote_ready($1) END AS promoted", "={{ [$json.ctx, $json.tenant_id] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    sweep = pg(w, "Sweep (demote on failed/expired)", "SELECT api.run_readiness_sweep() AS demoted", None, CRJ)
    w.nodes[-1]["parameters"]["options"] = {}
    w.nodes[-1]["executeOnce"] = True
    w.nodes[-1]["alwaysOutputData"] = True
    w.link(sch, ten); w.link(man, ten); w.chain(ten, facts, plan, rcall, ev, rec, prom_plan, prom, sweep)
    w.save("30_readiness.json", settings=b.ERR_SETTINGS)
