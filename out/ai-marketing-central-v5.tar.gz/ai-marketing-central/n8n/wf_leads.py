"""Workflow 70: سحب طلبات الاستمارات (Lead Gen). كل 10 دقايق، لكل حساب تيك توك: يجلب صفحات الاستمارة المنشورة، يسحب طلباتها عبر الـBroker
(tiktok.pull_leads: مهمة تنزيل ← CSV)، يستبعد المُرسَل سابقاً (api.leads_mark) والأقدم من 48 ساعة، ويدز الجديد لمالكي العميل بتيليجرام.
إذا فشل إرسال دفعة بالكامل يُلغى تعليمها فتُعاد بالدورة القادمة. الهوية والعزل من القاعدة."""


def build(b):
    WF, code, pg, call_broker = b.WF, b.code, b.pg, b.call_broker
    CRJ = b.CRED_PG_JOBS
    w = WF("wfLeadsPull000001", "job: lead forms pull (new leads to owner)")
    sch = w.add("Every 10 minutes", "n8n-nodes-base.scheduleTrigger", 1.3, {"rule": {"interval": [{"field": "minutes", "minutesInterval": 10}]}})
    man = w.add("Manual (tests)", "n8n-nodes-base.manualTrigger", 1, {})
    ten = pg(w, "Ready tenants", "SELECT tenant_id::text AS tenant_id, ctx FROM api.job_contexts('schedule', 25)", None, CRJ)
    w.nodes[-1]["parameters"]["options"] = {}
    acc = pg(w, "TikTok accounts", "SELECT $1::text AS ctx, external_id FROM api.list_ad_accounts($1) WHERE enabled AND platform = 'tiktok'", "={{ [$json.ctx] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    plan1 = code(w, "Plan page reads", r"""
return $input.all().map(i => i.json).filter(r => r && r.ctx && r.external_id)
  .map(r => ({ json: { ctx: r.ctx, platform: 'tiktok', op: 'tiktok.read_instant_pages', ad_account: String(r.external_id), params: { business_type: 'LEAD_GEN', status: 'PUBLISHED' } } }));
""")
    c1 = call_broker(w, "Read form pages via Broker", mode="each")
    plan2 = code(w, "Plan lead pulls", r"""
const plans = $('Plan page reads').all().map(i => i.json);
const bucket = Math.floor(Date.now() / 600000);
const out = [], per = {};
$input.all().forEach((it, i) => {
  const r = it.json, p = plans[i]; if (!p || !r.ok) return;
  const list = ((r.data && r.data.data && r.data.data.list) || []).filter(x => x && x.page_id);
  for (const pg of list) {
    per[p.ctx] = (per[p.ctx] || 0) + 1; if (per[p.ctx] > 15) break;                   // حد معقول لكل عميل بالدورة
    out.push({ json: { ctx: p.ctx, platform: 'tiktok', op: 'tiktok.pull_leads', ad_account: p.ad_account, params: { page_id: String(pg.page_id) },
      idem: 'leads-' + pg.page_id + '-' + p.ad_account.slice(-6) + '-' + bucket, title: String(pg.title || '').slice(0, 60) } });
  }
});
return out;
""")
    c2 = call_broker(w, "Pull leads via Broker", mode="each")
    coll = code(w, "Collect fresh leads", r"""
const plans = $('Plan lead pulls').all().map(i => i.json);
const WINDOW = 48 * 3600000, CAP = 30, now = Date.now();
const parseT = (s) => { const t = Date.parse(String(s || '').replace(' ', 'T') + (/[zZ]|[+-]\d\d:?\d\d$/.test(String(s)) ? '' : 'Z')); return isNaN(t) ? null : t; };
const byCtx = {};
$input.all().forEach((it, i) => {
  const r = it.json, p = plans[i]; if (!p || !r.ok) return;
  for (const l of ((r.data && r.data.rows) || [])) {
    const t = parseT(l.time);
    if (t !== null && now - t > WINDOW) continue;                                      // أقدم من 48 ساعة: لا نزعج المالك بالقديم
    (byCtx[p.ctx] = byCtx[p.ctx] || []).push({ key: 'tt:' + p.params.page_id + ':' + l.lead_id, form: p.title, acct: p.ad_account, t: t || 0, time: l.time || '', f: l.fields || {} });
  }
});
return Object.entries(byCtx).map(([ctx, arr]) => { arr.sort((a, b) => b.t - a.t); const top = arr.slice(0, CAP); return { json: { ctx, leads: JSON.stringify(top), keys: JSON.stringify(top.map(x => x.key)) } }; });
""")
    mark = pg(w, "Mark seen", "SELECT $1::text AS ctx, $2::text AS leads, to_jsonb(api.leads_mark($1, ARRAY(SELECT jsonb_array_elements_text($3::jsonb)))) AS fresh",
              "={{ [$json.ctx, $json.leads, $json.keys] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    batch = code(w, "Compose batches", r"""
const LABEL = { name: 'الاسم', full_name: 'الاسم', first_name: 'الاسم', last_name: 'اللقب', phone_number: 'الهاتف', phone: 'الهاتف', email: 'الإيميل', address: 'العنوان', city: 'المدينة', province: 'المحافظة', campaign_name: 'الحملة', ad_name: 'الإعلان' };
const out = [];
for (const it of $input.all()) {
  const r = it.json; if (!r || !r.ctx) continue;
  let fresh = r.fresh; if (typeof fresh === 'string') { try { fresh = JSON.parse(fresh); } catch (e) { fresh = []; } }
  const set = new Set(Array.isArray(fresh) ? fresh : []);
  let leads = []; try { leads = JSON.parse(r.leads).filter(l => set.has(l.key)); } catch (e) {}
  if (!leads.length) continue;
  leads.sort((a, b) => a.t - b.t);                                                    // الأقدم أولاً داخل الرسالة
  const fmt = (l, n) => {
    const lines = Object.entries(l.f).map(([k, v]) => '   ' + (LABEL[k.toLowerCase()] || k) + ': ' + v);
    return n + ') ' + (l.time ? '🕒 ' + l.time + '\n' : '') + lines.join('\n');
  };
  let cur = [], len = 0, bid = 0;
  const flush = () => { if (!cur.length) return; bid++; const head = '📥 طلبات جديدة من الاستمارة «' + (cur[0].form || 'بدون اسم') + '» (حساب ..' + String(cur[0].acct).slice(-5) + '):\n\n';
    out.push({ json: { ctx: r.ctx, bid: r.ctx.slice(-8) + '-' + out.length, text: (head + cur.map((x, i) => fmt(x, i + 1)).join('\n\n')).slice(0, 3800), keys: JSON.stringify(cur.map(x => x.key)) } }); cur = []; len = 0; };
  let lastForm = null;
  for (const l of leads) {
    const s = fmt(l, 1).length + 2;
    if (cur.length && (l.form !== lastForm || len + s > 3300 || cur.length >= 8)) flush();
    cur.push(l); len += s; lastForm = l.form;
  }
  flush();
}
return out;
""")
    own = pg(w, "Owners", "SELECT $1::text AS ctx, $2::text AS text, $3::text AS bid, chat_id::text AS chat_id FROM api.list_owner_chats($1)", "={{ [$json.ctx, $json.text, $json.bid] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    comp = code(w, "Compose messages", r"""
return $input.all().map(i => i.json).filter(r => r && r.chat_id && r.text)
  .map(r => ({ json: { ctx: r.ctx, bid: r.bid, platform: 'telegram', op: 'telegram.send_message', ad_account: r.chat_id, params: { text: String(r.text).slice(0, 3800) } } }));
""")
    send = call_broker(w, "Send via Broker", mode="each")
    fail = code(w, "Failed batches", r"""
const sent = $('Compose messages').all().map(i => i.json);
const ok = {}; $input.all().forEach((it, i) => { const m = sent[i]; if (!m) return; ok[m.bid] = ok[m.bid] || it.json.ok === true; });
const batches = $('Compose batches').all().map(i => i.json);
return batches.filter(b => ok[b.bid] !== true).map(b => ({ json: { ctx: b.ctx, keys: b.keys } }));            // لم يصل لأي مالك: أعد تعليمها كجديدة
""")
    unm = pg(w, "Unmark failed", "SELECT $1::text AS ctx, api.leads_unmark($1, ARRAY(SELECT jsonb_array_elements_text($2::jsonb))) AS n", "={{ [$json.ctx, $json.keys] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    w.link(sch, ten); w.link(man, ten)
    w.chain(ten, acc, plan1, c1, plan2, c2, coll, mark, batch, own, comp, send, fail, unm)
    w.save("70_leads_pull.json", settings=b.ERR_SETTINGS)
