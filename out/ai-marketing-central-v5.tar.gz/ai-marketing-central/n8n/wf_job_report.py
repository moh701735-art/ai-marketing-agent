"""Workflow 20: تقرير مجدول (كل ساعة) لمالكي كل tenant جاهز. يدور على tenants بسياق system من القاعدة، لا tenant_id يدوي.
فشل tenant واحد (بلا بوت/توكن منتهٍ) لا يوقف البقية: كل نداء Broker يرجع نتيجة ولو فاشلة."""


def build(b):
    WF, code, pg, call_broker = b.WF, b.code, b.pg, b.call_broker
    CRJ = b.CRED_PG_JOBS
    w = WF("wfJobReport00001", "job: scheduled report (all ready tenants)")
    sch = w.add("Every hour", "n8n-nodes-base.scheduleTrigger", 1.3, {"rule": {"interval": [{"field": "hours", "hoursInterval": 1}]}})
    man = w.add("Manual (tests)", "n8n-nodes-base.manualTrigger", 1, {})
    ten = pg(w, "Ready tenants", "SELECT tenant_id::text AS tenant_id, ctx FROM api.job_contexts('schedule', 25)", None, CRJ)
    ten_node = w.nodes[-1]; ten_node["parameters"]["options"] = {}
    own = pg(w, "Owner chats", "SELECT $1::text AS ctx, chat_id::text AS chat_id FROM api.list_owner_chats($1)", "={{ [$json.ctx] }}", CRJ)
    own_node = w.nodes[-1]; own_node["onError"] = "continueRegularOutput"
    acc = pg(w, "Enabled accounts", "SELECT $1::text AS ctx, $2::text AS chat_id, platform, external_id, name, currency FROM api.list_ad_accounts($1) WHERE enabled", "={{ [$json.ctx, $json.chat_id] }}", CRJ)
    acc_node = w.nodes[-1]; acc_node["onError"] = "continueRegularOutput"
    plan = code(w, "Plan calls", r"""
const today = new Date(Date.now() + 3 * 3600000).toISOString().slice(0, 10);       // يوم بغداد (حسابات التيك توك هنا بتوقيت العراق)
const items = [];
for (const r of $input.all().map(i => i.json).filter(r => r && r.external_id)) {
  if (r.platform === 'meta') items.push({ json: { ctx: r.ctx, chatId: r.chat_id, platform: 'meta', op: 'meta.read_insights', ad_account: r.external_id, params: { date_preset: 'today', fields: 'spend,impressions,clicks', level: 'account' }, label: (r.name && r.name !== r.external_id) ? r.name : '..' + String(r.external_id).slice(-5), kind: 'acct', cur: String(r.currency || '').toUpperCase() } });
  else {
    items.push({ json: { ctx: r.ctx, chatId: r.chat_id, platform: 'tiktok', op: 'tiktok.read_report', ad_account: r.external_id, params: { report_type: 'BASIC', data_level: 'AUCTION_ADVERTISER', dimensions: ['advertiser_id'], metrics: ['spend', 'impressions', 'clicks'], start_date: today, end_date: today }, label: (r.name && r.name !== r.external_id) ? r.name : '..' + String(r.external_id).slice(-5), kind: 'acct', cur: String(r.currency || '').toUpperCase() } });
  }
}
return items;
""")
    rcall = call_broker(w, "Read via Broker", mode="each")
    fmt = code(w, "Format per owner", r"""
const plans = $('Plan calls').all().map(i => i.json);
const res = $input.all().map(i => i.json);
const n2 = v => { const x = parseFloat(v); return Number.isFinite(x) ? x : 0; };
const groups = {};
res.forEach((r, i) => {
  const p = plans[i]; if (!p) return;
  const k = p.ctx + '|' + p.chatId; const g = groups[k] = groups[k] || { ctx: p.ctx, chatId: p.chatId, rows: [], bad: [], idle: 0, total: 0 };
  const tag = (p.platform === 'meta' ? 'Meta' : 'TikTok') + ' ' + p.label;
  if (!r.ok) { g.bad.push('⚠️ ' + tag + ': ما كدرت أجيب البيانات (' + ((r.error && r.error.class) || 'خطأ') + ')'); return; }
  const m = p.platform === 'meta' ? ((r.data && r.data.data && r.data.data[0]) || {}) : (((r.data && r.data.data && r.data.data.list && r.data.data.list[0]) || {}).metrics || {});
  const sp = n2(m.spend), im = n2(m.impressions), cl = n2(m.clicks);
  const iqd = p.cur === 'IQD', spUsd = iqd ? sp / 1310 : sp;                         // الدينار: نعرضه بالدينار ونضيفه للإجمالي محوّلاً للدولار
  g.total += spUsd; if (iqd) g.iqd = true;
  if (sp > 0 || im > 0 || cl > 0) g.rows.push({ sp: spUsd, line: '• ' + tag + ' — صرف ' + (iqd ? Math.round(sp).toLocaleString('en-US') + ' د.ع' : sp.toFixed(2) + '$') + ' | ظهور ' + im + ' | نقرات ' + cl });
  else g.idle++;
});
return Object.values(groups).map(g => {
  g.rows.sort((a, b) => b.sp - a.sp);
  const lines = g.rows.map(x => x.line).concat(g.bad);
  if (!g.rows.length && !g.bad.length) lines.push('ما في صرف اليوم بأي حساب.');
  if (g.idle) lines.push('(' + g.idle + ' حساب بدون صرف اليوم)');
  const body = lines.join('\n') + (g.rows.length > 1 ? '\n\n💰 إجمالي الصرف اليوم: ' + g.total.toFixed(2) + '$' + (g.iqd ? ' (حسابات الدينار محوّلة ÷1310)' : '') : '');
  return { json: { ctx: g.ctx, platform: 'telegram', op: 'telegram.send_message', ad_account: g.chatId, params: { text: ('🕐 التقرير المجدول\n' + body).slice(0, 3800) } } };
});
""")
    send = call_broker(w, "Send via Broker", mode="each")
    done = code(w, "Summary", r"""
const r = $input.all().map(i => i.json);
return [{ json: { sent: r.filter(x => x.ok === true).length, failed: r.filter(x => x.ok !== true).length } }];
""")
    w.link(sch, ten); w.link(man, ten); w.chain(ten, own, acc, plan, rcall, fmt, send, done)
    w.save("20_job_report.json", settings=b.ERR_SETTINGS)
