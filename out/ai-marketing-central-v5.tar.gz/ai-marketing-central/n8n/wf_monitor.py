"""Workflow 50: حارس التكلفة. كل 10 دقايق: للحملات المفعّلة بمراقبة (تفعيل صريح من المستخدم) يقرأ تكلفة النتيجة من تيك توك،
ينبّه المالك عند مستويات (مثل 0.15/0.20/0.30$) ويوقف الحملة تلقائياً عند السقف. الإيقاف يخفّض الصرف فقط (لا تفعيل آلي أبداً).
الهوية والعزل من القاعدة (system ctx لكل tenant)؛ فشل tenant لا يوقف الباقين."""


def build(b):
    WF, code, pg, call_broker = b.WF, b.code, b.pg, b.call_broker
    CRJ = b.CRED_PG_JOBS
    w = WF("wfCostGuard00001", "job: cost guard (alerts + auto-stop)")
    sch = w.add("Every 10 minutes", "n8n-nodes-base.scheduleTrigger", 1.3, {"rule": {"interval": [{"field": "minutes", "minutesInterval": 10}]}})
    man = w.add("Manual (tests)", "n8n-nodes-base.manualTrigger", 1, {})
    ten = pg(w, "Ready tenants", "SELECT tenant_id::text AS tenant_id, ctx FROM api.job_contexts('schedule', 25)", None, CRJ)
    w.nodes[-1]["parameters"]["options"] = {}
    watch = pg(w, "Watched campaigns",
               "SELECT $1::text AS ctx, platform, ad_account, external_id, name, activated_at::date::text AS since, extract(epoch FROM activated_at)::bigint AS act_epoch, "
               "rule_alerts::text AS alerts, rule_stop::text AS stop, rule_last_level::text AS last_level, "
               "(SELECT a.currency FROM api.list_ad_accounts($1) a WHERE a.external_id = w.ad_account LIMIT 1) AS cur FROM api.watch_list($1) AS w", "={{ [$json.ctx] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    plan = code(w, "Plan reports", r"""
const rows = $input.all().map(i => i.json).filter(r => r && r.external_id && r.platform === 'tiktok');
const loc = new Date(Date.now() + 3 * 3600000), end = loc.toISOString().slice(0, 10);
const groups = {};
for (const r of rows) { const k = r.ctx + '|' + r.ad_account; (groups[k] = groups[k] || { ctx: r.ctx, ad_account: r.ad_account, rules: [] }).rules.push(r); }
return Object.values(groups).map(g => {
  const since = g.rules.map(r => r.since).sort()[0];
  const start = new Date(Date.parse(since + 'T00:00:00Z') - 86400000).toISOString().slice(0, 10);
  return { json: { ctx: g.ctx, platform: 'tiktok', op: 'tiktok.read_report', ad_account: g.ad_account, rules: g.rules,
    params: { report_type: 'BASIC', data_level: 'AUCTION_AD', dimensions: ['ad_id'], metrics: ['campaign_id', 'campaign_name', 'spend', 'impressions', 'clicks', 'result'], start_date: start, end_date: end, page_size: 1000 } } };      // مستوى الإعلان (مثل الورك فلو القديم): مستوى الحملة يرجّع result=0 لحملات الواتساب
});
""")
    rcall = call_broker(w, "Read via Broker", mode="each")
    ev = code(w, "Evaluate", r"""
const plans = $('Plan reports').all().map(i => i.json);
const res = $input.all().map(i => i.json);
const num = v => { const n = parseFloat(v); return Number.isFinite(n) ? n : null; };
const out = [];
res.forEach((r, i) => {
  const p = plans[i]; if (!p || !r.ok) return;                        // فشل القراءة: لا قرار (لا إيقاف ولا تنبيه بدون بيانات)
  const list = (r.data && r.data.data && r.data.data.list) || [];
  const byId = {}; list.forEach(x => { const m0 = (x && x.metrics) || {}, cid = String(m0.campaign_id || (x.dimensions && x.dimensions.campaign_id) || ''); if (!cid) return; const t = byId[cid] || (byId[cid] = { spend: 0, result: 0 }); t.spend += num(m0.spend) || 0; t.result += num(m0.result) || 0; });
  for (const rule of p.rules) {
    const m = byId[rule.external_id]; if (!m) continue;
    const k = String(rule.cur || '').toUpperCase() === 'IQD' ? 1 / 1310 : 1;      // حسابات الدينار: نحوّل للدولار (÷1310) قبل مقارنة السقوف
    const spend = (num(m.spend) || 0) * k, result = num(m.result) || 0;
    let cpr = num(m.cost_per_result); cpr = cpr > 0 ? cpr * k : (result > 0 ? spend / result : null);
    const noRes = result < 1;
    if (noRes) { if (spend <= 0) continue; cpr = spend / 2; }          // بلا نتائج: مثل الورك فلو القديم نوقف عند ضعف السقف (تحمّل مرحلة التعلم)
    if (cpr === null) continue;
    const alerts = String(rule.alerts || '').replace(/[{}]/g, '').split(',').map(num).filter(x => x > 0).sort((a, b) => a - b);
    const stop = num(rule.stop), last = num(rule.last_level) || 0;
    const nm = '«' + rule.name + '»';
    const stats = 'الصرف: ' + spend.toFixed(2) + '$ | النتائج: ' + result + ' | تكلفة النتيجة: ' + (noRes ? spend : cpr).toFixed(3) + '$' + (noRes ? ' (صرف بدون أي نتيجة؛ الإيقاف عند ضعف السقف)' : '') + (k !== 1 ? ' (محوّلة من الدينار)' : '');
    if (stop !== null && cpr >= stop) {
      out.push({ json: { kind: 'stop', ctx: p.ctx, platform: 'tiktok', op: 'tiktok.set_campaign_status', ad_account: p.ad_account, params: { campaign_ids: [rule.external_id], operation_status: 'DISABLE' },
        idem: 'guard-stop-' + rule.external_id + '-' + rule.act_epoch, cid: rule.external_id, name: rule.name, level: stop, cpr, stopCap: stop, stats } });
    } else {
      const hit = alerts.filter(a => cpr >= a).pop();
      if (hit && hit > last) out.push({ json: { kind: 'alert', ctx: p.ctx, cid: rule.external_id, state: 'watching', level: hit,
        text: '🔔 تكلفة النتيجة للحملة ' + nm + ' وصلت ' + cpr.toFixed(3) + '$ (تجاوزت ' + hit + '$)\n' + stats + (stop !== null ? '\nالإيقاف التلقائي عند ' + stop + '$.' : '') + '\nإيقاف يدوي: /pause_' + rule.external_id } });
    }
  }
});
return out;
""")
    sw = w.add("Action?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.kind === 'stop' ? 0 : 1 }}"})
    scall = call_broker(w, "Stop via Broker", mode="each")
    sres = code(w, "Stop result", r"""
const src = $('Evaluate').all().map(i => i.json).filter(x => x.kind === 'stop');
return $input.all().map((it, i) => {
  const r = it.json, s = src[i] || {};
  if (r.ok === true) return { json: { ctx: s.ctx, cid: s.cid, state: 'stopped', level: s.level,
    text: '⛔ أوقفت الحملة «' + s.name + '» تلقائياً: تكلفة النتيجة ' + s.cpr.toFixed(3) + '$ وصلت السقف ' + s.stopCap + '$.\n' + s.stats + '\nلتكملها (تفعيل جديد + مراقبة): /activate_' + s.cid } };
  return { json: { ctx: s.ctx, cid: s.cid, state: 'watching', level: 0,
    text: '🚨 تكلفة النتيجة للحملة «' + s.name + '» ' + s.cpr.toFixed(3) + '$ (السقف ' + s.stopCap + '$) وما كدرت أوقفها تلقائياً (' + ((r.error && r.error.class) || 'خطأ') + ').\nأوقفها حالاً: /pause_' + s.cid + ' أو من TikTok Ads Manager. بعيد المحاولة بعد 10 دقايق.' } };
});
""")
    rec = pg(w, "Record state", "SELECT $1::text AS ctx, $5::text AS text, api.rule_update($1, 'tiktok', $2, $3::numeric, $4) AS ok",
             "={{ [$json.ctx, $json.cid, $json.level, $json.state, $json.text] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    own = pg(w, "Owners", "SELECT $1::text AS ctx, $2::text AS text, chat_id::text AS chat_id FROM api.list_owner_chats($1)", "={{ [$json.ctx, $json.text] }}", CRJ)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    comp = code(w, "Compose messages", r"""
return $input.all().map(i => i.json).filter(r => r && r.chat_id && r.text)
  .map(r => ({ json: { ctx: r.ctx, platform: 'telegram', op: 'telegram.send_message', ad_account: r.chat_id, params: { text: String(r.text).slice(0, 3800) } } }));
""")
    send = call_broker(w, "Send via Broker", mode="each")
    done = code(w, "Summary", r"""
const r = $input.all().map(i => i.json);
return [{ json: { sent: r.filter(x => x.ok === true).length, failed: r.filter(x => x.ok !== true).length } }];
""")
    w.link(sch, ten); w.link(man, ten); w.chain(ten, watch, plan, rcall, ev, sw)
    w.link(sw, scall, 0); w.chain(scall, sres, rec); w.link(sw, rec, 1)
    w.chain(rec, own, comp, send, done)
    w.save("50_cost_guard.json", settings=b.ERR_SETTINGS)
