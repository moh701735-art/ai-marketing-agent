"""Workflow 10: استقبال رسائل تيليجرام لكل البوتات (عميل واحد = بوت واحد) وتنفيذ الأوامر. الهوية تأتي من القاعدة فقط (ctx)."""
R = CRED = None


def build(b):
    WF, code, pg, call_broker = b.WF, b.code, b.pg, b.call_broker
    CRT, CRJ = b.CRED_PG_RUNTIME, b.CRED_PG_JOBS
    w = WF("wfIngress0000001", "ingress: telegram commands (all tenants)")

    # ───── الاستقبال والهوية ─────
    # الرد على تيليجرام: 200 فقط بعد حسم الهوية والتسجيل (claim). عطل القاعدة => 500 فيعيد تيليجرام المحاولة بنفس update_id (claim يمنع التكرار).
    # طلب غير صالح/مستخدم غير مسجل => 200 صامت (لا إعادة محاولات). بعد claim ناجح: at-most-once (التحديث مسجّل ولو تعطل التنفيذ لاحقاً).
    wh = w.add("TG Webhook", "n8n-nodes-base.webhook", 2.2, {"httpMethod": "POST", "path": "tg-ingress", "responseMode": "responseNode", "options": {}},
               webhookId="0b8a6b7e-3f4d-4b2a-9d1c-5e7f8a9b0c1d")
    norm = code(w, "Normalize", r"""
const w = $input.first().json;
const upd = w.body || {};
const m = upd.message || upd.edited_message || null;
const secret = (w.headers || {})['x-telegram-bot-api-secret-token'] || '';
const botId = String((w.query || {}).bot || '');
if (!m || !m.from || !m.chat || typeof m.text !== 'string' || !botId || !secret || !/^[0-9]{1,15}$/.test(String(m.from.id))) return [{ json: { drop: true } }];
return [{ json: { botId, secret, tgUser: String(m.from.id), chatId: String(m.chat.id), updateId: Number(upd.update_id), text: m.text.trim().slice(0, 1000) } }];
""")
    ctxq = pg(w, "Resolve ctx", "SELECT ctx, sub_state FROM api.resolve_context($1, sha256(convert_to($2,'UTF8')), $3::bigint)",
              "={{ [$json.botId || '', $json.secret || '', $json.tgUser || '0'] }}", CRT, always=True)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    decide = code(w, "Decide", r"""
const d = $('Normalize').first().json; const r = $input.first().json;
if (r.error) return [{ json: { act: 'fail' } }];                      // القاعدة غير متاحة
if (d.drop || !r.ctx) return [{ json: { act: 'silent' } }];            // طلب غير صالح/غير مسجل: صمت
return [{ json: { ...d, secret: undefined, ctx: r.ctx, sub: r.sub_state, act: 'go' } }];
""")
    swd = w.add("Resolved?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.act === 'go' ? 1 : 0 }}"})
    early = code(w, "Early answer", "const d = $input.first().json; return [{ json: { http: d.act === 'fail' ? 500 : 200, proceed: false } }];")
    claim = pg(w, "Begin update", "SELECT api.begin_update($1, $2::bigint) AS st", "={{ [$json.ctx, $json.updateId] }}", CRT, always=True)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    after = code(w, "After begin", r"""
const d = $('Decide').first().json; const r = $input.first().json;
if (r.error) return [{ json: { http: 500, proceed: false } }];                          // لم يُسجَّل: تيليجرام يعيد الإرسال
if (r.st === 'inflight') return [{ json: { http: 500, proceed: false } }];              // نسخة أخرى تعالجه الآن: أعد لاحقاً
if (r.st === 'done') return [{ json: { http: 200, proceed: false } }];                  // اكتمل سابقاً
return [{ json: { ...d, http: 200, proceed: true } }];                                  // new | retry
""")
    swp = w.add("Process?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.proceed ? 1 : 0 }}"})
    resp = w.add("Respond early", "n8n-nodes-base.respondToWebhook", 1.4, {"respondWith": "noData", "options": {"responseCode": "={{ $json.http }}"}})
    route = code(w, "Route", r"""
const d = $input.first().json;
const t = d.text; let cmd = 'text', args = '';
if (t.startsWith('/')) { const m = t.match(/^\/([A-Za-z]+)(?:_(\d{5,24}))?(?:@\w+)?\s*([\s\S]*)$/); if (m) { cmd = m[1].toLowerCase(); args = ((m[2] || '') + ' ' + m[3]).trim(); } }
const map = { start: 0, help: 0, accounts: 2, campaigns: 3, report: 4, create: 5, activate: 8, pause: 9, check: 10, balance: 11, active: 12, restart: 8, duplicate: 13 };
const idx = (d.sub === 'expired' || d.sub === 'none') ? 6 : (cmd in map) ? map[cmd] : (cmd === 'text' ? 7 : 1);   // نص عادي (بلا /) => فهم بالذكاء الاصطناعي      // اشتراك منتهٍ: رسالة تجديد فقط
return [{ json: { ...d, cmd, args, idx } }];
""")
    sw = w.add("Command", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 14, "output": "={{ $json.idx }}"})
    w.chain(wh, norm, ctxq, decide, swd)
    w.link(swd, early, 0); w.link(swd, claim, 1); w.link(early, resp); w.chain(claim, after, swp); w.link(swp, resp, 0); w.link(swp, route, 1); w.link(route, sw)

    # ───── الرد (مشترك) ─────
    prep = code(w, "Prep send", r"""
const i = $input.first().json;
return [{ json: { ctx: i.ctx, platform: 'telegram', op: 'telegram.send_message', ad_account: String(i.chatId), params: { text: String(i.text).slice(0, 3800) } } }];
""")
    send = call_broker(w, "Send via Broker")
    done = code(w, "Sent", "return [{ json: { sent: $input.first().json.ok === true, error: $input.first().json.error } }];")
    fin_code = code(w, "Delivery outcome", r"""
const d = $('Decide').first().json; const r = $input.first().json;
const retry = ['central_unavailable', 'transient', 'circuit_open', 'rate_limited_local', 'internal', 'integrity_error', 'bad_response'];
const cls = (r.error && r.error.class) || '';
const ok = r.sent === true || !retry.includes(cls);            // رد وصل أو فشل دائم (مثل حظر البوت): أغلق. فشل مؤقت: حرّر الحجز ليعيد تيليجرام.
return [{ json: { ctx: d.ctx, updateId: d.updateId, ok } }];
""")
    fin_pg = pg(w, "Finish update", "SELECT api.finish_update($1, $2::bigint, $3::boolean)", "={{ [$json.ctx, $json.updateId, $json.ok] }}", CRT, always=True)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    fin_http = code(w, "Final status", r"""
const o = $('Delivery outcome').first().json; const r = $input.first().json;
return [{ json: { http: (r.error || !o.ok) ? 500 : 200 } }];
""")
    resp_final = w.add("Respond final", "n8n-nodes-base.respondToWebhook", 1.4, {"respondWith": "noData", "options": {"responseCode": "={{ $json.http }}"}})
    w.chain(prep, send, done, fin_code, fin_pg, fin_http, resp_final)

    def reply(name, js):                                           # عقدة نص ثابت/محسوب ثم الإرسال
        n = code(w, name, js); w.link(n, prep); return n

    # 0: start/help   1: مجهول
    help_ = reply("Reply help", r"""
const d = $input.first().json;
return [{ json: { ctx: d.ctx, chatId: d.chatId, text: 'أهلاً بيك 👋\nأني بوت إدارة إعلاناتك.\n\nالأوامر:\n/accounts — حساباتك الإعلانية\n/campaigns — آخر حملاتك\n/report — تقرير اليوم\n/create meta|tiktok <الحساب> <الميزانية> <اسم الحملة> — حملة جديدة (تنشأ متوقفة)\n/activate <رقم الحملة> — تفعيل حملة مع مراقبة التكلفة\n/pause <رقم الحملة> — إيقاف حملة\n/restart <رقم الحملة> — إعادة تشغيل حملة (وتسجيل مراقبة التكلفة لها)\n/duplicate <رقم الحملة> — نسخ حملة واتساب بنفس إعداداتها وفيديوهاتها\n/check_<رقم الحملة> — فحص الحملة بالأرقام (أُنشئت؟ مفعّلة؟ توزيع؟ رسائل؟)\n/balance — رصيد حساباتك (أو اكتب: شكد رصيد حساب بنين)\n/active — الحملات اللي صرفت اليوم وأرقامها\n\nأو اكتب طلبك بالكلام العادي (مع كود Spark لإنشاء حملة كاملة).' } }];
""")
    unk = reply("Reply unknown", r"""
const d = $input.first().json;
return [{ json: { ctx: d.ctx, chatId: d.chatId, text: 'ما فهمت الأمر. اكتب /help لتشوف الأوامر.' } }];
""")
    expd = reply("Reply subscription expired", r"""
const d = $input.first().json;
return [{ json: { ctx: d.ctx, chatId: d.chatId, text: 'اشتراكك بالبوت منتهي. تواصل مع الدعم لتجديد الاشتراك وإعادة التفعيل.' } }];
""")
    w.link(sw, help_, 0); w.link(sw, unk, 1); w.link(sw, expd, 6)

    # 2: accounts
    acc = pg(w, "List accounts", "SELECT platform, external_id, name, currency, status, enabled FROM api.list_ad_accounts($1)", "={{ [$('Route').first().json.ctx] }}", CRT, always=True)
    accf = reply("Format accounts", r"""
const d = $('Route').first().json;
const rows = $input.all().map(i => i.json).filter(r => r && r.external_id);
const text = rows.length ? '📋 حساباتك الإعلانية (' + rows.length + '):\n' + rows.map(r => '• [' + (r.platform === 'meta' ? 'Meta' : 'TikTok') + '] ' + r.external_id + (r.name ? ' — ' + r.name : '') + (r.enabled ? ' ✅' : ' ⏸️')).join('\n') : 'ما عندك حسابات إعلانية مربوطة بعد.';
return [{ json: { ctx: d.ctx, chatId: d.chatId, text } }];
""")
    w.link(sw, acc, 2); w.link(acc, accf)

    # 3: campaigns
    cam = pg(w, "List campaigns", "SELECT platform::text AS platform, name, status, daily_budget_minor, external_id FROM api.list_campaigns($1, NULL::text) LIMIT 20",
             "={{ [$('Route').first().json.ctx] }}", CRT, always=True)
    camf = reply("Format campaigns", r"""
const d = $('Route').first().json;
const rows = $input.all().map(i => i.json).filter(r => r && r.name);
const text = rows.length ? '🎯 حملاتك (' + rows.length + '):\n' + rows.map(r => '• ' + r.name + ' — ' + r.status + ' — ' + r.platform + (r.daily_budget_minor ? ' — ' + r.daily_budget_minor + '$' : '')).join('\n') : 'ما عندك حملات مسجلة بعد.';
return [{ json: { ctx: d.ctx, chatId: d.chatId, text } }];
""")
    w.link(sw, cam, 3); w.link(cam, camf)

    # 7: نص عادي => Broker يفهمه (Gemini) فيرجع نيّة منظّمة. التنفيذ يمر بنفس الأوامر الآمنة (لا ينفَّذ شيء من مخرجات النموذج مباشرة)
    aiprep = code(w, "AI: prep", r"""
const d = $input.first().json;
const RE = /#[A-Za-z0-9+\/=_\-]{16,250}/g;                      // كود تفويض Spark يبدأ بـ #. يُستخرج هنا ولا يذهب لمزوّد الذكاء الاصطناعي.
const t = String(d.text);
const codes = [...new Set(t.match(RE) || [])].slice(0, 5);
const masked = t.replace(RE, ' [SPARK_CODE] ').slice(0, 800);
return [{ json: { ...d, codes, platform: 'llm', op: 'llm.parse_command', ad_account: null, params: { text: masked } } }];
""")
    aicall = call_broker(w, "AI: call Broker")
    aidec = code(w, "AI: decide", r"""
const d = $('Route').first().json; const r = $input.first().json;
const base = { ctx: d.ctx, chatId: d.chatId };
if (!r.ok || !r.data || !r.data.intent) return [{ json: { ...base, aiIdx: 6, masked: String(($('AI: prep').first().json.params || {}).text || '') } }];
const it = r.data.intent; const map = { report: 0, accounts: 1, campaigns: 2, create_campaign: 3, help: 4, unknown: 5, campaign_status: 7, balance: 8, active_campaigns: 9 };
return [{ json: { ...base, aiIdx: (it.intent in map) ? map[it.intent] : 5, it, codes: $('AI: prep').first().json.codes || [], masked: String(($('AI: prep').first().json.params || {}).text || '') } }];
""")
    aisw = w.add("AI: route", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 10, "output": "={{ $json.aiIdx }}"})
    aiacc = pg(w, "AI: accounts", "SELECT platform, external_id, name, currency, status, enabled FROM api.list_ad_accounts($1)", "={{ [$('Route').first().json.ctx] }}", CRT, always=True)
    aiplan = code(w, "AI: plan", r"""
const d = $('Route').first().json; const a = $('AI: decide').first().json;
const it = a.it || {}, codes = a.codes || [];
const rows = $input.all().map(i => i.json).filter(r => r && r.external_id);
const tt = rows.filter(r => r.platform === 'tiktok' && r.enabled);
const base = { ...d, valid: false };
const say = (text) => [{ json: { ...base, text } }];
const nm = s => String(s || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
const P = { tiktok: 'TikTok', meta: 'Meta' };
if (!codes.length) {                                                      // بلا كود Spark: نلخّص فقط ونعطي أمر /create الجاهز
  const lines = ['فهمت إنك تريد حملة جديدة:', '• المنصة: ' + (P[it.platform] || 'ما حددت'), '• الحساب: ' + (it.account || 'ما حددت (اكتب /accounts)'),
    '• الميزانية: ' + (it.budget ? it.budget + '$' : 'ما حددت'), '• الاسم: ' + (it.name || 'ما حددت')];
  if (it.objective) lines.push('• الهدف: ' + it.objective);
  let tail = '\nلإنشاء حملة تيك توك كاملة (مبيعات/عملاء محتملين) أرسل الطلب مع كود إعلان Spark (يبدأ بـ #) واسم صفحة الهبوط.';
  const msgIntent = /واتس|whats|رسائل|رساله|عميل محتمل|ليد|lead/i.test(String(d.text || '')) || it.objective === 'LEAD_GENERATION';
  if (msgIntent) tail += '\nملاحظة: حملة الرسائل/العملاء المحتملين تحتاج كود Spark (وللواتساب رقم الواتساب). أمر /create ينشئ حملة زيارات فارغة فقط (مو رسائل) فما أعرضه هنا.';
  else if (it.platform && it.account && it.budget && it.name) tail += '\nأو حملة بسيطة (زيارات فقط، متوقفة، بدون مجموعة وإعلان): /create ' + it.platform + ' ' + it.account + ' ' + it.budget + ' ' + it.name;
  return say(lines.join('\n') + tail);
}
const ntx = String(d.text || '').replace(/#[A-Za-z0-9+\/=_\-]{16,250}/g, ' ').replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/[۰-۹]/g, c => '۰۱۲۳۴۵۶۷۸۹'.indexOf(c));
const wam = ntx.match(/(?<!\d)(?:\+?964|00964|0)?(7[0-9]{9})(?!\d)/);                // رقم واتساب عراقي (07XXXXXXXXX)
const mode = (/واتس|whats/i.test(ntx) || wam) ? 'whatsapp' : { CONVERSIONS: 'sales', LEAD_GENERATION: 'leads' }[it.objective];
if (mode === 'whatsapp' && !wam) return say('أي رقم واتساب تريد الزبائن يراسلوه؟ اكتبه (مثال 07741536361) وأعد الرسالة كاملة.');
if (!mode) return say('حددلي هدف الحملة: مبيعات/تحويلات أو عملاء محتملين. (مع Spark أدعم هذين حالياً.)');
let iqdAmount = 0;                                                        // ميزانية مكتوبة بالدينار (70 الف / 70000 دينار) بدون كلمة دولار
{
  const mI = ntx.match(/(\d+(?:[.,]\d+)?)\s*(?:الف|ألف|الاف|آلاف)|(\d[\d,]{3,})\s*(?:دينار|د\.?ع|iqd)/i);
  if (mI && !/دولار|\$|usd/i.test(ntx)) { iqdAmount = mI[1] ? Math.round(Number(mI[1].replace(',', '.')) * 1000) : Number(mI[2].replace(/,/g, '')); if (iqdAmount > 0) it.budget = Math.round(iqdAmount / 1310 * 100) / 100; }
}
if (!it.budget) {                                                         // قراءة ثابتة للميزانية من النص (أرقام عربية/فارسية، كلمات: ميزانية/مزانية/بجت) إذا فاتها النموذج
  const nt = String(d.text || '').replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/[۰-۹]/g, c => '۰۱۲۳۴۵۶۷۸۹'.indexOf(c));
  const bm = nt.match(/(?:ميزاني[هة]|مزاني[هة]|بجت|budget)\D{0,14}(\d+(?:\.\d+)?)|(\d+(?:\.\d+)?)\s*(?:دولار|\$|usd)/i);
  if (bm) it.budget = Number(bm[1] || bm[2]);
}
if (!(it.budget > 0)) return say('حددلي الميزانية بالدولار، واكتب الرسالة كاملة من جديد مع الميزانية (مثلاً: ميزانية 20 دولار). ما أتذكر الرسالة السابقة.');
const h = nm(it.account);
let acct = h ? (tt.find(r => nm(r.external_id) === h) || tt.find(r => nm(r.name) && (nm(r.name).includes(h) || h.includes(nm(r.name))))) : null;
if (!acct) {                                                              // اسم الحساب بنص الرسالة نفسه (مثل: بحساب بنين وداليا): مطابقة بعد إزالة المسافات والتشكيل، الأطول أولاً
  const msgN = nm(ntx), nn = r => nm(r.name);
  const hits = tt.filter(r => nn(r).length >= 3 && msgN.includes(nn(r))).sort((a, b) => nn(b).length - nn(a).length);
  if (hits.length) acct = hits[0];
  if (!acct) { const ids = ntx.match(/\d{15,25}/g) || []; acct = tt.find(r => ids.includes(String(r.external_id))) || null; }
  if (!acct) {                                                            // كلمة واحدة من الاسم (مثل: بنين) إذا تخص حساباً واحداً فقط
    const STOP = new Set(['حساب', 'الحساب', 'بحساب', 'حملة', 'الحملة', 'الحمله', 'ارفع', 'اريد', 'ميزانيه', 'ميزانية', 'واتساب', 'دولار', 'يوم', 'على', 'الى', 'هذا', 'هاي', 'باعلان', 'واحد', 'اسمها', 'اسمه', 'الهبوط', 'صفحه', 'صفحة']);
    const toks = [...new Set(ntx.split(/[^\p{L}\p{N}]+/u).map(nm).filter(t => t.length >= 3 && !STOP.has(t)))];
    const words = r => String(r.name || '').split(/[^\p{L}\p{N}]+/u).map(nm).filter(w => w.length >= 3);
    const cand = tt.filter(r => toks.some(t => words(r).includes(t) || (t.length >= 4 && nn(r).includes(t))));
    if (cand.length === 1) acct = cand[0];
  }
}
if (!acct && tt.length === 1) acct = tt[0];
if (!acct) return say('على أي حساب تيك توك أنزّل الإعلان؟\n' + (tt.length ? tt.map(r => '• ' + (r.name || '') + ' — ' + r.external_id).join('\n') : 'ما عندك حسابات تيك توك مربوطة.') + '\n\nأعد إرسال نفس الرسالة مع اسم الحساب أو رقمه.');
const cur = String(acct.currency || '').toUpperCase(), FX = 1310;                       // الدينار: نحوّل ميزانية الدولار (1$ = 1310 د.ع مثل النظام القديم)
if (cur !== 'USD' && cur !== 'IQD') return say('هذا الحساب بعملة ' + (cur || 'غير معروفة') + '. أدعم حسابات الدولار والدينار فقط.');
const budgetUsd = it.budget, budgetApi = cur === 'IQD' ? (iqdAmount || Math.ceil(it.budget * FX)) : it.budget;
const days = Math.min(90, Math.max(1, Math.round(Number(it.days) || 1)));
const wantInt = /اهتمام|interest/i.test(ntx) && !/(?:بدون|بلا|لا\s*تخل[يى]|ما\s*اريد|مو\s*تخل[يى]?)\s*(?:ال)?اهتمام/i.test(ntx);      // اهتمامات فقط إذا طلبها المستخدم صراحة
let product = it.product || '';
if (!product) { const pm = ntx.match(/(?:المنتج|منتج)\s*[:：]?\s*([^\n,،.#]{2,60})/); if (pm) product = pm[1].trim(); }
let costCap = null;                                                       // سقف التكلفة (cost cap) اختياري: "بسقف 20 سنت" / "سقف 0.2 دولار" / "سقف 300 دينار" => BID_TYPE_CUSTOM بسعر مستهدف. بدونه: أقل تكلفة كما كان
{
  const cm = ntx.match(/(?:سقف(?:\s*(?:ال)?(?:تكلف[ةه]|رساله|رسالة))?|cost\s*cap)\s*[:=]?\s*(\d+(?:[.,]\d+)?)\s*(سنتات|سنت|cents|cent|دولار|\$|usd|دينار|د\.?ع|الف|ألف)?/i);
  if (cm) {
    const v = Number(cm[1].replace(',', '.')), u = String(cm[2] || '').toLowerCase();
    const usd = /سنت|cent/.test(u) ? v / 100 : /الف|ألف/.test(u) ? v * 1000 / FX : /دينار|د\.?ع/.test(u) ? v / FX : /دولار|\$|usd/.test(u) ? v : (v >= 1 ? v / 100 : v);       // بلا وحدة: 20 => 20 سنت، 0.2 => 0.2$
    if (usd > 0 && usd <= 50) costCap = cur === 'IQD' ? Math.round(usd * FX) : Math.round(usd * 1000) / 1000;
  }
}
const launch = { campaign_name: it.name || ('حملة ' + new Date(Date.now() + 3 * 3600000).toISOString().slice(5, 16).replace('T', ' ')), objective: mode, budget: budgetApi,
  budget_mode: it.budget_kind === 'daily' ? 'daily' : 'total', days, spark_codes: codes, page_name: mode === 'whatsapp' ? '' : (it.landing_page || ''), ...(mode === 'whatsapp' ? { whatsapp_number: wam[1], smart: /(?:سمارت|smart)/i.test(ntx) && !/(?:بدون|لا|مو|ما)\s*(?:حمل[ةه]\s*)?(?:سمارت|smart)/i.test(ntx) } : {}), product, ...(costCap ? { cost_cap: costCap } : {}), use_interests: wantInt, interest_count: it.interest_count || 450, activate_now: !/(?:لا|ما|مو)\s*(?:تفعل|تشغل)|(?:خليها|خلها|اتركها|ابقيها|اتركه)\s*(?:ال)?(?:متوقف|موقوف|ايقاف)|متوقف[هة]?\s*(?:بس|فقط)/.test(ntx) };      // تفعيل مباشر دائماً (طلب المالك) إلا إذا قال: لا تفعلها / خليها متوقفة
return [{ json: { ...d, valid: true, platform: 'tiktok', account: acct.external_id, budget: launch.budget, name: launch.campaign_name,
  key: 'tgupd-' + d.chatId + '-' + d.updateId + '-launch', payload: JSON.stringify(launch), launch, cur, budget_usd: budgetUsd } }];
""")
    aierr = reply("AI: unavailable", r"const d = $input.first().json; return [{ json: { ctx: d.ctx, chatId: d.chatId, text: 'ما كدرت أفهم رسالتك هسه 🙏 بس أكدر أساعدك بهالأشياء:\n• اسأل عن حملة باسمها (مثلاً: حملة سديم نشط)\n• /report تقرير اليوم\n• /campaigns حملاتك\n• /help كل الأوامر' } }];")
    w.link(sw, aiprep, 7); w.chain(aiprep, aicall, aidec, aisw)

    # دردشة حرة: أي رسالة ما فُهمت كأمر تنرد عليها (Gemini)، وإذا غير واضحة يسأل ويعرض الخيارات. لا بيانات حية ولا تنفيذ.
    chatprep = code(w, "Chat: prep", r"""
const d = $('Route').first().json; const a = $('AI: decide').first().json;
const t = String(a.masked || '').replace(/\s+/g, ' ').trim().slice(0, 800);
return [{ json: { ctx: d.ctx, chatId: d.chatId, platform: 'llm', op: 'llm.chat', ad_account: null, params: { text: t || '.' } } }];
""")
    chatcall = call_broker(w, "Chat: call Broker")
    chatrep = reply("Chat: reply", r"""
const d = $('Route').first().json; const r = $input.first().json;
const fb = 'ما فهمت قصدك بالضبط 🤔 تريد:\n• أشوف لك حملة معينة؟ اكتب اسمها (مثلاً: حملة سديم نشط)\n• تقرير اليوم؟ /report\n• حملاتك؟ /campaigns\n• ترفع حملة جديدة؟ اكتب الهدف والحساب والميزانية وأكواد Spark\n• كل الأوامر: /help';
const text = (r.ok === true && r.data && typeof r.data.reply === 'string' && r.data.reply.trim()) ? r.data.reply.trim() : fb;
return [{ json: { ctx: d.ctx, chatId: d.chatId, text: text.slice(0, 3500) } }];
""")
    w.chain(chatprep, chatcall, chatrep)

    # سؤال عن حملة بالاسم ("شلون حملة سديم نشط"): بحث بتقارير آخر 7 أيام بحسابات تيك توك ثم فحص الحملة بالأرقام (نفس مسار /check)
    stacc = pg(w, "Stat: accounts", "SELECT external_id FROM api.list_ad_accounts($1) WHERE platform = 'tiktok' AND enabled", "={{ [$('Route').first().json.ctx] }}", CRT, always=True)
    stprep = code(w, "Stat: prep", r"""
const d = $('Route').first().json; const a = $('AI: decide').first().json;
const rows = $input.all().map(i => i.json).filter(r => r && r.external_id);
const name = String((a.it || {}).name || '').replace(/\s+/g, ' ').trim().slice(0, 80);
const say = t => [{ json: { ctx: d.ctx, chatId: d.chatId, halt: true, text: t } }];
if (!name) return say('أي حملة تقصد؟ اكتب اسمها، مثلاً: حملة سديم نشط، وأجيبلك أرقامها.');
if (!rows.length) return say('ما عندك حسابات تيك توك مفعّلة أدور بيها.');
return [{ json: { ctx: d.ctx, chatId: d.chatId, halt: false, platform: 'tiktok', op: 'tiktok.find_campaign', ad_account: null, params: { name, accounts: rows.map(r => String(r.external_id)).slice(0, 40) }, askedName: name } }];
""")
    stsw = w.add("Stat: search?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.halt ? 0 : 1 }}"})
    stcall = call_broker(w, "Stat: call Broker")
    stchoose = code(w, "Stat: choose", r"""
const p = $('Stat: prep').first().json; const r = $input.first().json; const base = { ctx: p.ctx, chatId: p.chatId };
const say = t => [{ json: { ...base, halt: true, text: t } }];
if (r.ok !== true) return say('ما كدرت أدور على الحملة هسه (تيك توك ما رد). جرّب بعد شوي أو استعمل /campaigns.');
const d = r.data || {}, m = d.matches || [];
if (!m.length) return say('ما لقيت حملة باسم «' + p.askedName + '» صرفت آخر 7 أيام بحساباتك' + (d.accounts_failed ? ' (' + d.accounts_failed + ' حساب ما كدرت أقراه)' : '') + '.\nتأكد من الاسم، أو اكتب /campaigns.');
const top = m[0], second = m[1];
if (top.exact && !(second && second.exact)) {
  return [{ json: { ...base, halt: false, mode: 'check', cid: top.campaign_id, name: top.name, cap: 0, alerts: [], platform: 'tiktok', ad_account: top.ad_account, op: 'tiktok.campaign_check', params: { campaign_id: top.campaign_id }, idem: 'tgupd-' + p.chatId + '-stat-' + top.campaign_id } }];
}
return say('🔎 لقيت أكثر من حملة تشبه «' + p.askedName + '»، اختار وحدة:\n' + m.map(x => '• ' + x.name + ' — /check_' + x.campaign_id).join('\n'));
""")

    # 4: report
    racc = pg(w, "Report: accounts", "SELECT platform, external_id, name FROM api.list_ad_accounts($1) WHERE enabled", "={{ [$('Route').first().json.ctx] }}", CRT, always=True)
    plan = code(w, "Report: plan", r"""
const d = $('Route').first().json;
const rows = $input.all().map(i => i.json).filter(r => r && r.external_id);
return [{ json: { ctx: d.ctx, chatId: d.chatId, n: rows.length, rows } }];
""")
    sw2 = w.add("Report: any accounts?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.n > 0 ? 1 : 0 }}"})
    rnone = reply("Report: none", r"const d = $input.first().json; return [{ json: { ctx: d.ctx, chatId: d.chatId, text: 'ما عندك حسابات إعلانية لأسوي لها تقرير.' } }];")
    rexp = code(w, "Report: explode", r"""
const d = $input.first().json;
const today = new Date().toISOString().slice(0, 10);
return d.rows.map(r => ({ json: r.platform === 'meta'
  ? { ctx: d.ctx, platform: 'meta', op: 'meta.read_insights', ad_account: r.external_id, params: { date_preset: 'today', fields: 'spend,impressions,clicks', level: 'account' }, label: r.external_id }
  : { ctx: d.ctx, platform: 'tiktok', op: 'tiktok.read_report', ad_account: r.external_id, params: { report_type: 'BASIC', data_level: 'AUCTION_ADVERTISER', dimensions: ['advertiser_id'], metrics: ['spend', 'impressions', 'clicks'], start_date: today, end_date: today }, label: r.external_id } }));
""")
    rcall = call_broker(w, "Report: call Broker", mode="each")
    rfmt = reply("Report: format", r"""
const d = $('Report: plan').first().json;
const plans = $('Report: explode').all().map(i => i.json);
const res = $input.all().map(i => i.json);
const lines = res.map((r, i) => {
  const p = plans[i] || {}; const tag = (p.platform === 'meta' ? 'Meta' : 'TikTok') + ' ' + p.label;
  if (!r.ok) return '⚠️ ' + tag + ': ما كدرت أجيب البيانات (' + ((r.error && r.error.class) || 'خطأ') + ')';
  const m = p.platform === 'meta' ? ((r.data && r.data.data && r.data.data[0]) || {}) : (((r.data && r.data.data && r.data.data.list && r.data.data.list[0]) || {}).metrics || {});
  return '• ' + tag + ': صرف ' + (m.spend || 0) + '$ | ظهور ' + (m.impressions || 0) + ' | نقرات ' + (m.clicks || 0);
});
return [{ json: { ctx: d.ctx, chatId: d.chatId, text: '📊 تقرير اليوم\n' + lines.join('\n') } }];
""")
    w.link(sw, racc, 4); w.chain(racc, plan, sw2); w.link(sw2, rnone, 0); w.link(sw2, rexp, 1); w.chain(rexp, rcall, rfmt)

    # 5: create  /create meta|tiktok <account> <budget> <name...>
    parse = code(w, "Create: parse", r"""
const d = $('Route').first().json;
const m = d.args.match(/^(meta|tiktok)\s+([A-Za-z0-9_]{1,40})\s+([0-9]+(?:\.[0-9]+)?)\s+([\s\S]{1,150})$/i);
const usage = 'الصيغة: /create meta|tiktok <رقم الحساب> <الميزانية بالدولار> <اسم الحملة>\nمثال: /create meta act_123 20 حملة العيد';
if (!m) return [{ json: { ...d, valid: false, text: usage } }];
const platform = m[1].toLowerCase(), account = m[2], budget = Number(m[3]), name = m[4].trim();
if (!(budget > 0 && budget <= 100000)) return [{ json: { ...d, valid: false, text: 'الميزانية لازم تكون رقم أكبر من صفر.' } }];
const key = 'tgupd-' + d.chatId + '-' + d.updateId + '-create';
return [{ json: { ...d, valid: true, platform, account, budget, name, key, payload: [platform, account, budget, name].join('|') } }];
""")
    sw3 = w.add("Create: valid?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.valid ? 1 : 0 }}"})
    cbad = reply("Create: usage", "const d = $input.first().json; return [{ json: { ctx: d.ctx, chatId: d.chatId, text: d.text } }];")
    begin = pg(w, "Create: begin request", "SELECT state, result_ref, reason FROM api.begin_campaign_checked($1, $2, sha256(convert_to($3,'UTF8')), $4, $5, $6::numeric)",
               "={{ [$json.ctx, $json.key, $json.payload, $json.platform, $json.account, $json.budget] }}", CRT)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    gate = code(w, "Create: gate", r"""
let d; try { d = $('Create: parse').first().json; } catch (e) { try { d = $('AI: plan').first().json; } catch (e2) { d = $('Dup: prep').first().json; } }
const r = $input.first().json;
if (r.error || r.reason) {
  const e = r.reason || '';
  const text = e === 'subscription_expired' ? 'اشتراكك بالبوت منتهي. تواصل مع الدعم للتجديد.' : e === 'subscription_grace_readonly' ? 'اشتراكك منتهي وبفترة سماح: القراءة فقط. جدّد لتتمكن من إنشاء حملات.' : e === 'daily_create_limit' ? 'وصلت الحد اليومي لإنشاء الحملات حسب خطتك.' : e === 'forbidden' ? 'ما عندك صلاحية إنشاء حملات (تحتاج دور مدير).' : e === 'budget_over_user_limit' ? 'الميزانية أعلى من الحد المسموح لك.' : e === 'ad_account_not_owned_or_disabled' ? 'هذا الحساب الإعلاني غير مرتبط بحسابك أو معطّل.' : e === 'tenant_not_ready' ? 'حسابك غير جاهز حالياً. تواصل مع الدعم.' : 'ما كدرت أبدأ الطلب. جرّب مرة ثانية.';
  return [{ json: { ...d, go: 1, text } }];
}
if (r.state === 'new') return [{ json: { ...d, go: 0 } }];
const t = r.state === 'in_progress' ? 'هذا الطلب قيد التنفيذ، انتظر شوي.' : r.state === 'needs_manual_check' ? 'نتيجة هذا الطلب غير مؤكدة. افحص المنصة قبل ما تعيد المحاولة.' : r.state === 'conflict' ? 'نفس الطلب انرسل سابقاً بتفاصيل مختلفة.' : 'هذا الطلب تنفّذ سابقاً' + (r.result_ref ? ' (' + r.result_ref + ')' : '') + '.';
return [{ json: { ...d, go: 1, text: t } }];
""")
    sw4 = w.add("Create: new?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.go }}"})
    cnotnew = reply("Create: not new", "const d = $input.first().json; return [{ json: { ctx: d.ctx, chatId: d.chatId, text: d.text } }];")
    cprep = code(w, "Create: prep call", r"""
const d = $input.first().json;
const meta = d.platform === 'meta';
if (d.dup) return [{ json: { ...d, platform: 'tiktok', op: 'tiktok.duplicate_campaign', ad_account: d.account, params: d.dup, idem: d.key } }];
if (d.launch) return [{ json: { ...d, platform: 'tiktok', op: 'tiktok.launch_spark', ad_account: d.account, params: d.launch, idem: d.key } }];
return [{ json: { ...d, ctx: d.ctx, platform: d.platform, op: meta ? 'meta.create_campaign' : 'tiktok.create_campaign', ad_account: d.account,
  params: meta ? { name: d.name, objective: 'OUTCOME_TRAFFIC' } : { campaign_name: d.name, objective_type: 'TRAFFIC' }, idem: d.key } }];
""")
    ccall = call_broker(w, "Create: call Broker")
    cres = code(w, "Create: result", r"""
const d = $('Create: prep call').first().json; const r = $input.first().json;
if (d.dup) {
  const ok = r.ok === true, dd = r.data || {}, e = r.error || {}, cls = e.class || '', m = String(e.message || '').slice(0, 160);
  const ref = String(dd.campaign_id || '');
  const why = { smart_plus_not_supported: 'هذي حملة Smart+؛ النسخ بالبوت للحملات اليدوية فقط (استعمل Duplicate من واجهة تيك توك).', not_whatsapp: 'النسخ حالياً لحملات رسائل الواتساب فقط.', source_not_found: 'ما لقيت الحملة المصدر بتيك توك (ممكن محذوفة).',
    multiple_adgroups: 'الحملة فيها أكثر من مجموعة إعلانية؛ ما أنسخها حتى ما ينقص منها شي.', ad_identity_not_auth_code: 'إعلانات هذي الحملة مو Spark بكود تفويض، ما أكدر أعيد استعمال هويتها.', no_ads: 'الحملة ما فيها إعلانات.',
    source_schedule_or_budget_unreadable: 'ما كدرت أقرأ ميزانية أو جدول الحملة المصدر.' };
  let text;
  if (ok) {
    const en = dd.stages && dd.stages.enabled;
    text = (dd.activated ? (en === false ? '⚠️ نسخت الحملة وطلبت تفعيلها لكن تيك توك ما أكّد التفعيل (' + ((dd.verify && dd.verify.adgroup && dd.verify.adgroup.secondary_status) || 'حالة غير معروفة') + ') — ما أضمن أنها تصرف.' : '✅ نسخت الحملة وفعّلتها (مفعّلة حسب قراءة تيك توك).')
      : '⚠️ نسخت الحملة بس ما كدرت أفعّلها (' + (dd.activation_error || 'سبب غير معروف') + '). فعّلها بـ /activate ' + ref + '.')
      + '\n• المصدر: «' + (dd.source_name || '') + '» (' + dd.source_campaign_id + ')\n• النسخة: «' + (dd.name || d.name) + '»\n• الميزانية: ' + dd.budget + ' (' + (dd.budget_mode === 'daily' ? 'يومية' : 'إجمالية') + ') لمدة ' + dd.days + ' يوم'
      + (dd.cost_cap ? '\n• سقف التكلفة: ' + dd.cost_cap : '') + '\n• الفيديوهات: ' + dd.videos_ok + '\n• الحملة: ' + ref + ' — المجموعة: ' + dd.adgroup_id + ' — الإعلانات: ' + (dd.ad_ids || []).join(', ')
      + (dd.activated && en !== false ? '\n\n👁 المراقبة شغالة (كل 10 دقايق): تنبيه عند 0.15 / 0.20 / 0.30$ لتكلفة النتيجة + إيقاف تلقائي عند 0.30$.\nلإيقافها: /pause ' + ref : '')
      + '\n\n📍 المراحل: ✅ أُنشئت | ' + (en ? '✅' : '⚠️') + ' مفعّلة (حسب تيك توك) | ⏳ توزيع | ⏳ نتائج\nافحص الأرقام بعد ساعة: /check_' + ref;
  } else {
    const detail = m === 'unsupported_source' ? (why[dd.why] || 'هذي الحملة غير مدعومة للنسخ.') : 'فشلت خطوة (' + (dd.stage || '؟') + '): ' + m + ' [' + cls + ']';
    text = '❌ ما نسخت الحملة. ' + detail + (ref ? '\n⚠️ انعملت حملة ناقصة (متوقفة) رقمها ' + ref + ' بالحساب ' + d.account + '. احذفها من TikTok Ads Manager أو قولي أكمّلها.' : '');
  }
  const status = ok ? 'succeeded' : (ref || cls === 'outcome_unknown' ? 'needs_manual_check' : 'failed');
  return [{ json: { ctx: d.ctx, chatId: d.chatId, key: d.key, ok, status, ref: ok ? ref : (ref || cls), ext: ref, platform: 'tiktok', account: d.account, name: dd.name || d.name, budget: d.budget, objective: 'LEAD_GENERATION', activated: !!dd.activated, text } }];
}
if (d.launch) {
  const ok = r.ok === true, dd = r.data || {}, e = r.error || {}, cls = e.class || '';
  const L = d.launch, ref = String(dd.campaign_id || '');
  const objName = L.objective === 'sales' ? 'مبيعات (تحويلات)' : L.objective === 'whatsapp' ? 'رسائل واتساب (محادثات)' : 'عملاء محتملين';
  let text;
  if (ok) text = (dd.activated ? (dd.stages && dd.stages.enabled === false ? '⚠️ أُنشئت الحملة "' + L.campaign_name + '" وطلبت تفعيلها لكن تيك توك ما أكّد التفعيل (حالتها: ' + ((dd.verify && dd.verify.adgroup && dd.verify.adgroup.secondary_status) || 'غير معروفة') + ') — ما أضمن أنها تصرف. (' : '✅ جهّزت وفعّلت الحملة "' + L.campaign_name + '" على TikTok — مفعّلة حسب قراءة تيك توك (') + (dd.activation_reason === 'declared' ? 'تفعيل مباشر حسب إعدادك' : 'الكود سبق ترويجه بهذا الحساب') + ').' : '✅ جهّزت الحملة "' + L.campaign_name + '" على TikTok — كلها متوقفة (DISABLE) ولا تصرف.') + '\n• الحساب: ' + d.account + '\n• الهدف: ' + objName + '\n• الصفحة: ' + (dd.page_title || '') +
    '\n• الميزانية: ' + (d.cur === 'IQD' ? Number(L.budget).toLocaleString('en-US') + ' د.ع (≈ ' + d.budget_usd + '$)' : L.budget + '$') + ' (' + (L.budget_mode === 'daily' ? 'يومية' : 'إجمالية') + ') لمدة ' + L.days + ' يوم' + (L.cost_cap ? '\n• المزايدة: سقف تكلفة (cost cap) ' + L.cost_cap + (d.cur === 'IQD' ? ' د.ع' : '$') + ' للنتيجة' : '\n• المزايدة: أقل تكلفة (بدون سقف)') + '\n• الفيديوهات: ' + dd.videos_ok + (dd.videos_skipped ? ' (تخطيت ' + dd.videos_skipped + ')' : '') +
    (dd.product_seen ? '\n• المنتج كما فهمته من الفيديو: ' + dd.product_seen : '') + '\n• الاستهداف: ' + (!L.use_interests ? 'بدون اهتمامات (استهداف عام: العراق + العمر). لإضافة اهتمامات اكتب: خلي اهتمامات واسم المنتج.' : dd.interests_n > 0 ? dd.interests_n + ' اهتمام مرتبط بالمنتج (' + (dd.interests || []).slice(0, 5).join('، ') + '...)' : 'عام (نية شراء + اهتمامات ذكية) — ' + ({ no_product: 'ما حددت المنتج. أرسل مثلاً: المنتج بكج تبييض أسنان', no_recommendations: 'تيك توك ما رجّع اهتمامات لهذا المنتج', no_seeds: 'ما كدرت أحلل المنتج هسه', too_few_valid: 'اهتمامات صالحة قليلة', llm_disabled: 'تحليل المنتج غير مفعل' }[dd.interests_note] || 'تعذر تحديد اهتمامات')) + (dd.interests_debug ? '\n• تشخيص الاهتمامات: كلمات ' + (dd.interests_debug.seeds || 0) + ' | طلبات فاشلة ' + (dd.interests_debug.fail || 0) + ' | اقتراحات تيك توك ' + (dd.interests_debug.raw || 0) + ' | مرشحة ' + (dd.interests_debug.cand || 0) + ' | مرفوضة ' + (dd.interests_debug.bad || 0) + (dd.interests_debug.err ? ' | خطأ: ' + dd.interests_debug.err : '') : '') +
    '\n• الحملة: ' + ref + ' — المجموعة: ' + dd.adgroup_id + ' — الإعلانات: ' + (dd.ad_ids || []).join(', ') + (dd.smart ? '\n• حملة Smart+ (استهداف تلقائي من تيك توك، نصف الميزانية): ' + (dd.smart.ready ? dd.smart.campaign_id + (dd.smart.activated ? ' — شغالة' : ' — جاهزة (توقف حتى التفعيل)') : '⚠️ ما انخلقت (' + dd.smart.stage + '): ' + dd.smart.error + ' — اليدوية انخلقت ولا تأثرت.') + '\n  (الميزانية فوق مقسومة: نصف يدوي ونصف سمارت+)' : '') + (dd.activated ? '\n\n👁 المراقبة شغالة (كل 10 دقايق): تنبيه عند 0.15 / 0.20 / 0.30$ لتكلفة النتيجة + إيقاف تلقائي عند 0.30$ + تقرير كل ساعة.\nلإيقافها: /pause_' + ref : '\n\nللتفعيل مع مراقبة التكلفة (تنبيه عند 0.15 / 0.20 / 0.30$ للنتيجة + إيقاف تلقائي عند 0.30$) اضغط:\n/activate_' + ref + (dd.activation_error ? '\n⚠️ حاولت أفعّلها مباشرة (حسب طلبك/سجل الكود) وما كدرت: ' + dd.activation_error : '')) + '\n\n📍 المراحل: ✅ أُنشئت | ' + (dd.stages ? (dd.stages.enabled ? '✅' : '⚠️') : '❔') + ' مفعّلة (حسب تيك توك) | ⏳ توزيع | ⏳ نتائج\nالنجاح الحقيقي يُقاس بالأرقام: افحص التوزيع والنتائج بعد ساعة بـ /check_' + ref;
  else {
    const m = String(e.message || '').slice(0, 160);
    const why = dd.stage === 'pages' ? (m === 'page_not_found' ? 'ما لقيت صفحة هبوط بهذا الاسم.' : m === 'page_required' ? 'عندك أكثر من صفحة هبوط، حدد اسم الصفحة.' : m === 'no_pages' ? 'ما عندك صفحات فورية منشورة بهذا الحساب.' : 'ما كدرت أقرأ الصفحات: ' + m) + (dd.pages && dd.pages.length ? '\nصفحاتك: ' + dd.pages.join('، ') : '')
      : dd.stage === 'whatsapp' ? (m === 'whatsapp_not_linked' ? 'رقم الواتساب ' + (L.whatsapp_number ? '0' + L.whatsapp_number + ' ' : '') + 'مو مربوط بحساب تيك توك هذا، فما أنشأت حملة (حتى ما تروح الرسائل لرقم ثاني).' + ((dd.linked || []).length ? '\nالمربوط بالحساب هسه: ' + dd.linked.join('، ') : '') + '\nاربط رقمك من TikTok Ads Manager ← Business Messaging ← WhatsApp ثم أعد الطلب.' : 'ما كدرت أتحقق من رقم الواتساب: ' + m)
      : dd.stage === 'video' ? 'كود Spark ما اشتغل (الفيديو خاص أو الكود منتهي أو غير صالح). اطلب كود جديد من تيك توك.'
      : 'فشلت خطوة (' + (dd.stage || '؟') + '): ' + m + ' [' + cls + ']';
    text = '❌ ما كملت الحملة. ' + why + (ref ? '\n⚠️ انعملت حملة ناقصة (متوقفة) رقمها ' + ref + ' بالحساب ' + d.account + '. احذفها من TikTok Ads Manager أو قولي أكمّلها.' : '');
  }
  const status = ok ? 'succeeded' : (ref || cls === 'outcome_unknown' ? 'needs_manual_check' : 'failed');
  return [{ json: { ctx: d.ctx, chatId: d.chatId, key: d.key, ok, status, ref: ok ? ref : (ref || cls), ext: ref, platform: 'tiktok', account: d.account, name: L.campaign_name, budget: (d.budget_usd || L.budget), objective: L.objective === 'sales' ? 'WEB_CONVERSIONS' : 'LEAD_GENERATION', activated: !!dd.activated, text } }];
}
const ok = r.ok === true;
const cls = (r.error && r.error.class) || '';
const ext = ok ? String((d.platform === 'meta' ? (r.data && r.data.id) : (r.data && r.data.data && r.data.data.campaign_id)) || '') : '';
const status = ok ? 'succeeded' : (cls === 'outcome_unknown' ? 'needs_manual_check' : 'failed');
const msgs = { auth_expired: 'توكن حساب الإعلان منتهي. لازم يُعاد ربطه.', outcome_unknown: 'ما أكدت إذا انعملت الحملة. افحص المنصة قبل ما تعيد المحاولة.', forbidden: 'ما عندك صلاحية على هذا الحساب.',
  rate_limited: 'المنصة مشغولة. جرّب بعد شوي.', transient: 'خلل مؤقت بالمنصة. جرّب بعد شوي.', invalid_params: 'بيانات الحملة غير صالحة.', bad_request: 'المنصة رفضت الطلب.', permission_denied: 'المنصة رفضت الصلاحية.' };
const text = ok ? '✅ انعملت الحملة "' + d.name + '" (متوقفة PAUSED) — ' + d.platform + ' — ' + ext : '❌ ما انعملت الحملة: ' + (msgs[cls] || 'خطأ غير متوقع (' + cls + ')');
return [{ json: { ctx: d.ctx, chatId: d.chatId, key: d.key, ok, status, ref: ok ? ext : cls, ext, platform: d.platform, account: d.account, name: d.name, budget: d.budget, objective: d.platform === 'meta' ? 'OUTCOME_TRAFFIC' : 'TRAFFIC', text } }];
""")
    sw5 = w.add("Create: ok?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.ok ? 1 : 0 }}"})
    rec = pg(w, "Create: record campaign", "SELECT api.record_campaign($1, $2, $3, $4, $5, $6, $7::numeric) AS pk",
             "={{ [$json.ctx, $json.platform, $json.account, $json.ext, $json.name, $json.objective, $json.budget] }}", CRT)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    back = code(w, "Create: after record", r"""
const d = $('Create: result').first().json; const r = $input.first().json;
if (r.error) return [{ json: { ...d, status: 'needs_manual_check', text: '⚠️ الحملة انعملت بالمنصة لكن ما انسجلت عندي. افحصها يدوياً: ' + d.ext } }];
return [{ json: d }];
""")
    fin = pg(w, "Create: finish request", "SELECT api.finish_campaign_request($1, $2, $3, $4)", "={{ [$json.ctx || $('Create: result').first().json.ctx, $json.key || $('Create: result').first().json.key, $json.status || $('Create: result').first().json.status, $json.ref || $('Create: result').first().json.ref] }}", CRT)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    cdone = reply("Create: reply", "const d = $('Create: result').first().json; let t = d.text; try { const a = $('Create: after record').all(); if (a.length && a[0].json && a[0].json.text) t = a[0].json.text; } catch (e) {} return [{ json: { ctx: d.ctx, chatId: d.chatId, text: t } }];")
    w.link(sw, parse, 5); w.chain(parse, sw3); w.link(sw3, cbad, 0); w.link(sw3, begin, 1); w.chain(begin, gate, sw4); w.link(sw4, cprep, 0); w.link(sw4, cnotnew, 1)
    wat = pg(w, "Create: watch", "SELECT $1::text AS ctx, $4::text AS key, $5::text AS status, $6::text AS ref, CASE WHEN $3::boolean THEN (SELECT count(*) FROM api.start_watch($1, 'tiktok', $2, '{0.15,0.2,0.3}'::numeric[], 0.3))::int ELSE 0 END AS n",
             "={{ [$json.ctx, $json.ext || '', !!$json.activated && $json.status === 'succeeded', $json.key, $json.status, $json.ref] }}", CRT)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    w.chain(cprep, ccall, cres, sw5); w.link(sw5, fin, 0); w.link(sw5, rec, 1); w.chain(rec, back, wat, fin); w.link(fin, cdone)
    w.link(aisw, racc, 0); w.link(aisw, acc, 1); w.link(aisw, cam, 2); w.link(aisw, aiacc, 3); w.chain(aiacc, aiplan, sw3); w.link(aisw, help_, 4); w.link(aisw, chatprep, 5); w.link(aisw, aierr, 6); w.link(aisw, stacc, 7)
    # 8/9: /activate_<id> و /pause_<id> (تيك توك). التفعيل أمر صريح فقط؛ ينشئ مراقبة التكلفة بنفس الخطوة.
    alook = pg(w, "Act: lookup", "SELECT platform::text AS platform, ad_account_external_id AS account, external_id, name, status FROM api.list_campaigns($1, NULL) WHERE external_id = $2",
               "={{ [$('Route').first().json.ctx, (($('Route').first().json.args || '').match(/\\d{5,24}/) || [''])[0]] }}", CRT, always=True)
    aprep = code(w, "Act: prep", r"""
const d = $('Route').first().json; const c = $input.all().map(i => i.json).filter(r => r && r.external_id)[0];
const say = t => [{ json: { ctx: d.ctx, chatId: d.chatId, halt: true, text: t } }];
if (!c) return say('ما لقيت حملة بهذا الرقم عندي. استعمل الرقم من رسالة إنشاء الحملة (/campaigns تعرض آخر حملاتك).');
if (c.platform !== 'tiktok') return say('التفعيل والإيقاف بالبوت حالياً لتيك توك فقط.');
if (d.cmd === 'check') return [{ json: { ctx: d.ctx, chatId: d.chatId, halt: false, mode: 'check', cid: c.external_id, name: c.name, cap: 0, alerts: [], platform: 'tiktok', ad_account: c.account, op: 'tiktok.campaign_check', params: { campaign_id: c.external_id }, idem: 'tgupd-' + d.chatId + '-' + d.updateId + '-check' } }];
const act = d.cmd === 'activate' || d.cmd === 'restart';
if (d.cmd === 'activate' && c.status === 'ACTIVE') return say('هذي الحملة شغالة أصلاً ومراقبتها فعالة. لإيقافها: /pause_' + c.external_id);
const args = String(d.args || '');
const sm = args.match(/stop\s*=\s*([0-9]*\.?[0-9]+)/i), am = args.match(/alerts?\s*=\s*([0-9.,\s]+)/i);
let cap = sm ? Number(sm[1]) : 0.30;
let alerts = am ? am[1].split(/[,\s]+/).filter(Boolean).map(Number) : [0.15, 0.20, 0.30];
if (!(cap > 0 && cap <= 1000) || alerts.length > 10 || alerts.some(x => !(x > 0 && x <= 1000))) return say('القيم غير صالحة. مثال: /activate_' + c.external_id + ' stop=0.30 alerts=0.15,0.20,0.30');
alerts = [...new Set(alerts)].sort((a, b) => a - b);
const base = { ctx: d.ctx, chatId: d.chatId, halt: false, restart: d.cmd === 'restart', mode: act ? 'activate' : 'pause', cid: c.external_id, name: c.name, cap, alerts, platform: 'tiktok', ad_account: c.account,
  idem: 'tgupd-' + d.chatId + '-' + d.updateId + '-' + (act ? 'act' : 'pause') };
return [{ json: act ? { ...base, op: 'tiktok.activate_campaign', params: { campaign_id: c.external_id } }
                    : { ...base, op: 'tiktok.set_campaign_status', params: { campaign_ids: [c.external_id], operation_status: 'DISABLE' } } }];
""")
    asw = w.add("Act: go?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.halt ? 0 : 1 }}"})
    acall = call_broker(w, "Act: call Broker")
    ares = code(w, "Act: result", r"""
const p = (() => { try { return $('Stat: choose').first().json; } catch (e) { return $('Act: prep').first().json; } })(); const r = $input.first().json; const e = r.error || {}; const dd = r.data || {};
const act = p.mode === 'activate';
if (r.ok === true) return [{ json: { ...p, ok: true } }];
const why = { forbidden: 'ما عندك صلاحية (تحتاج دور مدير).', auth_expired: 'توكن تيك توك منتهي. لازم يُعاد ربط الحساب.', outcome_unknown: 'ما أكدت إذا تنفذ الأمر. افحص الحملة من TikTok Ads Manager.', rate_limited: 'تيك توك مشغول. جرّب بعد شوي.' }[e.class] || ('تيك توك رفض الخطوة (' + (dd.stage || '؟') + '): ' + String(e.message || '').slice(0, 140));
return [{ json: { ...p, ok: false, text: '❌ ما كملت ' + (act ? 'التفعيل' : p.mode === 'check' ? 'الفحص' : 'الإيقاف') + ': ' + why + (act ? '\nالحملة ما بدأت تصرف (تُفعَّل الحملة آخر خطوة).' : '') } }];
""")
    aok = w.add("Act: ok?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.ok ? 1 : 0 }}"})
    adb = pg(w, "Act: record", "SELECT CASE WHEN $5 = 'check' THEN 0 WHEN $5 = 'activate' THEN (SELECT count(*) FROM api.start_watch($1, 'tiktok', $2, $3::numeric[], $4::numeric))::int ELSE api.rule_update($1, 'tiktok', $2, 0::numeric, 'off')::int END AS n",
             "={{ [$json.ctx, $json.cid, '{' + $json.alerts.join(',') + '}', $json.cap, $json.mode] }}", CRT, always=True)
    w.nodes[-1]["onError"] = "continueRegularOutput"
    arep = reply("Act: reply", r"""
const p = $('Act: result').first().json; const r = $input.first().json;
let text;
if (p.mode === 'check') {
  const b = $('Act: call Broker').first().json, c = b.data || {}, st = c.stages || {}, m = c.metrics || {};
  const mk = (x) => x ? '✅' : '❌';
  text = '🔎 فحص الحملة «' + p.name + '» (' + p.cid + ')\n' + mk(st.created) + ' أُنشئت (Created)\n' + mk(st.enabled) + ' مفعّلة فعلياً حسب تيك توك (Enabled)' + (c.status && c.status.secondary ? ' — ' + c.status.secondary : '') + '\n' + mk(st.delivering) + ' توزيع (Delivering): ظهور ' + (m.impressions || 0) + '\n' + mk(st.results) + ' نتائج/رسائل (Results): ' + (m.results || 0) + '\n\n📊 آخر 7 أيام: صرف ' + (m.spend_usd || 0) + '$ | نقرات ' + (m.clicks || 0) + ' | CTR ' + (m.ctr_pct || 0) + '% | CPC ' + (m.cpc_usd == null ? '—' : m.cpc_usd + '$') + ' | CPM ' + (m.cpm_usd == null ? '—' : m.cpm_usd + '$') + ' | تكلفة الرسالة ' + (m.cost_per_result_usd == null ? '—' : m.cost_per_result_usd + '$') + '\n\n🧭 الحكم: ' + (c.verdict || '—');
} else if (p.mode === 'activate') {
  text = r.error ? '⚠️ فعّلت الحملة «' + p.name + '» بس ما كدرت أسجّل مراقبة التكلفة. أوقفها إذا تريد: /pause_' + p.cid
    : (p.restart ? '🔄 أعدت تشغيل الحملة «' : '✅ فعّلت الحملة «') + p.name + '» على TikTok.\n\n👁 المراقبة شغالة (كل 10 دقايق):\n• تنبيه لما تكلفة النتيجة توصل: ' + p.alerts.map(x => x + '$').join(' ، ') + '\n• إيقاف تلقائي إذا وصلت ' + p.cap + '$ أو أكثر\n• تقرير مفصل كل ساعة\n\nلإيقافها يدوياً: /pause_' + p.cid;
} else {
  text = '⏸️ أوقفت الحملة «' + p.name + '».' + (r.error ? '' : ' (المراقبة انتهت)') + '\nلتفعيلها ثانية: /activate_' + p.cid;
}
return [{ json: { ctx: p.ctx, chatId: p.chatId, text } }];
""")
    w.link(sw, alook, 8); w.link(sw, alook, 9); w.link(sw, alook, 10); w.chain(alook, aprep, asw); w.link(asw, cbad, 0); w.link(asw, acall, 1)
    w.chain(acall, ares, aok); w.link(aok, cbad, 0); w.link(aok, adb, 1); w.chain(adb, arep)
    w.chain(stacc, stprep, stsw)
    w.link(stsw, cbad, 0); w.link(stsw, stcall, 1); w.chain(stcall, stchoose, asw)

    # /balance (رصيد الحسابات) و /active (الحملات اللي صرفت اليوم): قراءة فقط، تعمل بالأمر أو بالكلام العادي ("شكد رصيد حساب بنين"، "شنو الحملات الشغالة")
    balacc = pg(w, "Bal: accounts", "SELECT external_id, name, currency FROM api.list_ad_accounts($1) WHERE platform = 'tiktok' AND enabled", "={{ [$('Route').first().json.ctx] }}", CRT, always=True)
    balprep = code(w, "Bal: prep", r"""
const d = $('Route').first().json;
const rows = $input.all().map(i => i.json).filter(r => r && r.external_id);
const nm = s => String(s || '').toLowerCase().replace(/[ً-ٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/[^\p{L}\p{N}]+/gu, '');
if (!rows.length) return [{ json: { ctx: d.ctx, chatId: d.chatId, halt: true, text: 'ما عندك حسابات تيك توك مفعّلة.' } }];
const text = String(d.text || '');
const ids = text.match(/\d{15,25}/g) || [];
let sel = rows.filter(r => ids.includes(String(r.external_id)));
if (!sel.length) {
  const STOP = new Set(['رصيد', 'رصيدي', 'رصيدك', 'شكد', 'كم', 'باقي', 'حساب', 'الحساب', 'بحساب', 'حسابي', 'balance', 'الرصيد', 'عن', 'اريد', 'شوف', 'اعطيني']);
  const toks = [...new Set(text.split(/[^\p{L}\p{N}]+/u).map(nm).filter(t => t.length >= 3 && !STOP.has(t)))];
  const words = r => String(r.name || '').split(/[^\p{L}\p{N}]+/u).map(nm).filter(w => w.length >= 3);
  const hit = rows.filter(r => toks.some(t => words(r).includes(t) || (t.length >= 4 && nm(r.name).includes(t))));
  if (hit.length && hit.length < rows.length) sel = hit;
}
if (!sel.length) sel = rows;
return [{ json: { ctx: d.ctx, chatId: d.chatId, halt: false, platform: 'tiktok', op: 'tiktok.balances', ad_account: null, params: { accounts: sel.map(r => String(r.external_id)).slice(0, 40) } } }];
""")
    balsw = w.add("Bal: go?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.halt ? 0 : 1 }}"})
    balcall = call_broker(w, "Bal: call Broker")
    balfmt = reply("Bal: reply", r"""
const d = $('Route').first().json; const r = $input.first().json;
const send = t => [{ json: { ctx: d.ctx, chatId: d.chatId, text: t } }];
if (r.ok !== true) return send('ما كدرت أقرأ الأرصدة هسه (تيك توك ما رد). جرّب بعد شوي.');
const FX = 1310, f0 = n => Math.round(n).toLocaleString('en-US');
const rows = ((r.data || {}).accounts || []).map(a => ({ ...a, usd: a.balance == null ? null : (a.currency === 'IQD' ? a.balance / FX : a.balance) }));
if (!rows.length) return send('ما رجع تيك توك أي رصيد. جرّب بعد شوي.');
rows.sort((a, b) => (a.usd == null ? 1e15 : a.usd) - (b.usd == null ? 1e15 : b.usd));
const line = a => (a.usd != null && a.usd < 5 ? '⚠️ ' : '• ') + (a.name || a.ad_account).slice(0, 26) + ': ' + (a.balance == null ? 'غير متاح' : a.currency === 'IQD' ? f0(a.balance) + ' د.ع (≈ $' + a.usd.toFixed(2) + ')' : '$' + a.usd.toFixed(2)) + (a.status && !/ENABLE/.test(a.status) ? ' — ' + a.status.replace('STATUS_', '') : '');
const known = rows.filter(a => a.usd != null);
let t = '💳 رصيد ' + (rows.length === 1 ? 'الحساب' : 'الحسابات (' + rows.length + ')') + ' — الأقل رصيداً أول:\n' + rows.slice(0, 25).map(line).join('\n');
if (rows.length > 25) t += '\n… وباقي ' + (rows.length - 25) + ' حساب';
if (rows.length > 1 && known.length) t += '\n\nالمجموع: $' + known.reduce((s, a) => s + a.usd, 0).toFixed(2);
if (known.some(a => a.usd < 5)) t += '\n⚠️ = رصيد أقل من 5$: الحملات ممكن توقف عند نفاده.';
if ((r.data || {}).accounts_failed) t += '\n(' + r.data.accounts_failed + ' حساب ما كدرت أقراه)';
return send(t);
""")
    w.chain(balacc, balprep, balsw); w.link(balsw, cbad, 0); w.link(balsw, balcall, 1); w.chain(balcall, balfmt)
    actacc = pg(w, "Active: accounts", "SELECT external_id FROM api.list_ad_accounts($1) WHERE platform = 'tiktok' AND enabled", "={{ [$('Route').first().json.ctx] }}", CRT, always=True)
    actprep = code(w, "Active: prep", r"""
const d = $('Route').first().json;
const rows = $input.all().map(i => i.json).filter(r => r && r.external_id);
if (!rows.length) return [{ json: { ctx: d.ctx, chatId: d.chatId, halt: true, text: 'ما عندك حسابات تيك توك مفعّلة.' } }];
return [{ json: { ctx: d.ctx, chatId: d.chatId, halt: false, platform: 'tiktok', op: 'tiktok.active_today', ad_account: null, params: { accounts: rows.map(r => String(r.external_id)).slice(0, 40) } } }];
""")
    actsw = w.add("Active: go?", "n8n-nodes-base.switch", 3.5, {"mode": "expression", "numberOutputs": 2, "output": "={{ $json.halt ? 0 : 1 }}"})
    actcall = call_broker(w, "Active: call Broker")
    actfmt = reply("Active: reply", r"""
const d = $('Route').first().json; const r = $input.first().json;
const send = t => [{ json: { ctx: d.ctx, chatId: d.chatId, text: t } }];
if (r.ok !== true) return send('ما كدرت أقرأ الحملات هسه (تيك توك ما رد). جرّب بعد شوي.');
const x = r.data || {}, c = x.campaigns || [];
if (!c.length) return send('ما صرفت ولا حملة اليوم لحد هسه' + (x.accounts_failed ? ' (' + x.accounts_failed + ' حساب ما كدرت أقراه)' : '') + '.');
const line = k => (k.results === 0 && k.spend_usd >= 1 ? '⚠️ ' : '• ') + k.name.slice(0, 28) + '\n   صرف $' + k.spend_usd + ' | رسائل ' + k.results + ' | سعر الرسالة ' + (k.cost_per_result_usd == null ? '—' : '$' + k.cost_per_result_usd) + ' | نقرات ' + k.clicks + ' → /check_' + k.campaign_id;
let t = '📊 الحملات اللي صرفت اليوم (' + x.campaigns_count + ' حملة، إجمالي $' + x.total_spend_usd + '):\n' + c.slice(0, 15).map(line).join('\n');
if (c.some(k => k.results === 0 && k.spend_usd >= 1)) t += '\n\n⚠️ = صرفت 1$ فأكثر بدون رسائل لحد هسه.';
if (x.accounts_failed) t += '\n(' + x.accounts_failed + ' حساب ما كدرت أقراه)';
return send(t);
""")
    w.chain(actacc, actprep, actsw); w.link(actsw, cbad, 0); w.link(actsw, actcall, 1); w.chain(actcall, actfmt)
    w.link(sw, balacc, 11); w.link(sw, actacc, 12); w.link(aisw, balacc, 8); w.link(aisw, actacc, 9)

    # /duplicate <رقم الحملة>: نسخ حملة واتساب (يدوية) من تيك توك بنفس إعداداتها وفيديوهاتها ثم تفعيلها؛ يمر بنفس بوابة الإنشاء (الاشتراك/الحد اليومي/عدم التكرار) وتسجيل الحملة والمراقبة
    duplook = pg(w, "Dup: lookup", "SELECT platform::text AS platform, ad_account_external_id AS account, external_id, name, status, daily_budget_minor FROM api.list_campaigns($1, NULL) WHERE external_id = $2",
                 "={{ [$('Route').first().json.ctx, (($('Route').first().json.args || '').match(/\\d{5,24}/) || [''])[0]] }}", CRT, always=True)
    dupprep = code(w, "Dup: prep", r"""
const d = $('Route').first().json; const c = $input.all().map(i => i.json).filter(r => r && r.external_id)[0];
const bad = t => [{ json: { ...d, valid: false, text: t } }];
if (!c) return bad('ما لقيت حملة بهذا الرقم عندي. اكتب /duplicate مع رقم حملة من رسالة إنشاء الحملة (/campaigns تعرض آخر حملاتك).');
if (c.platform !== 'tiktok') return bad('النسخ بالبوت حالياً لتيك توك فقط.');
const budget = Number(c.daily_budget_minor) > 0 ? Number(c.daily_budget_minor) : 1;
const name = String(c.name || 'حملة').slice(0, 150) + ' - نسخة';
return [{ json: { ...d, valid: true, platform: 'tiktok', account: c.account, budget, name, key: 'tgupd-' + d.chatId + '-' + d.updateId + '-dup', payload: ['dup', c.external_id, c.account, budget].join('|'), dup: { campaign_id: String(c.external_id), name } } }];
""")
    w.chain(duplook, dupprep, sw3); w.link(sw, duplook, 13)
    w.save("10_ingress_commands.json", settings=b.ERR_SETTINGS)
