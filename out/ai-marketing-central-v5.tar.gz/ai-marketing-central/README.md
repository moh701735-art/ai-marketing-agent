# مشروع التسويق المركزي (مستقل)

نظام جديد بالكامل: قاعدة PostgreSQL مركزية متعددة العملاء + Credential Broker + Workflows مركزية.
**لا علاقة تشغيلية له بأي نظام سابق**: لا اتصال، لا توكنات، لا بيانات، لا Workflows مستوردة.

## الحالة
المراحل P1 (هيكل) وP2 (قاعدة + نسخ/استعادة) وP3 (Credential Broker) وP4 (n8n مركزي + اشتراكات + جاهزية) وP5 (E2E على عميلين) منفَّذة محلياً. النتائج الفعلية في `docs/results/` (+ `p3/` `p4/` `p5/`). P6 (مراجعة أمنية، `docs/results/P6-report.md`) منفَّذة؛ P7 (ملفات staging بـ `deploy/`، `docs/results/P7-report.md`) مجهَّزة ومجرَّبة محلياً فقط (لا سيرفر بعد)؛ P8 وما بعدها لم تبدأ.
لا بوت حقيقي، لا Meta/TikTok، لا استضافة مدفوعة.

## التشغيل المحلي (Docker فقط)
```
./scripts/install_hooks.sh        # فاحص الأسرار قبل كل commit
./ops/db-up.sh                    # postgres محلي، شبكة internal بلا خروج للإنترنت
./ops/apply-schema.sh             # قاعدتان فارغتان: central_dev, vault_dev
./ops/run-db-tests.sh             # اختبارات القاعدة (311) على قواعد test منفصلة
./broker/run_tests.sh             # 38 اختبار بلا قاعدة: تشفير/إخفاء/توقيع (22) + وحدة (16)
./ops/run-broker-tests.sh         # 111 اختبار: وحدة + تكامل (Postgres) + اختراق داخلي
./ops/smoke-broker.sh             # الخدمة الحقيقية في Docker + منصة وهمية
./ops/mutation-check.py           # يكسر الكود عمداً ويتأكد أن الاختبارات تفشل
./ops/restore-drill.sh            # نسخ احتياطي مشفّر + محاكاة فقد + استعادة + تحقق
./ops/verify-isolation.sh         # إثبات الاستقلال والعزل الشبكي
./ops/p4-up.sh                    # n8n + Broker + منصات وهمية (مرة واحدة)
./ops/p4-e2e.sh                   # P4: أوامر + مهمة مجدولة + جاهزية + اشتراكات + أخطاء + فحص أسرار
./ops/p6-audit.sh                 # P6: حقن/عزل/webhook على n8n الحي
./ops/add-tenant.py --help       # إضافة عميل جديد (الأسرار بمتغيرات بيئة/إدخال مخفي، تُخزَّن بالـ vault)
./ops/p5-e2e.sh                   # P5: السيناريوهات الستة على عميلين (يوقف القاعدة 60 ثانية)
```

## قواعد
- لا أسرار في Git (`scripts/scan_repo.py` + pre-commit). الأسرار تُولَّد محلياً في `.env` و`.secrets/`.
- بيانات وهمية فقط. لا حملات حقيقية.
